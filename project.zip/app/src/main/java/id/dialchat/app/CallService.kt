package id.dialchat.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.DisconnectCause
import android.telecom.InCallService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

class Ended(val number: String, val name: String?, val sim: String?, val seconds: Long, val acc: PhoneAccountHandle?)

object CallManager {
    var ended: Ended? = null
    val incomingSet = HashSet<Call>()
    val autoRejected = HashSet<Call>()
    val calls = ArrayList<Call>()
    var audio: CallAudioState? = null
    var service: InCallService? = null
    private val listeners = ArrayList<() -> Unit>()
    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun fire() { for (l in listeners.toList()) l() }
    fun primary(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING }
        ?: calls.firstOrNull { it.state != Call.STATE_HOLDING } ?: calls.firstOrNull()
    fun other(c: Call): Call? = calls.firstOrNull { it !== c }
}

object CallUtil {
    fun number(c: Call): String = c.details?.handle?.schemeSpecificPart ?: ""

    fun name(ctx: Context, n: String): String? {
        if (n.isBlank()) return null
        return try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    fun sim(ctx: Context, c: Call): String? = try {
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val list = tm.callCapablePhoneAccounts
        val h = c.details?.accountHandle
        val idx = list.indexOfFirst { it == h }
        if (idx >= 0 && list.size > 1) "SIM ${idx + 1}" else null
    } catch (e: Exception) { null }
}

object Notif {
    const val ID = 1001
    const val MISSED = 2000

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    private fun callPi(ctx: Context, code: Int, act: String?): PendingIntent {
        val i = Intent(ctx, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (act != null) i.putExtra("act", act)
        return PendingIntent.getActivity(ctx, code, i, flags())
    }

    private fun channel(nm: NotificationManager, id: String, name: String, imp: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(id, name, imp)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun builder(ctx: Context, ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, ch) else Notification.Builder(ctx)

    fun show(ctx: Context, c: Call) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ringing = c.state == Call.STATE_RINGING
        channel(nm, "incoming", "Panggilan masuk", NotificationManager.IMPORTANCE_HIGH)
        channel(nm, "ongoing", "Panggilan berlangsung", NotificationManager.IMPORTANCE_LOW)
        val n = CallUtil.number(c)
        val title = CallUtil.name(ctx, n) ?: n.ifBlank { "Nomor tidak dikenal" }
        val b = builder(ctx, if (ringing) "incoming" else "ongoing")
        b.setSmallIcon(R.drawable.ic_phone)
        b.setColor(Color.parseColor("#1D4ED8"))
        b.setContentTitle(title)
        b.setContentText(if (ringing) "Panggilan masuk" else "Panggilan berlangsung")
        b.setOngoing(true)
        b.setCategory(Notification.CATEGORY_CALL)
        b.setContentIntent(callPi(ctx, 0, null))
        if (ringing) {
            b.setPriority(Notification.PRIORITY_HIGH)
            b.setFullScreenIntent(callPi(ctx, 1, null), true)
            b.addAction(R.drawable.ic_phone, "Jawab", callPi(ctx, 2, "answer"))
            b.addAction(R.drawable.ic_hangup, "Tolak", callPi(ctx, 3, "reject"))
        }
        nm.notify(ID, b.build())
    }

    fun cancel(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
    }

    fun missed(ctx: Context, n: String, auto: Boolean = false) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        channel(nm, "missed", "Panggilan tak terjawab", NotificationManager.IMPORTANCE_DEFAULT)
        val base = MISSED + (n.hashCode() and 0xFFFF)
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tab", 1)
        val pi = PendingIntent.getActivity(ctx, base, i, flags())
        val name = CallUtil.name(ctx, n) ?: n.ifBlank { "Nomor tidak dikenal" }
        val b = builder(ctx, "missed")
        b.setSmallIcon(R.drawable.ic_in)
        b.setColor(Color.parseColor("#1D4ED8"))
        b.setContentTitle(if (auto) "Panggilan diblokir otomatis" else "Panggilan tak terjawab")
        b.setContentText(name)
        b.setAutoCancel(true)
        b.setContentIntent(pi)
        if (n.any { it.isDigit() }) {
            val callI = Intent(ctx, MainActivity::class.java)
                .setAction(Intent.ACTION_DIAL)
                .setData(Uri.parse("tel:" + Uri.encode(n)))
                .putExtra("autocall", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            b.addAction(R.drawable.ic_phone, "Telepon balik", PendingIntent.getActivity(ctx, base + 100000, callI, flags()))
            val w = Wa.normalize(n)
            if (w != null) {
                val waI = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$w")).setPackage("com.whatsapp")
                b.addAction(R.drawable.ic_wa, "WhatsApp", PendingIntent.getActivity(ctx, base + 200000, waI, flags()))
            }
            val smsI = Intent(ctx, ThreadActivity::class.java).putExtra("address", n)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            b.addAction(R.drawable.ic_bubble, "SMS", PendingIntent.getActivity(ctx, base + 300000, smsI, flags()))
        }
        nm.notify(base, b.build())
    }
}

class CallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            CallManager.primary()?.let { Notif.show(this@CallService, it) }
            CallManager.fire()
        }
        override fun onDetailsChanged(call: Call, details: Call.Details) { CallManager.fire() }
    }

    override fun onCreate() { super.onCreate(); CallManager.service = this }
    override fun onDestroy() { CallManager.service = null; super.onDestroy() }

    override fun onCallAdded(call: Call) {
        var silence = false
        if (call.state == Call.STATE_RINGING) {
            val mode = Prefs.spamMode(this)
            if (mode > 0 && CallUtil.name(this, CallUtil.number(call)) == null) {
                if (mode == 2) {
                    CallManager.autoRejected.add(call)
                    call.reject(false, null)
                    return
                }
                silence = true
            }
        }
        call.registerCallback(cb)
        CallManager.ended = null
        if (call.state == Call.STATE_RINGING) CallManager.incomingSet.add(call)
        CallManager.calls.add(call)
        CallManager.audio = callAudioState
        Notif.show(this, CallManager.primary() ?: call)
        CallManager.fire()
        if (call.state != Call.STATE_RINGING) {
            try {
                startActivity(Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { }
        }
        if (silence) {
            Handler(Looper.getMainLooper()).postDelayed({
                try { (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).silenceRinger() } catch (e: Exception) { }
            }, 500)
        }
    }

    override fun onCallRemoved(call: Call) {
        if (CallManager.autoRejected.remove(call)) {
            Notif.missed(this, CallUtil.number(call), true)
            return
        }
        call.unregisterCallback(cb)
        CallManager.calls.remove(call)
        val wasIncoming = CallManager.incomingSet.remove(call)
        val t0 = call.details?.connectTimeMillis ?: 0L
        if (CallManager.calls.isEmpty() && (!wasIncoming || t0 > 0L)) {
            val nn = CallUtil.number(call)
            CallManager.ended = Ended(nn, CallUtil.name(this, nn), CallUtil.sim(this, call),
                if (t0 > 0L) (System.currentTimeMillis() - t0) / 1000 else 0L, call.details?.accountHandle)
        }
        val missed = call.details?.disconnectCause?.code == DisconnectCause.MISSED
        val n = CallUtil.number(call)
        val p = CallManager.primary()
        if (p == null) Notif.cancel(this) else Notif.show(this, p)
        if (missed) Notif.missed(this, n)
        CallManager.fire()
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        CallManager.audio = audioState
        CallManager.fire()
    }
}
