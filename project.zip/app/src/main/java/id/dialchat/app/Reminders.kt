package id.dialchat.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/** Pengingat "telepon balik": satu pengingat per nomor, disimpan di Prefs supaya bisa dijadwalkan ulang setelah HP restart. */
object Reminders {
    private const val ACTION = "id.dialchat.REMINDER"

    private fun key(number: String) = number.filter { it.isDigit() }.takeLast(9).ifEmpty { number }
    fun code(number: String): Int = (key(number).hashCode() and 0x3FFFFFFF) * 2

    private fun items(ctx: Context): List<JSONObject> {
        return try {
            val a = JSONArray(Prefs.remindersJson(ctx))
            (0 until a.length()).map { a.getJSONObject(it) }
        } catch (e: Exception) { logW("Reminders", e); emptyList() }
    }
    private fun write(ctx: Context, list: List<JSONObject>) {
        val a = JSONArray()
        for (o in list) a.put(o)
        Prefs.setRemindersJson(ctx, a.toString())
    }

    private fun setAlarm(ctx: Context, number: String, name: String, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION)
            .putExtra("num", number).putExtra("name", name)
        val pi = PendingIntent.getBroadcast(ctx, code(number), i, SmsUtil.flags())
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.set(AlarmManager.RTC_WAKEUP, at, pi)
    }

    /** Jadwalkan (atau ganti) pengingat untuk [number] pada waktu [at] (epoch ms). */
    fun schedule(ctx: Context, number: String, name: String, at: Long) {
        val k = key(number)
        val list = items(ctx).filter { it.optString("k") != k }.toMutableList()
        list.add(JSONObject().put("k", k).put("num", number).put("name", name).put("at", at))
        write(ctx, list)
        setAlarm(ctx, number, name, at)
    }

    /** Dipanggil saat pengingat berbunyi: hapus dari daftar tersimpan. */
    fun fired(ctx: Context, number: String) {
        val k = key(number)
        write(ctx, items(ctx).filter { it.optString("k") != k })
    }

    /** Setelah restart semua alarm hilang: pasang lagi. Yang waktunya sudah lewat langsung berbunyi. */
    fun rescheduleAll(ctx: Context) {
        for (o in items(ctx)) {
            try { setAlarm(ctx, o.getString("num"), o.optString("name", o.getString("num")), o.getLong("at")) }
            catch (e: Exception) { logW("Reminders", e) }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val num = i.getStringExtra("num") ?: return
        val name = i.getStringExtra("name") ?: num
        Reminders.fired(ctx, num)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("reminder", tr(R.string.s_pengingat), NotificationManager.IMPORTANCE_HIGH))
            b = Notification.Builder(ctx, "reminder")
        } else {
            b = Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
        }
        val code = Reminders.code(num)
        val tel = Uri.fromParts("tel", num, null)
        // ketuk notifikasi: buka dialpad dengan nomor terisi
        val open = Intent(Intent.ACTION_DIAL, tel).setClass(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        b.setSmallIcon(R.drawable.ic_phone)
            .setContentTitle(tr(R.string.s_telepon_balik_ke, name))
            .setContentText(num)
            .setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(ctx, code, open, SmsUtil.flags()))
        val canCall = Build.VERSION.SDK_INT < 23 ||
            ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (canCall) {
            val call = Intent(Intent.ACTION_CALL, tel).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            b.addAction(R.drawable.ic_phone, tr(R.string.s_telepon), PendingIntent.getActivity(ctx, code + 1, call, SmsUtil.flags()))
        }
        nm.notify(code, b.build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleAll(ctx)
    }
}
