package id.dialchat.app

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ContactDetailActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val SURF by lazy { col(R.color.surf) }
    private val LINE by lazy { col(R.color.line) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val pal by lazy { intArrayOf(BLUE, GREEN, Color.parseColor("#6D28D9"), Color.parseColor("#B45309"), RED) }

    private var cid = 0L
    private var current: ContactFull? = null
    private var pendingDelete = false
    private lateinit var body: LinearLayout
    private lateinit var topBar: LinearLayout

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun hasWrite() = Build.VERSION.SDK_INT < 23 ||
        checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cid = intent.getLongExtra("id", 0L)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdr = LinearLayout(this)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = cornerBg(gd, BG)
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        topBar = LinearLayout(this)
        topBar.gravity = Gravity.CENTER_VERTICAL
        hdr.addView(topBar, LinearLayout.LayoutParams(MATCH, WRAP))
        val sv = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(20), dp(16), dp(24))
        sv.addView(body)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = Collapse(hdr, dp(112), dp(68)) { p ->
            hdr.setPadding(dp(20), lerpI(dp(44), dp(14), p), dp(20), lerpI(dp(24), dp(10), p))
        }
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Photos.clear()
        render()
    }

    private fun circle(res: Int, bg: Int, fg: Int, size: Int, desc: String, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.background = ov(bg); f.contentDescription = desc; f.isClickable = true
        f.setOnClickListener { onClick() }
        val i = icon(res, fg, 20)
        i.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        f.addView(i)
        f.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        return f
    }

    private fun renderTop(c: ContactFull) {
        topBar.removeAllViews()
        val glass = Color.argb(46, 255, 255, 255)
        topBar.addView(circle(R.drawable.ic_back, glass, Color.WHITE, 44, tr(R.string.s_kembali)) { finish() })
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val firstNum = c.phones.firstOrNull()?.value
        if (firstNum != null) {
            val fav = Prefs.isFav(this, firstNum)
            topBar.addView(circle(R.drawable.ic_star, glass, if (fav) Color.parseColor("#FDE68A") else Color.WHITE, 44,
                if (fav) tr(R.string.s_hapus_dari_favorit) else tr(R.string.s_favoritkan)) {
                Prefs.toggleFav(this, c.display, firstNum)
                render()
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        }
        topBar.addView(circle(R.drawable.ic_edit, glass, Color.WHITE, 44, tr(R.string.s_ubah_kontak)) {
            startActivity(Intent(this, ContactEditActivity::class.java).putExtra("id", cid))
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        topBar.addView(circle(R.drawable.ic_delete, glass, Color.WHITE, 44, tr(R.string.s_hapus_kontak)) { confirmDelete() },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
    }

    private fun render() {
        val c = ContactsRepo.load(this, cid)
        if (c == null) { finish(); return }
        current = c
        renderTop(c)
        body.removeAllViews()

        val name = c.display
        val av = TextView(this)
        av.text = (name.firstOrNull { it.isLetterOrDigit() } ?: '#').uppercaseChar().toString()
        av.gravity = Gravity.CENTER; av.textSize = 30f; av.setTextColor(Color.WHITE); av.setTypeface(null, Typeface.BOLD)
        av.background = ov(pal[Math.abs(name.hashCode()) % pal.size])
        val pb = Photos.get(this, c.photoUri)
        body.addView(if (pb != null) photoView(pb) else av, LinearLayout.LayoutParams(dp(80), dp(80)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        body.addView(TextView(this).apply {
            text = name; textSize = 22f; setTextColor(INK); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        body.addView(TextView(this).apply {
            text = tr(R.string.s_disimpan_di) + c.source.label; textSize = 13f; setTextColor(MUTED); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        val num = c.phones.firstOrNull()?.value
        if (num != null) {
            val acts = LinearLayout(this)
            acts.setPadding(0, dp(20), 0, dp(8))
            acts.addView(action(R.drawable.ic_phone, tr(R.string.s_telepon), BLUE, Color.WHITE) { call(num) })
            acts.addView(action(R.drawable.ic_bubble, tr(R.string.btn_message), SURF, INK) { message(num) })
            if (Wa.normalize(num) != null) acts.addView(action(R.drawable.ic_wa, "WhatsApp", GREEN, Color.WHITE) { Wa.open(this, num) })
            body.addView(acts, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        divider()
        for (p in c.phones) {
            body.addView(infoRow(R.drawable.ic_phone, p.value, ContactsRepo.phoneTypeName(p.type, p.label),
                R.drawable.ic_bubble, tr(R.string.s_pesan_ke, p.value), { call(p.value) }, { message(p.value) }, { copy(p.value) }))
        }
        for (m in c.emails) {
            body.addView(infoRow(R.drawable.ic_send, m.value, ContactsRepo.emailTypeName(m.type, m.label),
                0, "", { mail(m.value) }, null, { copy(m.value) }))
        }
        if (c.note.isNotBlank()) {
            body.addView(infoRow(R.drawable.ic_edit, c.note, tr(R.string.s_catatan), 0, "", {}, null, { copy(c.note) }))
        }
    }

    private fun divider() {
        body.addView(View(this).apply { setBackgroundColor(LINE) },
            LinearLayout.LayoutParams(MATCH, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(4) })
    }

    private fun action(res: Int, label: String, bg: Int, fg: Int, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER_HORIZONTAL
        l.addView(circle(res, bg, fg, 56, label, onClick))
        l.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(INK); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
        })
        l.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        return l
    }

    private fun infoRow(
        res: Int, title: String, sub: String, trailRes: Int, trailDesc: String,
        onClick: () -> Unit, onTrail: (() -> Unit)?, onLong: () -> Unit
    ): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(4), dp(12), dp(4), dp(12))
        r.isClickable = true
        r.setOnClickListener { onClick() }
        r.setOnLongClickListener { onLong(); true }
        r.addView(icon(res, MUTED, 22))
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(INK) })
        mid.addView(TextView(this).apply { text = sub; textSize = 13f; setTextColor(MUTED) })
        r.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(16); marginEnd = dp(8) })
        if (trailRes != 0 && onTrail != null) r.addView(circle(trailRes, SURF, INK, 44, trailDesc) { onTrail() })
        return r
    }

    private fun call(n: String) {
        val i = Intent(this, MainActivity::class.java).setAction(Intent.ACTION_DIAL)
            .setData(Uri.parse("tel:" + Uri.encode(n))).putExtra("autocall", true)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
    }

    private fun message(n: String) {
        startActivity(Intent(this, ThreadActivity::class.java).putExtra("address", n))
    }

    private fun mail(a: String) {
        try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$a"))) }
        catch (e: Exception) { toast(tr(R.string.s_aplikasi_email_tidak_ditemukan)) }
    }

    private fun copy(s: String) {
        try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kontak", s))
            toast(tr(R.string.s_disalin))
        } catch (e: Exception) { logW("ContactDetailActivity", e) }
    }

    private fun confirmDelete() {
        val c = current ?: return
        if (!hasWrite()) {
            pendingDelete = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_CONTACTS), 21)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(tr(R.string.s_hapus_kontak_2))
            .setMessage(tr(R.string.s_akan_dihapus_dari_perangkat_ini, c.display))
            .setPositiveButton(tr(R.string.s_hapus)) { _, _ ->
                if (ContactsRepo.delete(this, c.id)) { toast(tr(R.string.s_kontak_dihapus)); finish() } else toast(tr(R.string.s_gagal_menghapus_kontak))
            }
            .setNegativeButton(tr(R.string.s_batal), null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 21 && pendingDelete) {
            pendingDelete = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) confirmDelete()
            else toast(tr(R.string.s_izin_mengubah_kontak_diperlukan))
        }
    }
}
