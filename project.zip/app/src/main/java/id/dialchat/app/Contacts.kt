package id.dialchat.app

import android.accounts.AccountManager
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.util.LruCache
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Note
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.Photo
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts

// urutan properti penting: MainActivity memakai destructuring (name, number, id)
data class ContactItem(val name: String, val number: String, val id: Long, val photo: String?, val src: String)

class Entry(var value: String, var type: Int, var label: String = "")

class Source(val name: String?, val type: String?) {
    val label: String get() = if (name.isNullOrBlank()) tr("Perangkat") else name
    val key: String get() = (name ?: "") + "|" + (type ?: "")
}

class ContactFull(
    val id: Long, val rawId: Long, val first: String, val last: String, val display: String,
    val phones: List<Entry>, val emails: List<Entry>, val note: String, val source: Source,
    val photoUri: String? = null
)

object ContactsRepo {
    val PHONE_TYPES = intArrayOf(Phone.TYPE_MOBILE, Phone.TYPE_HOME, Phone.TYPE_WORK, Phone.TYPE_OTHER)
    val EMAIL_TYPES = intArrayOf(Email.TYPE_HOME, Email.TYPE_WORK, Email.TYPE_OTHER)

    fun phoneTypeName(t: Int, label: String): String = when (t) {
        Phone.TYPE_MOBILE -> tr("Seluler")
        Phone.TYPE_HOME -> tr("Rumah")
        Phone.TYPE_WORK -> tr("Kantor")
        Phone.TYPE_CUSTOM -> label.ifBlank { tr("Lainnya") }
        else -> tr("Lainnya")
    }

    fun emailTypeName(t: Int, label: String): String = when (t) {
        Email.TYPE_HOME -> tr("Pribadi")
        Email.TYPE_WORK -> tr("Kantor")
        Email.TYPE_CUSTOM -> label.ifBlank { tr("Lainnya") }
        else -> tr("Lainnya")
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    fun list(ctx: Context): List<ContactItem> {
        val out = ArrayList<ContactItem>()
        val seen = HashSet<String>()
        val srcMap = HashMap<Long, String>()
        try {
            ctx.contentResolver.query(
                RawContacts.CONTENT_URI,
                arrayOf(RawContacts.CONTACT_ID, RawContacts.ACCOUNT_NAME, RawContacts.ACCOUNT_TYPE),
                RawContacts.DELETED + "=0", null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    if (c.getString(2) == "com.whatsapp") continue
                    val id = c.getLong(0)
                    if (!srcMap.containsKey(id)) srcMap[id] = Source(c.getString(1), c.getString(2)).key
                }
            }
        } catch (e: Exception) { }
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, Phone.PHOTO_THUMBNAIL_URI),
                null, null, Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: ""
                    val n = c.getString(2) ?: ""
                    if (n.isBlank() || !seen.add(name + "|" + digits(n))) continue
                    out.add(ContactItem(name, n, id, c.getString(3), srcMap[id] ?: "|"))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // raw contact utama: bukan WhatsApp, bukan yang sudah dihapus
    private fun primaryRaw(ctx: Context, contactId: Long): Triple<Long, String?, String?>? {
        try {
            ctx.contentResolver.query(
                RawContacts.CONTENT_URI,
                arrayOf(RawContacts._ID, RawContacts.ACCOUNT_NAME, RawContacts.ACCOUNT_TYPE),
                RawContacts.CONTACT_ID + "=? AND " + RawContacts.DELETED + "=0",
                arrayOf(contactId.toString()), RawContacts._ID + " ASC"
            )?.use { c ->
                var fallback: Triple<Long, String?, String?>? = null
                while (c.moveToNext()) {
                    val t = Triple(c.getLong(0), c.getString(1), c.getString(2))
                    if (fallback == null) fallback = t
                    if (t.third != "com.whatsapp") return t
                }
                return fallback
            }
        } catch (e: Exception) { }
        return null
    }

    fun load(ctx: Context, contactId: Long): ContactFull? {
        val raw = primaryRaw(ctx, contactId) ?: return null
        var first = ""; var last = ""; var display = ""; var note = ""
        val phones = ArrayList<Entry>()
        val emails = ArrayList<Entry>()
        try {
            ctx.contentResolver.query(
                Data.CONTENT_URI,
                arrayOf(Data.MIMETYPE, Data.DATA1, Data.DATA2, Data.DATA3),
                Data.RAW_CONTACT_ID + "=?", arrayOf(raw.first.toString()), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val d1 = c.getString(1) ?: ""
                    val d2 = c.getString(2) ?: ""
                    val d3 = c.getString(3) ?: ""
                    when (c.getString(0)) {
                        StructuredName.CONTENT_ITEM_TYPE -> { display = d1; first = d2; last = d3 }
                        Phone.CONTENT_ITEM_TYPE -> if (d1.isNotBlank()) phones.add(Entry(d1, c.getInt(2), d3))
                        Email.CONTENT_ITEM_TYPE -> if (d1.isNotBlank()) emails.add(Entry(d1, c.getInt(2), d3))
                        Note.CONTENT_ITEM_TYPE -> note = d1
                    }
                }
            }
        } catch (e: Exception) { return null }
        var photo: String? = null
        try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.PHOTO_URI),
                ContactsContract.Contacts._ID + "=?", arrayOf(contactId.toString()), null
            )?.use { c -> if (c.moveToFirst()) photo = c.getString(0) }
        } catch (e: Exception) { }
        if (display.isBlank()) display = (first + " " + last).trim().ifBlank { phones.firstOrNull()?.value ?: "" }
        return ContactFull(contactId, raw.first, first, last, display, phones, emails, note, Source(raw.second, raw.third), photo)
    }

    // sumber yang sudah punya kontak di perangkat; "Perangkat" (lokal) selalu ada
    fun sources(ctx: Context): List<Source> {
        val out = ArrayList<Source>()
        val seen = HashSet<String>()
        out.add(Source(null, null)); seen.add("|")
        try {
            ctx.contentResolver.query(
                RawContacts.CONTENT_URI, arrayOf(RawContacts.ACCOUNT_NAME, RawContacts.ACCOUNT_TYPE),
                RawContacts.DELETED + "=0", null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0); val t = c.getString(1)
                    if (n.isNullOrBlank() || t == "com.whatsapp") continue
                    if (seen.add("$n|$t")) out.add(Source(n, t))
                }
            }
        } catch (e: Exception) { }
        try {
            ctx.contentResolver.query(
                ContactsContract.Settings.CONTENT_URI,
                arrayOf(ContactsContract.Settings.ACCOUNT_NAME, ContactsContract.Settings.ACCOUNT_TYPE),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0); val t = c.getString(1)
                    if (n.isNullOrBlank() || t == "com.whatsapp") continue
                    if (seen.add("$n|$t")) out.add(Source(n, t))
                }
            }
        } catch (e: Exception) { }
        try {
            for (a in AccountManager.get(ctx).getAccountsByType("com.google"))
                if (seen.add(a.name + "|" + a.type)) out.add(Source(a.name, a.type))
        } catch (e: Exception) { }
        return out
    }

    private fun nameOp(raw: Long?, first: String, last: String): ContentProviderOperation {
        val b = ContentProviderOperation.newInsert(Data.CONTENT_URI)
        if (raw != null) b.withValue(Data.RAW_CONTACT_ID, raw) else b.withValueBackReference(Data.RAW_CONTACT_ID, 0)
        return b.withValue(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.GIVEN_NAME, first)
            .withValue(StructuredName.FAMILY_NAME, last).build()
    }

    private fun dataOp(raw: Long?, mime: String, e: Entry, typeCol: String = Data.DATA2): ContentProviderOperation {
        val b = ContentProviderOperation.newInsert(Data.CONTENT_URI)
        if (raw != null) b.withValue(Data.RAW_CONTACT_ID, raw) else b.withValueBackReference(Data.RAW_CONTACT_ID, 0)
        b.withValue(Data.MIMETYPE, mime).withValue(Data.DATA1, e.value).withValue(typeCol, e.type)
        if (e.label.isNotBlank()) b.withValue(Data.DATA3, e.label)
        return b.build()
    }

    private fun noteOp(raw: Long?, note: String): ContentProviderOperation {
        val b = ContentProviderOperation.newInsert(Data.CONTENT_URI)
        if (raw != null) b.withValue(Data.RAW_CONTACT_ID, raw) else b.withValueBackReference(Data.RAW_CONTACT_ID, 0)
        return b.withValue(Data.MIMETYPE, Note.CONTENT_ITEM_TYPE).withValue(Note.NOTE, note).build()
    }

    // existing == null: kontak baru di sumber src. Hasil: id kontak, atau -1 jika gagal.
    fun save(
        ctx: Context, existing: ContactFull?, first: String, last: String,
        phones: List<Entry>, emails: List<Entry>, note: String, src: Source?, photo: ByteArray? = null
    ): Long {
        val ops = ArrayList<ContentProviderOperation>()
        val rawId: Long?
        if (existing == null) {
            rawId = null
            ops.add(
                ContentProviderOperation.newInsert(RawContacts.CONTENT_URI)
                    .withValue(RawContacts.ACCOUNT_TYPE, src?.type)
                    .withValue(RawContacts.ACCOUNT_NAME, src?.name).build()
            )
        } else {
            rawId = existing.rawId
            ops.add(
                ContentProviderOperation.newDelete(Data.CONTENT_URI)
                    .withSelection(
                        Data.RAW_CONTACT_ID + "=? AND " + Data.MIMETYPE + " IN (?,?,?,?)",
                        arrayOf(
                            rawId.toString(), StructuredName.CONTENT_ITEM_TYPE, Phone.CONTENT_ITEM_TYPE,
                            Email.CONTENT_ITEM_TYPE, Note.CONTENT_ITEM_TYPE
                        )
                    ).build()
            )
        }
        ops.add(nameOp(rawId, first, last))
        for (p in phones) ops.add(dataOp(rawId, Phone.CONTENT_ITEM_TYPE, p))
        for (m in emails) ops.add(dataOp(rawId, Email.CONTENT_ITEM_TYPE, m))
        if (note.isNotBlank()) ops.add(noteOp(rawId, note))
        if (photo != null) {
            if (rawId != null) ops.add(
                ContentProviderOperation.newDelete(Data.CONTENT_URI)
                    .withSelection(Data.RAW_CONTACT_ID + "=? AND " + Data.MIMETYPE + "=?",
                        arrayOf(rawId.toString(), Photo.CONTENT_ITEM_TYPE)).build()
            )
            val pb = ContentProviderOperation.newInsert(Data.CONTENT_URI)
            if (rawId != null) pb.withValue(Data.RAW_CONTACT_ID, rawId) else pb.withValueBackReference(Data.RAW_CONTACT_ID, 0)
            ops.add(pb.withValue(Data.MIMETYPE, Photo.CONTENT_ITEM_TYPE).withValue(Photo.PHOTO, photo).build())
        }
        return try {
            val res = ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            if (existing != null) existing.id else {
                val raw = ContentUris.parseId(res[0].uri!!)
                var cid = -1L
                ctx.contentResolver.query(
                    RawContacts.CONTENT_URI, arrayOf(RawContacts.CONTACT_ID),
                    RawContacts._ID + "=?", arrayOf(raw.toString()), null
                )?.use { c -> if (c.moveToFirst()) cid = c.getLong(0) }
                cid
            }
        } catch (e: Exception) { -1L }
    }

    fun delete(ctx: Context, contactId: Long): Boolean = try {
        ctx.contentResolver.delete(
            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId), null, null
        ) > 0
    } catch (e: Exception) { false }
}

object Photos {
    private val cache = LruCache<String, Bitmap>(120)

    fun clear() = cache.evictAll()

    fun get(ctx: Context, uri: String?): Bitmap? {
        if (uri.isNullOrEmpty()) return null
        val hit = cache.get(uri)
        if (hit != null) return hit
        try {
            val bmp = ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
            if (bmp != null) cache.put(uri, bmp)
            return bmp
        } catch (e: Exception) { return null }
    }

    // gambar pilihan pengguna -> JPEG maksimal 720 px untuk disimpan sebagai foto kontak
    fun encode(ctx: Context, uri: Uri, max: Int = 720): ByteArray? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= max && bounds.outHeight / (sample * 2) >= max) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val k = max.toFloat() / Math.max(bmp.width, bmp.height)
            val out = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
            val bo = java.io.ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 90, bo)
            return bo.toByteArray()
        } catch (e: Exception) { return null }
    }
}
