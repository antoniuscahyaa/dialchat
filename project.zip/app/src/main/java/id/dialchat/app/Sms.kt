package id.dialchat.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsManager
import android.widget.Toast

object SmsUtil {
    private var counter = 100

    fun flags(mutable: Boolean = false): Int {
        var f = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 31) {
            f = f or (if (mutable) PendingIntent.FLAG_MUTABLE else PendingIntent.FLAG_IMMUTABLE)
        } else if (Build.VERSION.SDK_INT >= 23 && !mutable) {
            f = f or PendingIntent.FLAG_IMMUTABLE
        }
        return f
    }

    fun isDefault(ctx: Context): Boolean = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun threadFor(ctx: Context, address: String): Long =
        try { Telephony.Threads.getOrCreateThreadId(ctx, address) } catch (e: Exception) { -1L }

    fun markRead(ctx: Context, threadId: Long) {
        if (threadId < 0) return
        val v = ContentValues()
        v.put(Telephony.Sms.READ, 1)
        v.put(Telephony.Sms.SEEN, 1)
        try {
            ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString()))
        } catch (e: Exception) { }
    }

    fun setType(ctx: Context, uri: Uri?, type: Int, notType: Int?) {
        if (uri == null) return
        val v = ContentValues()
        v.put(Telephony.Sms.TYPE, type)
        try {
            if (notType != null) ctx.contentResolver.update(uri, v, "type != ?", arrayOf(notType.toString()))
            else ctx.contentResolver.update(uri, v, null, null)
        } catch (e: Exception) { }
    }

    fun send(ctx: Context, address: String, text: String, subId: Int) {
        val v = ContentValues()
        v.put(Telephony.Sms.ADDRESS, address)
        v.put(Telephony.Sms.BODY, text)
        v.put(Telephony.Sms.DATE, System.currentTimeMillis())
        v.put(Telephony.Sms.READ, 1)
        v.put(Telephony.Sms.SEEN, 1)
        v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
        if (subId >= 0) v.put("sub_id", subId)
        val uri: Uri? = try { ctx.contentResolver.insert(Telephony.Sms.CONTENT_URI, v) } catch (e: Exception) { null }
        try {
            val sm = if (subId >= 0 && Build.VERSION.SDK_INT >= 22) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            val sents = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                val si = Intent(ctx, SmsSentReceiver::class.java)
                si.putExtra("uri", uri?.toString())
                si.putExtra("address", address)
                si.putExtra("last", i == parts.size - 1)
                counter++
                sents.add(PendingIntent.getBroadcast(ctx, counter, si, flags()))
            }
            if (parts.size == 1) sm.sendTextMessage(address, null, text, sents[0], null)
            else sm.sendMultipartTextMessage(address, null, parts, sents, null)
        } catch (e: Exception) {
            setType(ctx, uri, Telephony.Sms.MESSAGE_TYPE_FAILED, null)
        }
    }
}

object SmsNotif {
    fun idFor(addr: String): Int = 3000 + (addr.hashCode() and 0xFFFF)

    fun otpCode(body: String): String? {
        if (!Regex("(?i)(otp|kode|code|verifikasi|verification|pin|token|sandi|password)").containsMatchIn(body)) return null
        return Regex("(?<!\\d)\\d{4,8}(?!\\d)").find(body)?.value
    }

    private fun builder(ctx: Context, nm: NotificationManager): Notification.Builder {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("sms", tr("Pesan"), NotificationManager.IMPORTANCE_HIGH))
            return Notification.Builder(ctx, "sms")
        }
        return Notification.Builder(ctx)
    }

    fun show(ctx: Context, addr: String, body: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = idFor(addr)
        val name = CallUtil.name(ctx, addr) ?: addr
        val oi = Intent(ctx, ThreadActivity::class.java).putExtra("address", addr)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val open = PendingIntent.getActivity(ctx, id, oi, SmsUtil.flags())
        val replyPi = PendingIntent.getBroadcast(ctx, id,
            Intent(ctx, SmsActionReceiver::class.java).setAction("reply").putExtra("address", addr), SmsUtil.flags(true))
        val readPi = PendingIntent.getBroadcast(ctx, id + 70000,
            Intent(ctx, SmsActionReceiver::class.java).setAction("read").putExtra("address", addr), SmsUtil.flags())
        val ri = RemoteInput.Builder("reply").setLabel(tr("Balas")).build()
        val a1 = Notification.Action.Builder(R.drawable.ic_bubble, tr("Balas"), replyPi).addRemoteInput(ri).build()
        val a2 = Notification.Action.Builder(R.drawable.ic_bubble, tr("Tandai dibaca"), readPi).build()
        val b = builder(ctx, nm)
        b.setSmallIcon(R.drawable.ic_stat_msg)
        b.setColor(Color.parseColor("#1D4ED8"))
        b.setContentTitle(name)
        b.setContentText(body)
        b.setStyle(Notification.BigTextStyle().bigText(body))
        b.setAutoCancel(true)
        b.setCategory(Notification.CATEGORY_MESSAGE)
        b.setPriority(Notification.PRIORITY_HIGH)
        b.setContentIntent(open)
        val code = otpCode(body)
        if (code != null) {
            val copyPi = PendingIntent.getBroadcast(ctx, id + 80000,
                Intent(ctx, SmsActionReceiver::class.java).setAction("copy").putExtra("address", addr).putExtra("code", code), SmsUtil.flags())
            b.addAction(Notification.Action.Builder(R.drawable.ic_bubble, tr("Salin kode"), copyPi).build())
        } else {
            b.addAction(a1)
        }
        b.addAction(a2)
        nm.notify(id, b.build())
    }

    fun failed(ctx: Context, addr: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val name = CallUtil.name(ctx, addr) ?: addr
        val oi = Intent(ctx, ThreadActivity::class.java).putExtra("address", addr)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val open = PendingIntent.getActivity(ctx, idFor(addr) + 50000, oi, SmsUtil.flags())
        val b = builder(ctx, nm)
        b.setSmallIcon(R.drawable.ic_stat_msg)
        b.setColor(Color.parseColor("#1D4ED8"))
        b.setContentTitle(tr("Pesan gagal terkirim"))
        b.setContentText(tr("Ke %s. Ketuk untuk membuka dan kirim ulang.", name))
        b.setAutoCancel(true)
        b.setContentIntent(open)
        nm.notify(idFor(addr) + 50000, b.build())
    }

    fun simple(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b = builder(ctx, nm)
        b.setSmallIcon(R.drawable.ic_stat_msg)
        b.setColor(Color.parseColor("#1D4ED8"))
        b.setContentTitle(title)
        b.setContentText(text)
        b.setStyle(Notification.BigTextStyle().bigText(text))
        b.setAutoCancel(true)
        nm.notify(4000, b.build())
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs == null || msgs.isEmpty()) return
        val addr = msgs[0].originatingAddress ?: ""
        val body = StringBuilder()
        for (m in msgs) body.append(m.messageBody ?: "")
        val v = ContentValues()
        v.put(Telephony.Sms.ADDRESS, addr)
        v.put(Telephony.Sms.BODY, body.toString())
        v.put(Telephony.Sms.DATE, System.currentTimeMillis())
        v.put(Telephony.Sms.DATE_SENT, msgs[0].timestampMillis)
        val blocked = try {
            Build.VERSION.SDK_INT >= 24 && android.provider.BlockedNumberContract.isBlocked(ctx, addr)
        } catch (e: Exception) { false }
        v.put(Telephony.Sms.READ, if (blocked) 1 else 0)
        v.put(Telephony.Sms.SEEN, if (blocked) 1 else 0)
        val sub = intent.getIntExtra("subscription", -1)
        if (sub >= 0) v.put("sub_id", sub)
        try { ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) } catch (e: Exception) { }
        if (!blocked) SmsNotif.show(ctx, addr, body.toString())
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        SmsNotif.simple(ctx, tr("Pesan multimedia (MMS)"), tr("Ada MMS masuk, tetapi DialChat belum mendukung MMS."))
    }
}

class SmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val u = intent.getStringExtra("uri") ?: return
        val uri = Uri.parse(u)
        if (resultCode != Activity.RESULT_OK) {
            SmsUtil.setType(ctx, uri, Telephony.Sms.MESSAGE_TYPE_FAILED, null)
            val ad = intent.getStringExtra("address")
            if (ad != null) SmsNotif.failed(ctx, ad)
        } else if (intent.getBooleanExtra("last", false)) {
            SmsUtil.setType(ctx, uri, Telephony.Sms.MESSAGE_TYPE_SENT, Telephony.Sms.MESSAGE_TYPE_FAILED)
        }
    }
}

class SmsActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val addr = intent.getStringExtra("address") ?: return
        if (intent.action == "copy") {
            val code = intent.getStringExtra("code") ?: ""
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(tr("Kode OTP"), code))
            Toast.makeText(ctx, tr("Kode %s disalin", code), Toast.LENGTH_SHORT).show()
            return
        }
        if (intent.action == "reply") {
            val t = RemoteInput.getResultsFromIntent(intent)?.getCharSequence("reply")?.toString()
            if (!t.isNullOrBlank()) SmsUtil.send(ctx, addr, t.trim(), -1)
        }
        SmsUtil.markRead(ctx, SmsUtil.threadFor(ctx, addr))
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(SmsNotif.idFor(addr))
    }
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val t = intent?.getStringExtra(Intent.EXTRA_TEXT)
        val a = intent?.data?.schemeSpecificPart
        if (!t.isNullOrBlank() && !a.isNullOrBlank()) SmsUtil.send(this, a, t, -1)
        stopSelf()
        return START_NOT_STICKY
    }
}
