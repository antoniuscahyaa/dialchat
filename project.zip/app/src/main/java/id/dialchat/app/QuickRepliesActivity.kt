package id.dialchat.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class QuickRepliesActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val SURF by lazy { col(R.color.surf) }
    private val BG by lazy { col(R.color.bg) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val fields = ArrayList<EditText>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdr = LinearLayout(this)
        hdr.gravity = Gravity.CENTER_VERTICAL
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = cornerBg(gd, BG)
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr(R.string.s_kembali)
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        hdr.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = tr(R.string.s_pesan_cepat); t.textSize = 26f; t.setTextColor(Color.WHITE); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(12), 0, 0, 0)
        hdr.addView(t)
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(16), dp(20), dp(16))
        val d = TextView(this)
        d.text = tr(R.string.s_template_ini_muncul_saat_menolak_p)
        d.textSize = 14f; d.setTextColor(MUTED)
        col.addView(d)
        val cur = Prefs.templates(this)
        for (i in 0 until 5) {
            val e = EditText(this)
            e.hint = tr(R.string.s_template) + (i + 1)
            e.textSize = 15f
            e.background = rr(SURF, 16)
            e.setPadding(dp(16), dp(12), dp(16), dp(12))
            if (i < cur.size) e.setText(cur[i])
            val p = LinearLayout.LayoutParams(MATCH, WRAP)
            p.topMargin = dp(10)
            col.addView(e, p)
            fields.add(e)
        }
        sv.addView(col)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = simpleCollapse(hdr, back, t, 26f, 20f, 112, 64)
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val save = TextView(this)
        save.text = tr(R.string.s_simpan); save.textSize = 17f; save.setTextColor(Color.WHITE); save.setTypeface(null, Typeface.BOLD)
        save.gravity = Gravity.CENTER; save.background = rr(BLUE, 28); save.isClickable = true
        save.setOnClickListener {
            Prefs.setTemplates(this, fields.map { it.text.toString() })
            Toast.makeText(this, tr(R.string.s_template_tersimpan), Toast.LENGTH_SHORT).show()
            finish()
        }
        val sp = LinearLayout.LayoutParams(MATCH, dp(56))
        sp.setMargins(dp(20), dp(8), dp(20), dp(20))
        root.addView(save, sp)
        setContentView(root)
    }
}
