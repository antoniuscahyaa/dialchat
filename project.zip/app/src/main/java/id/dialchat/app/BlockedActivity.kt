package id.dialchat.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class BlockedActivity : BaseActivity() {
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val RED = Color.parseColor("#B42318")
    private val SURF by lazy { col(R.color.surf) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val blk = LinearLayout(this)
        blk.orientation = LinearLayout.VERTICAL
        blk.setBackgroundColor(BG)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), dp(16), dp(8), dp(8))
        val back = FrameLayout(this)
        back.contentDescription = tr(R.string.s_kembali)
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, INK, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        head.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val t = TextView(this)
        t.text = tr(R.string.s_nomor_diblokir); t.textSize = 22f; t.setTextColor(INK); t.setTypeface(null, Typeface.BOLD)
        head.addView(t)
        blk.addView(head)
        val sub = TextView(this)
        sub.text = tr(R.string.s_panggilan_dari_nomor_ini_ditolak_o)
        sub.textSize = 14f; sub.setTextColor(MUTED); sub.setPadding(dp(16), dp(4), dp(16), dp(12))
        blk.addView(sub)
        val br = LinearLayout(this)
        br.setPadding(dp(16), 0, dp(16), dp(8))
        br.addView(actionBtn(tr(R.string.s_ekspor)) { doExport() })
        br.addView(actionBtn(tr(R.string.s_impor)) { doImport() })
        blk.addView(br)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(list)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val wSpec = View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels, View.MeasureSpec.EXACTLY)
        val hSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        blk.measure(wSpec, hSpec)
        sub.measure(wSpec, hSpec)
        val expPx = blk.measuredHeight
        val subPx = sub.measuredHeight
        val subLp = sub.layoutParams
        val hc = Collapse(blk, expPx, expPx - subPx - dp(10)) { p ->
            head.setPadding(dp(8), lerpI(dp(16), dp(6), p), dp(8), dp(8))
            t.setTextDp(lerpF(22f, 19f, p))
            sub.alpha = (1f - p * 1.6f).coerceIn(0f, 1f)
            val sh = lerpI(subPx, 0, p)
            if (subLp.height != sh) { subLp.height = sh; sub.layoutParams = subLp }
        }
        area.addView(blk, FrameLayout.LayoutParams(MATCH, expPx))
        sv.setPadding(0, expPx, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        load()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) load()
    }

    private fun actionBtn(label: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label; v.textSize = 14f; v.setTextColor(INK); v.setTypeface(null, Typeface.BOLD)
        v.gravity = Gravity.CENTER; v.background = rr(SURF, 20); v.setPadding(dp(20), 0, dp(20), 0)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40))
        p.marginEnd = dp(8)
        v.layoutParams = p
        return v
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun queryNumbers(): List<String> {
        val nums = ArrayList<String>()
        contentResolver.query(
            BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
        )?.use { c -> while (c.moveToNext()) nums.add(c.getString(0) ?: "") }
        return nums
    }

    private fun doExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TITLE, "dialchat-blokir.txt")
        try { startActivityForResult(i, 41) } catch (e: Exception) { toast(tr(R.string.s_tidak_bisa_membuka_pemilih_file)) }
    }

    private fun doImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        try { startActivityForResult(i, 42) } catch (e: Exception) { toast(tr(R.string.s_tidak_bisa_membuka_pemilih_file)) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        if (requestCode == 41) {
            try {
                val nums = queryNumbers()
                contentResolver.openOutputStream(u)?.use { it.write(nums.joinToString("\n").toByteArray()) }
                toast(tr(R.string.s_nomor_diekspor, nums.size))
            } catch (e: Exception) { toast(tr(R.string.s_gagal_mengekspor_pastikan_dialchat)) }
        } else if (requestCode == 42) {
            try {
                val lines = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                var n = 0
                for (l in lines.map { it.trim() }.filter { it.isNotEmpty() }) {
                    try {
                        val v = ContentValues()
                        v.put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, l)
                        contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v)
                        n++
                    } catch (e: Exception) { }
                }
                toast(tr(R.string.s_nomor_diimpor, n))
                load()
            } catch (e: Exception) { toast(tr(R.string.s_gagal_mengimpor)) }
        }
    }

    private fun msg(t: String) {
        val v = TextView(this)
        v.text = t; v.textSize = 15f; v.setTextColor(MUTED)
        v.setPadding(dp(16), dp(24), dp(16), dp(24))
        list.addView(v)
    }

    private fun load() {
        list.removeAllViews()
        val nums = ArrayList<String>()
        try {
            contentResolver.query(
                BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
            )?.use { c -> while (c.moveToNext()) nums.add(c.getString(0) ?: "") }
        } catch (e: Exception) {
            msg(tr(R.string.s_jadikan_dialchat_aplikasi_telepon))
            return
        }
        if (nums.isEmpty()) { msg(tr(R.string.s_belum_ada_nomor_yang_diblokir)); return }
        for (n in nums) list.addView(row(n))
    }

    private fun row(n: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(12))
        val c = FrameLayout(this)
        c.background = ov(RED)
        val ic = icon(R.drawable.ic_block, Color.WHITE, 22)
        ic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        c.addView(ic)
        r.addView(c, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = prettyNum(n); t.textSize = 16f; t.setTextColor(INK)
        val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tp.marginStart = dp(12)
        r.addView(t, tp)
        val u = TextView(this)
        u.text = tr(R.string.s_buka_blokir); u.textSize = 14f; u.setTextColor(INK); u.setTypeface(null, Typeface.BOLD)
        u.gravity = Gravity.CENTER; u.background = rr(SURF, 20); u.setPadding(dp(16), 0, dp(16), 0)
        u.isClickable = true
        u.setOnClickListener {
            try { BlockedNumberContract.unblock(this, n) } catch (e: Exception) { }
            load()
        }
        r.addView(u, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        return r
    }
}
