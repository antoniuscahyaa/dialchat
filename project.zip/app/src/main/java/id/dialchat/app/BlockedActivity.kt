package id.dialchat.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class BlockedActivity : Activity() {
    private val INK = Color.parseColor("#14181F")
    private val MUTED = Color.parseColor("#5B6472")
    private val RED = Color.parseColor("#B42318")
    private val SURF = Color.parseColor("#F3F4F7")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), dp(16), dp(8), dp(8))
        val back = FrameLayout(this)
        back.contentDescription = "Kembali"
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, INK, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        head.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val t = TextView(this)
        t.text = "Nomor diblokir"; t.textSize = 22f; t.setTextColor(INK); t.setTypeface(null, Typeface.BOLD)
        head.addView(t)
        root.addView(head)
        val sub = TextView(this)
        sub.text = "Panggilan dari nomor ini ditolak otomatis dan tidak berdering."
        sub.textSize = 14f; sub.setTextColor(MUTED); sub.setPadding(dp(16), dp(4), dp(16), dp(12))
        root.addView(sub)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        load()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) load()
    }

    private fun msg(t: String) {
        val v = TextView(this)
        v.text = t; v.textSize = 15f; v.setTextColor(MUTED)
        v.setPadding(dp(16), dp(24), dp(16), dp(24))
        list.addView(v)
    }

    private fun load() {
        list.removeAllViews()
        val nums = ArrayList<String>()
        try {
            contentResolver.query(
                BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
            )?.use { c -> while (c.moveToNext()) nums.add(c.getString(0) ?: "") }
        } catch (e: Exception) {
            msg("Jadikan DialChat aplikasi telepon utama untuk melihat dan mengelola daftar blokir.")
            return
        }
        if (nums.isEmpty()) { msg("Belum ada nomor yang diblokir."); return }
        for (n in nums) list.addView(row(n))
    }

    private fun row(n: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(12))
        val c = FrameLayout(this)
        c.background = ov(RED)
        val ic = icon(R.drawable.ic_block, Color.WHITE, 22)
        ic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        c.addView(ic)
        r.addView(c, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = prettyNum(n); t.textSize = 16f; t.setTextColor(INK)
        val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tp.marginStart = dp(12)
        r.addView(t, tp)
        val u = TextView(this)
        u.text = "Buka blokir"; u.textSize = 14f; u.setTextColor(INK); u.setTypeface(null, Typeface.BOLD)
        u.gravity = Gravity.CENTER; u.background = rr(SURF, 20); u.setPadding(dp(16), 0, dp(16), 0)
        u.isClickable = true
        u.setOnClickListener {
            try { BlockedNumberContract.unblock(this, n) } catch (e: Exception) { }
            load()
        }
        r.addView(u, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        return r
    }
}
