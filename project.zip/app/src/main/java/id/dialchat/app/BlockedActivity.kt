package id.dialchat.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class BlockedActivity : BaseActivity() {
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val RED = Color.parseColor("#B42318")
    private val SURF by lazy { col(R.color.surf) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), dp(16), dp(8), dp(8))
        val back = FrameLayout(this)
        back.contentDescription = "Kembali"
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, INK, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        head.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val t = TextView(this)
        t.text = "Nomor diblokir"; t.textSize = 22f; t.setTextColor(INK); t.setTypeface(null, Typeface.BOLD)
        head.addView(t)
        root.addView(head)
        val sub = TextView(this)
        sub.text = "Panggilan dari nomor ini ditolak otomatis dan tidak berdering."
        sub.textSize = 14f; sub.setTextColor(MUTED); sub.setPadding(dp(16), dp(4), dp(16), dp(12))
        root.addView(sub)
        val br = LinearLayout(this)
        br.setPadding(dp(16), 0, dp(16), dp(8))
        br.addView(actionBtn("Ekspor") { doExport() })
        br.addView(actionBtn("Impor") { doImport() })
        root.addView(br)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        load()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) load()
    }

    private fun actionBtn(label: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label; v.textSize = 14f; v.setTextColor(INK); v.setTypeface(null, Typeface.BOLD)
        v.gravity = Gravity.CENTER; v.background = rr(SURF, 20); v.setPadding(dp(20), 0, dp(20), 0)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40))
        p.marginEnd = dp(8)
        v.layoutParams = p
        return v
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun queryNumbers(): List<String> {
        val nums = ArrayList<String>()
        contentResolver.query(
            BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
        )?.use { c -> while (c.moveToNext()) nums.add(c.getString(0) ?: "") }
        return nums
    }

    private fun doExport() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TITLE, "dialchat-blokir.txt")
        try { startActivityForResult(i, 41) } catch (e: Exception) { toast("Tidak bisa membuka pemilih file") }
    }

    private fun doImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        try { startActivityForResult(i, 42) } catch (e: Exception) { toast("Tidak bisa membuka pemilih file") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        if (requestCode == 41) {
            try {
                val nums = queryNumbers()
                contentResolver.openOutputStream(u)?.use { it.write(nums.joinToString("\n").toByteArray()) }
                toast(nums.size.toString() + " nomor diekspor")
            } catch (e: Exception) { toast("Gagal mengekspor. Pastikan DialChat jadi aplikasi telepon utama.") }
        } else if (requestCode == 42) {
            try {
                val lines = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                var n = 0
                for (l in lines.map { it.trim() }.filter { it.isNotEmpty() }) {
                    try {
                        val v = ContentValues()
                        v.put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, l)
                        contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v)
                        n++
                    } catch (e: Exception) { }
                }
                toast(n.toString() + " nomor diimpor")
                load()
            } catch (e: Exception) { toast("Gagal mengimpor") }
        }
    }

    private fun msg(t: String) {
        val v = TextView(this)
        v.text = t; v.textSize = 15f; v.setTextColor(MUTED)
        v.setPadding(dp(16), dp(24), dp(16), dp(24))
        list.addView(v)
    }

    private fun load() {
        list.removeAllViews()
        val nums = ArrayList<String>()
        try {
            contentResolver.query(
                BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
            )?.use { c -> while (c.moveToNext()) nums.add(c.getString(0) ?: "") }
        } catch (e: Exception) {
            msg("Jadikan DialChat aplikasi telepon utama untuk melihat dan mengelola daftar blokir.")
            return
        }
        if (nums.isEmpty()) { msg("Belum ada nomor yang diblokir."); return }
        for (n in nums) list.addView(row(n))
    }

    private fun row(n: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(12))
        val c = FrameLayout(this)
        c.background = ov(RED)
        val ic = icon(R.drawable.ic_block, Color.WHITE, 22)
        ic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        c.addView(ic)
        r.addView(c, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = prettyNum(n); t.textSize = 16f; t.setTextColor(INK)
        val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tp.marginStart = dp(12)
        r.addView(t, tp)
        val u = TextView(this)
        u.text = "Buka blokir"; u.textSize = 14f; u.setTextColor(INK); u.setTypeface(null, Typeface.BOLD)
        u.gravity = Gravity.CENTER; u.background = rr(SURF, 20); u.setPadding(dp(16), 0, dp(16), 0)
        u.isClickable = true
        u.setOnClickListener {
            try { BlockedNumberContract.unblock(this, n) } catch (e: Exception) { }
            load()
        }
        r.addView(u, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        return r
    }
}
