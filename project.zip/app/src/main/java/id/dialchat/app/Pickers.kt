package id.dialchat.app

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast

/** Dialog pilih kontak dengan kolom cari. Daftar kontak dimuat di thread latar. */
fun Activity.pickContact(title: String, onPick: (name: String, number: String) -> Unit) {
    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(this, tr(R.string.s_izin_kontak_belum_diberikan), Toast.LENGTH_SHORT).show()
        return
    }
    Bg.load({ ContactsRepo.list(this) }) { res ->
        if (res == null || isFinishing) return@load
        val all = res.filter { it.number.isNotBlank() }.sortedBy { it.name.lowercase() }
        val shown = ArrayList<ContactItem>()
        val labels = ArrayList<String>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        fun refresh(q: String) {
            val s = q.trim()
            shown.clear()
            shown.addAll(all.filter { s.isEmpty() || it.name.contains(s, ignoreCase = true) || it.number.contains(s) }.take(300))
            labels.clear()
            for (c in shown) labels.add(if (c.name.isBlank()) c.number else c.name + " · " + c.number)
            adapter.notifyDataSetChanged()
        }
        refresh("")
        val et = EditText(this)
        et.setSingleLine(); et.hint = tr(R.string.s_cari)
        val lv = ListView(this)
        lv.adapter = adapter
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (360 * resources.displayMetrics.density).toInt()))
        val d = AlertDialog.Builder(this).setTitle(title).setView(box)
            .setNegativeButton(tr(R.string.s_batal), null).create()
        lv.setOnItemClickListener { _, _, i, _ ->
            val c = shown[i]
            d.dismiss()
            onPick(if (c.name.isBlank()) c.number else c.name, c.number)
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { refresh(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        d.show()
    }
}
