package id.dialchat.app

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import java.util.Locale

/** Bahasa aplikasi (lihat Prefs.lang): 0 = ikut sistem, 1 = Indonesia, 2 = English. */
object L {
    @Volatile var en: Boolean = false
    private var app: Context? = null
    private var r: Resources? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        apply(Prefs.lang(ctx))
    }

    val loc: Locale get() = if (en) Locale.ENGLISH else Locale("id")

    /** 0 = ikut sistem (Indonesia bila bahasa HP Indonesia, selain itu English), 1 = Indonesia, 2 = English. */
    fun apply(mode: Int) {
        en = when (mode) {
            1 -> false
            2 -> true
            else -> Locale.getDefault().language.let { it != "in" && it != "id" }
        }
        val a = app ?: return
        val cfg = Configuration(a.resources.configuration)
        cfg.setLocale(loc)
        r = a.createConfigurationContext(cfg).resources
    }

    fun res(): Resources = r ?: app!!.resources
}

/** Teks dari res/values (Indonesia) atau res/values-en (English) sesuai bahasa pilihan. */
fun tr(id: Int): String = L.res().getString(id)

/** Sama seperti tr(id), lalu isi placeholder (%1$d, %1$s, ...) dengan args. */
fun tr(id: Int, vararg a: Any?): String = L.res().getString(id, *a)
