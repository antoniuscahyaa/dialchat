package id.dialchat.app

import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.Executors

/** Catat error yang sengaja tidak ditampilkan ke pengguna, supaya masih bisa dilacak lewat logcat. */
fun logW(where: String, e: Throwable) {
    Log.w("DialChat", where, e)
}

/**
 * Menjalankan kerja berat (query ContentProvider, dll.) di thread latar lalu mengirim hasilnya ke main thread.
 * `done` menerima null bila pekerjaannya gagal (errornya sudah dicatat), jadi pemanggil bisa melepas status "sedang memuat".
 */
object Bg {
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun <T : Any> load(work: () -> T, done: (T?) -> Unit) {
        pool.execute {
            val r: T? = try { work() } catch (e: Throwable) { logW("Bg", e); null }
            main.post { done(r) }
        }
    }
}
