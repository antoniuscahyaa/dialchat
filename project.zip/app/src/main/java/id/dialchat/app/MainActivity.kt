package id.dialchat.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.role.RoleManager
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.Window
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.MotionEvent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.Telephony
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Row(
    val header: String? = null, val title: String = "", val sub: String = "",
    val number: String = "", val missed: Boolean = false, val arrow: Int = 0, val save: Boolean = false,
    val cid: Long = 0, val photo: String? = null
)

class MainActivity : BaseActivity() {
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINK by lazy { col(R.color.link) }
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val SURF by lazy { col(R.color.surf) }
    private val LINE by lazy { col(R.color.line) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val num = StringBuilder()
    private lateinit var numTv: TextView
    private lateinit var waBtn: LinearLayout
    private lateinit var waLabelTv: TextView
    private lateinit var waNumTv: TextView
    private lateinit var waIcon: ImageView
    private lateinit var saveTv: TextView
    private lateinit var pasteChip: TextView
    private lateinit var roleBar: TextView
    private lateinit var msgPane: MessagesPane
    private lateinit var favRow: LinearLayout
    private lateinit var favScroll: HorizontalScrollView
    private val PAL by lazy { intArrayOf(BLUE, GREEN, Color.parseColor("#6D28D9"), Color.parseColor("#B45309"), RED) }
    private lateinit var sugBox: LinearLayout
    private lateinit var panes: List<View>
    private val tabPills = ArrayList<FrameLayout>()
    private val tabIcons = ArrayList<ImageView>()
    private val tabLbls = ArrayList<TextView>()
    private lateinit var histList: ListView
    private lateinit var contList: ListView
    private lateinit var chipAll: TextView
    private lateinit var chipMiss: TextView
    private lateinit var searchEt: EditText
    private var missedOnly = false
    private var curTab = 0
    private var people = listOf<ContactItem>()
    private var peopleLoaded = false
    private var srcFilter: String? = null
    private var srcFilterLabel = tr("Semua kontak")
    private lateinit var filterTv: TextView

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun rr(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun ov(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    fun has(p: String) = Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun digits(s: String) = s.filter { it.isDigit() }

    private fun icon(res: Int, color: Int, size: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(color, PorterDuff.Mode.SRC_IN)
        layoutParams = lp(dp(size), dp(size))
    }
    private fun tinted(res: Int, color: Int, size: Int) = getDrawable(res)!!.mutate().apply {
        setColorFilter(color, PorterDuff.Mode.SRC_IN); setBounds(0, 0, dp(size), dp(size))
    }
    private fun circleBtn(res: Int, bg: Int, fg: Int, size: Int, desc: String, ms: Int = 0, enabled: Boolean = true, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.background = ov(bg); f.contentDescription = desc; f.isEnabled = enabled
        val i = icon(res, fg, 20)
        i.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        f.addView(i)
        if (enabled) { f.isClickable = true; f.setOnClickListener { onClick() } }
        f.layoutParams = lp(dp(size), dp(size)).apply { marginStart = dp(ms) }
        return f
    }
    private fun pillBtn(res: Int, label: String, bg: Int, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER; l.background = rr(bg, 28); l.isClickable = true
        l.setOnClickListener { onClick() }
        l.addView(icon(res, Color.WHITE, 20))
        l.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
        })
        l.layoutParams = lp(0, dp(56), 1f).apply { marginEnd = dp(10) }
        return l
    }

    // ---------- nomor ----------
    private fun normalizeWa(raw: String): String? {
        val t = raw.trim(); val d = digits(t)
        if (d.isEmpty()) return null
        val r = when {
            t.startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("62") -> d
            d.startsWith("08") -> "62" + d.drop(1)
            d.startsWith("8") -> "62$d"
            else -> return null
        }
        if (r.startsWith("62")) return if (r.startsWith("628") && r.length in 10..15) r else null
        return if (r.length in 8..15) r else null
    }
    private fun fmtWa(r: String): String =
        if (r.startsWith("62")) { val x = r.drop(2); "+62 " + x.take(3) + " " + x.drop(3).chunked(4).joinToString(" ") } else "+$r"
    private fun pretty(s: String) = if (s.length > 4 && s.all { it.isDigit() }) s.chunked(4).joinToString(" ") else s

    // ---------- aksi ----------
    private fun openWa(raw: String) {
        val w = normalizeWa(raw)
        if (w == null) { toast(tr("Nomor tidak valid untuk WhatsApp")); return }
        val uri = Uri.parse("https://wa.me/$w")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return }
            catch (e: ActivityNotFoundException) { }
        }
        toast(tr("WhatsApp tidak terpasang"))
    }
    // kode rahasia *#*#kode#*#* dikirim dialer sebagai broadcast, bukan sebagai panggilan
    private fun sendSecretCode(code: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                (getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).sendDialerSpecialCode(code)
            } else {
                sendBroadcast(Intent("android.provider.Telephony.SECRET_CODE", Uri.parse("android_secret_code://$code")))
            }
        } catch (e: SecurityException) {
            toast(tr("Jadikan aplikasi ini Telepon default dulu"))
        } catch (e: Exception) { toast("Kode gagal: " + e.javaClass.simpleName) }
    }
    private fun callNum(raw: String) {
        if (raw.isBlank()) { toast(tr("Ketik nomor dulu")); return }
        val secret = secretRe.matchEntire(raw.trim())
        if (secret != null) { sendSecretCode(secret.groupValues[1]); return }
        val accs = simAccounts()
        if (accs.size > 1) showSimSheet(raw, accs) else placeCall(raw, null)
    }
    private fun simAccounts(): List<PhoneAccountHandle> = try {
        if (has(Manifest.permission.READ_PHONE_STATE))
            (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).callCapablePhoneAccounts
        else emptyList()
    } catch (e: Exception) { emptyList() }
    private fun placeCall(raw: String, acc: PhoneAccountHandle?) {
        val u = Uri.parse("tel:" + Uri.encode(raw))
        val i = if (has(Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, u) else Intent(Intent.ACTION_DIAL, u)
        if (acc != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, acc)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }
    private fun showSimSheet(raw: String, accs: List<PhoneAccountHandle>) {
        val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(24))
        val r = dp(28).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BG)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        box.background = bg
        val t1 = TextView(this)
        t1.text = tr("Telepon dengan SIM mana?"); t1.textSize = 22f; t1.setTextColor(INK); t1.setTypeface(null, Typeface.BOLD)
        box.addView(t1)
        val t2 = TextView(this)
        t2.text = raw; t2.textSize = 14f; t2.setTextColor(MUTED); t2.setPadding(0, dp(4), 0, dp(6))
        box.addView(t2)
        accs.forEachIndexed { i, acc ->
            val label = try { tm.getPhoneAccount(acc)?.label?.toString() ?: "" } catch (e: Exception) { "" }
            val col = if (i % 2 == 0) BLUE else GREEN
            val card = LinearLayout(this)
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(18), 0, dp(18), 0)
            card.background = rr(col, 20)
            card.isClickable = true
            card.setOnClickListener { d.dismiss(); placeCall(raw, acc) }
            val badge = TextView(this)
            badge.text = (i + 1).toString(); badge.textSize = 20f; badge.gravity = Gravity.CENTER
            badge.setTextColor(col); badge.setTypeface(null, Typeface.BOLD); badge.background = ov(Color.WHITE)
            card.addView(badge, lp(dp(44), dp(44)))
            val mid = LinearLayout(this)
            mid.orientation = LinearLayout.VERTICAL
            val a = TextView(this)
            a.text = "SIM " + (i + 1); a.textSize = 18f; a.setTextColor(Color.WHITE); a.setTypeface(null, Typeface.BOLD)
            mid.addView(a)
            val b2 = TextView(this)
            b2.text = label; b2.textSize = 13f; b2.setTextColor(Color.WHITE)
            mid.addView(b2)
            val mp = lp(0, WRAP, 1f)
            mp.marginStart = dp(14)
            card.addView(mid, mp)
            card.addView(icon(R.drawable.ic_phone, Color.WHITE, 26))
            val cp = lp(MATCH, dp(76))
            cp.topMargin = dp(12)
            box.addView(card, cp)
        }
        val cancel = TextView(this)
        cancel.text = tr("Batal"); cancel.textSize = 15f; cancel.setTextColor(MUTED); cancel.gravity = Gravity.CENTER
        cancel.setOnClickListener { d.dismiss() }
        val cl = lp(MATCH, dp(48))
        cl.topMargin = dp(8)
        box.addView(cancel, cl)
        d.setContentView(box)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setDimAmount(0.55f)
        }
        d.show()
    }
    private fun blockNumber(n: String) {
        try {
            if (Build.VERSION.SDK_INT < 24 || !BlockedNumberContract.canCurrentUserBlockNumbers(this)) {
                toast(tr("Jadikan DialChat aplikasi telepon utama dulu untuk memblokir nomor")); return
            }
            val v = ContentValues()
            v.put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n)
            contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v)
            toast(tr("Nomor diblokir"))
        } catch (e: Exception) { toast(tr("Gagal memblokir nomor")) }
    }
    private fun showActions(r: Row, del: (() -> Unit)? = null) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(24))
        val rad = dp(28).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BG)
        bg.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
        box.background = bg
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val f = r.title.firstOrNull()
        val av = TextView(this)
        av.text = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
        av.gravity = Gravity.CENTER; av.textSize = 20f; av.setTextColor(MUTED); av.background = ov(SURF)
        head.addView(av, lp(dp(48), dp(48)))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        val n1 = TextView(this)
        n1.text = r.title; n1.textSize = 18f; n1.setTextColor(INK); n1.setTypeface(null, Typeface.BOLD)
        val n2 = TextView(this)
        n2.text = r.number; n2.textSize = 14f; n2.setTextColor(MUTED)
        ht.addView(n1); ht.addView(n2)
        val hp = lp(0, WRAP, 1f)
        hp.marginStart = dp(14)
        head.addView(ht, hp)
        box.addView(head)
        val line = View(this)
        line.setBackgroundColor(LINE)
        val lpl = lp(MATCH, dp(1))
        lpl.setMargins(0, dp(12), 0, dp(8))
        box.addView(line, lpl)
        fun item(col: Int, res: Int, label: String, lc: Int, onClick: () -> Unit) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(10), dp(4), dp(10))
            row.isClickable = true
            row.setOnClickListener { d.dismiss(); onClick() }
            val c = FrameLayout(this)
            c.background = ov(col)
            val ic = icon(res, Color.WHITE, 22)
            ic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
            c.addView(ic)
            row.addView(c, lp(dp(44), dp(44)))
            val tv = TextView(this)
            tv.text = label; tv.textSize = 17f; tv.setTextColor(lc)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = dp(16)
            row.addView(tv, tp)
            box.addView(row, lp(MATCH, WRAP))
        }
        item(BLUE, R.drawable.ic_phone, tr("Telepon"), INK) { callNum(r.number) }
        if (normalizeWa(r.number) != null) item(GREEN, R.drawable.ic_wa, tr("Chat WhatsApp"), INK) { openWa(r.number) }
        if (r.save) item(BLUE, R.drawable.ic_userplus, tr("Simpan kontak"), INK) { saveContact(r.number) }
        if (del != null) item(RED, R.drawable.ic_delete, tr("Hapus percakapan"), RED) { del() }
        if (!r.save && r.title.isNotBlank() && r.number.any { it.isDigit() }) {
            val fav = Prefs.isFav(this, r.number)
            item(Color.parseColor("#B45309"), R.drawable.ic_star, if (fav) tr("Hapus dari favorit") else tr("Favoritkan"), INK) {
                Prefs.toggleFav(this, r.title, r.number)
                renderFavs()
                toast(if (fav) tr("Dihapus dari favorit") else tr("Ditambahkan ke favorit"))
            }
        }
        item(RED, R.drawable.ic_block, tr("Blokir nomor"), RED) { blockNumber(r.number) }
        d.setContentView(box)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setDimAmount(0.55f)
        }
        d.show()
    }
    private fun buildMessages(): View {
        msgPane = MessagesPane(this)
        return msgPane
    }
    fun requestSmsRole() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 78)
                    return
                }
            }
            val i = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            i.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            startActivityForResult(i, 78)
        } catch (e: Exception) { toast(tr("Tidak bisa membuka pengaturan aplikasi SMS")) }
    }
    fun showThreadActions(t: Thr) {
        val nm = CallUtil.name(this, t.address)
        val r = Row(title = nm ?: t.address, number = t.address, save = nm == null && t.address.any { it.isDigit() })
        showActions(r) { confirmDeleteThread(t) }
    }
    private fun confirmDeleteThread(t: Thr) {
        AlertDialog.Builder(this)
            .setMessage(tr("Hapus seluruh percakapan ini?"))
            .setPositiveButton(tr("Hapus")) { _, _ ->
                try {
                    contentResolver.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(t.id.toString()))
                } catch (e: Exception) { toast(tr("Gagal menghapus percakapan")) }
                msgPane.refresh()
            }
            .setNegativeButton(tr("Batal"), null)
            .show()
    }
    private fun isDefaultDialer(): Boolean = try {
        (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == packageName
    } catch (e: Exception) { false }
    private fun refreshRole() {
        if (!::roleBar.isInitialized) return
        roleBar.visibility = if (isDefaultDialer()) View.GONE else View.VISIBLE
    }
    private fun requestDefaultDialer() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 77)
                    return
                }
            }
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 77)
        } catch (e: Exception) { toast(tr("Tidak bisa membuka pengaturan aplikasi telepon")) }
    }
    override fun onResume() {
        super.onResume()
        refreshRole()
        Photos.clear()
        peopleLoaded = false
        if (curTab == 2) loadContacts()
        if (curTab == 3 && ::msgPane.isInitialized) msgPane.refresh()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (resultCode == RESULT_OK && u != null) {
            if (requestCode == 31) importVcf(u) else if (requestCode == 32) exportVcf(u)
        }
        refreshRole()
        if (::msgPane.isInitialized) msgPane.refresh()
    }
    private fun callVoicemail() {
        if (!has(Manifest.permission.CALL_PHONE)) { toast(tr("Izin telepon diperlukan")); return }
        try { startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("voicemail", "", null))) }
        catch (e: Exception) { toast(tr("Pesan suara tidak tersedia")) }
    }
    private fun pickSource() {
        val srcs = ContactsRepo.sources(this)
        val labels = (listOf(tr("Semua kontak")) + srcs.map { it.label }).toTypedArray()
        AlertDialog.Builder(this).setItems(labels) { _, i ->
            if (i == 0) { srcFilter = null; srcFilterLabel = tr("Semua kontak") }
            else { srcFilter = srcs[i - 1].key; srcFilterLabel = srcs[i - 1].label }
            renderContacts(searchEt.text.toString())
        }.show()
    }
    private fun showContactMenu() {
        AlertDialog.Builder(this).setItems(arrayOf(tr("Impor dari file .vcf"), tr("Ekspor semua kontak (.vcf)"))) { _, i ->
            try {
                if (i == 0) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 31)
                else startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/x-vcard").putExtra(Intent.EXTRA_TITLE, "kontak.vcf"), 32)
            } catch (e: Exception) { toast(tr("Pemilih file tidak ditemukan")) }
        }.show()
    }
    private fun importVcf(uri: Uri) {
        if (!has(Manifest.permission.WRITE_CONTACTS)) { toast(tr("Izin kontak diperlukan")); return }
        toast(tr("Membaca file…"))
        Thread {
            val cards = try {
                val text = contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
                Vcf.parse(text)
            } catch (e: Exception) { emptyList<Card>() }
            runOnUiThread {
                if (cards.isEmpty()) { toast(tr("Tidak ada kontak di file ini")); return@runOnUiThread }
                val srcs = ContactsRepo.sources(this)
                val labels = srcs.map { it.label }.toTypedArray()
                AlertDialog.Builder(this).setTitle(tr("Simpan %d kontak ke", cards.size))
                    .setItems(labels) { _, i -> runImport(cards, srcs[i]) }
                    .setNegativeButton(tr("Batal"), null).show()
            }
        }.start()
    }
    private fun runImport(cards: List<Card>, src: Source) {
        toast(tr("Mengimpor %d kontak…", cards.size))
        Thread {
            val have = HashSet<String>()
            for (c in ContactsRepo.list(this)) have.add(c.name.lowercase() + "|" + digits(c.number))
            var ok = 0; var skip = 0; var fail = 0
            for (c in cards) {
                val nm = (c.first + " " + c.last).trim().lowercase()
                val firstNum = c.phones.firstOrNull()?.value ?: ""
                if (c.phones.isNotEmpty() && have.contains(nm + "|" + digits(firstNum))) { skip++; continue }
                val id = ContactsRepo.save(this, null, c.first, c.last, c.phones, c.emails, c.note, src)
                if (id >= 0) ok++ else fail++
            }
            runOnUiThread {
                toast(tr("%d diimpor, %d dilewati", ok, skip) + (if (fail > 0) tr(", %d gagal", fail) else ""))
                peopleLoaded = false
                if (curTab == 2) loadContacts()
            }
        }.start()
    }
    private fun exportVcf(uri: Uri) {
        toast(tr("Mengekspor…"))
        Thread {
            val n = try { contentResolver.openOutputStream(uri)?.use { Vcf.export(this, it) } ?: 0 } catch (e: Exception) { 0 }
            runOnUiThread { toast(if (n > 0) tr("%d kontak diekspor", n) else tr("Tidak ada kontak yang diekspor")) }
        }.start()
    }
    private fun saveContact(n: String) {
        startActivity(Intent(this, ContactEditActivity::class.java).putExtra("number", n))
    }
    private fun setNumber(s: String) {
        num.setLength(0)
        num.append(s.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }.take(20))
        updateDial()
    }
    private val secretRe = Regex("^\\*#\\*#(.+)#\\*#\\*$")
    private fun press(k: String) {
        if (num.length < 20) { num.append(k); updateDial() }
        val m = secretRe.matchEntire(num.toString())
        if (m != null) { sendSecretCode(m.groupValues[1]); setNumber("") }
    }
    private fun updateDial() {
        val s = num.toString()
        numTv.text = pretty(s); numTv.textSize = if (s.length > 14) 26f else 34f
        val w = normalizeWa(s)
        waNumTv.text = when { s.isEmpty() -> ""; w != null -> fmtWa(w); else -> tr("Bukan nomor WhatsApp") }
        waBtn.background = rr(if (w != null) Color.WHITE else Color.argb(46, 255, 255, 255), 26)
        val wfg = if (w != null) GREEN else Color.argb(200, 255, 255, 255)
        waLabelTv.setTextColor(wfg); waNumTv.setTextColor(wfg)
        waIcon.setColorFilter(wfg, PorterDuff.Mode.SRC_IN)
        saveTv.visibility = if (s.isEmpty()) View.INVISIBLE else View.VISIBLE
        updateSuggest(s)
        refreshClip()
    }
    private fun refreshClip() {
        if (!::pasteChip.isInitialized) return
        val t = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val c = cm.primaryClip
            if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else null
        } catch (e: Exception) { null }
        val ok = t != null && Regex("^\\+?[0-9][0-9 ().-]{6,19}$").matches(t)
        if (ok && digits(t!!) != digits(num.toString())) {
            pasteChip.text = tr("Tempel dari clipboard: %s", t)
            pasteChip.setOnClickListener { setNumber(t); pasteChip.visibility = View.GONE }
            pasteChip.visibility = View.VISIBLE
        } else pasteChip.visibility = View.GONE
    }
    private fun handleIntent(i: Intent?) {
        val d = i?.data
        if (d != null && d.scheme == "tel") {
            setNumber(Uri.decode(d.schemeSpecificPart ?: ""))
            if (i.getBooleanExtra("autocall", false)) {
                i.removeExtra("autocall")
                window.decorView.post { callNum(num.toString()) }
            }
        }
    }

    // ---------- UI ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(BG)
        val content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))
        panes = listOf(buildDial(), buildHistory(), buildContacts(), buildMessages())
        panes.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(View(this).apply { setBackgroundColor(LINE) }, lp(MATCH, dp(1)))
        root.addView(buildNav(), lp(MATCH, dp(72)))
        setContentView(root)
        showTab(intent?.getIntExtra("tab", 0) ?: 0)
        handleIntent(intent)
        val need = ArrayList<String>()
        for (p in listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS, Manifest.permission.GET_ACCOUNTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS))
            if (!has(p)) need.add(p)
        if (Build.VERSION.SDK_INT >= 33 && !has("android.permission.POST_NOTIFICATIONS")) need.add("android.permission.POST_NOTIFICATIONS")
        if (Build.VERSION.SDK_INT >= 23 && need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent); showTab(intent?.getIntExtra("tab", 0) ?: 0) }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) refreshClip() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        peopleLoaded = false; showTab(curTab)
    }

    private fun buildDial(): View {
        val GL = Color.argb(46, 255, 255, 255)
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL

        // ---- header biru (gaya sama dengan tab Pesan) ----
        val hdr = FrameLayout(this)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = gd
        for ((size, al) in listOf(220 to 26, 340 to 15)) {
            val v = View(this)
            v.background = ov(Color.argb(al, 255, 255, 255))
            val rp = FrameLayout.LayoutParams(dp(size), dp(size), Gravity.TOP or Gravity.END)
            rp.setMargins(0, -dp(size / 3), -dp(size / 3), 0)
            hdr.addView(v, rp)
        }
        val hc = LinearLayout(this)
        hc.orientation = LinearLayout.VERTICAL; hc.setPadding(dp(20), dp(12), dp(20), dp(24))

        // pill ikon: Riwayat & Kontak (menggantikan tab bawah)
        val topRow = LinearLayout(this)
        topRow.gravity = Gravity.CENTER_VERTICAL or Gravity.END
        fun topPill(res: Int, desc: String, onTap: () -> Unit) = FrameLayout(this).apply {
            background = rr(GL, 20); contentDescription = desc; isClickable = true
            addView(icon(res, Color.WHITE, 20).apply { layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER) })
            setOnClickListener { onTap() }
            layoutParams = lp(dp(44), dp(40)).apply { marginStart = dp(8) }
        }
        topRow.addView(topPill(R.drawable.ic_clock, tr("Riwayat")) { showTab(1) })
        topRow.addView(topPill(R.drawable.ic_people, tr("Kontak")) { showTab(2) })
        topRow.addView(topPill(R.drawable.ic_settings, tr("Pengaturan")) { startActivity(Intent(this, SettingsActivity::class.java)) })
        hc.addView(topRow, lp(MATCH, dp(44)))

        pasteChip = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#14181F")); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            background = rr(Color.WHITE, 20); setPadding(dp(16), 0, dp(16), 0); gravity = Gravity.CENTER
            compoundDrawablePadding = dp(8); visibility = View.GONE
            setCompoundDrawables(tinted(R.drawable.ic_paste, BLUE, 18), null, null, null)
            layoutParams = lp(WRAP, dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        }
        roleBar = TextView(this).apply {
            text = tr("Jadikan DialChat aplikasi telepon utama"); textSize = 14f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; background = rr(GL, 20)
            setPadding(dp(16), 0, dp(16), 0); visibility = View.GONE
            setOnClickListener { requestDefaultDialer() }
            layoutParams = lp(MATCH, dp(40)).apply { bottomMargin = dp(10) }
        }
        hc.addView(roleBar)
        hc.addView(pasteChip)
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL; mid.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        sugBox = LinearLayout(this)
        sugBox.orientation = LinearLayout.VERTICAL
        mid.addView(sugBox, lp(MATCH, WRAP))
        saveTv = TextView(this).apply {
            text = tr("Simpan kontak"); textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(4))
            setCompoundDrawables(tinted(R.drawable.ic_userplus, Color.WHITE, 18), null, null, null); compoundDrawablePadding = dp(6)
            setOnClickListener { saveContact(num.toString()) }
        }
        mid.addView(saveTv)
        numTv = TextView(this).apply {
            textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; hint = tr("Ketik nomor")
            setHintTextColor(Color.argb(170, 255, 255, 255)); setPadding(0, dp(4), 0, dp(16))
        }
        mid.addView(numTv, lp(MATCH, WRAP))
        hc.addView(mid, lp(MATCH, 0, 1f))
        waBtn = LinearLayout(this)
        waBtn.gravity = Gravity.CENTER_VERTICAL
        waBtn.setPadding(dp(20), 0, dp(20), 0)
        waBtn.isClickable = true
        waBtn.setOnClickListener { openWa(num.toString()) }
        waIcon = icon(R.drawable.ic_wa, Color.WHITE, 24)
        waBtn.addView(waIcon)
        waLabelTv = TextView(this)
        waLabelTv.text = tr("Chat WhatsApp"); waLabelTv.textSize = 16f; waLabelTv.setTypeface(null, Typeface.BOLD)
        waLabelTv.setPadding(dp(10), 0, 0, 0)
        waBtn.addView(waLabelTv, lp(0, WRAP, 1f))
        waNumTv = TextView(this)
        waNumTv.textSize = 13f
        waBtn.addView(waNumTv)
        hc.addView(waBtn, lp(MATCH, dp(52)))
        hdr.addView(hc, FrameLayout.LayoutParams(MATCH, MATCH))
        p.addView(hdr, lp(MATCH, 0, 1f))

        // ---- keypad ----
        val kp = LinearLayout(this)
        kp.orientation = LinearLayout.VERTICAL; kp.setPadding(dp(20), dp(12), dp(20), dp(12))
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        // panel aksen (biru, opacity rendah) di belakang tombol — gaya "bento"
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL; panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        panel.background = rr(if (isDark) Color.argb(36, 138, 176, 255) else Color.argb(26, 29, 78, 216), 34)
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            // penyebab tombol tidak rata: LinearLayout horizontal menyejajarkan baseline teks
            // (angka 1/*/# tanpa huruf punya baseline beda dari 2-9)
            row.isBaselineAligned = false
            for (c in 0 until 3) {
                val (k, l) = keys[r * 3 + c]
                val o = dp(26).toFloat(); val n = dp(8).toFloat()
                // urutan radii: kiri-atas, kanan-atas, kanan-bawah, kiri-bawah (sudut luar besar, dalam kecil)
                val tl = if (r == 0 && c == 0) o else n
                val trc = if (r == 0 && c == 2) o else n
                val br = if (r == 3 && c == 2) o else n
                val bl = if (r == 3 && c == 0) o else n
                row.addView(keyView(k, l, floatArrayOf(tl, tl, trc, trc, br, br, bl, bl)), lp(0, dp(62), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            panel.addView(row, lp(MATCH, WRAP))
        }
        kp.addView(panel, lp(MATCH, WRAP))
        val act = LinearLayout(this)
        act.gravity = Gravity.CENTER_VERTICAL; act.setPadding(0, dp(12), 0, 0)
        act.addView(pillBtn(R.drawable.ic_phone, tr("Telepon"), BLUE) { callNum(num.toString()) })
        val back = circleBtn(R.drawable.ic_backspace, SURF, INK, 56, tr("Hapus angka")) {
            if (num.isNotEmpty()) { num.setLength(num.length - 1); updateDial() }
        }
        back.setOnLongClickListener { num.setLength(0); updateDial(); true }
        act.addView(back)
        kp.addView(act, lp(MATCH, WRAP))
        p.addView(kp, lp(MATCH, WRAP))
        updateDial()
        return p
    }
    private fun keyView(k: String, l: String, radii: FloatArray): TextView {
        val sb = SpannableStringBuilder(k)
        if (l.isNotEmpty()) {
            val s = sb.length
            sb.append("\n").append(l)
            sb.setSpan(RelativeSizeSpan(0.36f), s, sb.length, 0)
            sb.setSpan(ForegroundColorSpan(MUTED), s, sb.length, 0)
        }
        fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadii = radii }
        // normal: putih (dark: SURF); ditekan: tint aksen lembut (bukan biru penuh)
        val normal = if (isDark) SURF else Color.WHITE
        val pressed = if (isDark) Color.parseColor("#425475") else Color.parseColor("#B0C1F1")
        val sel = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(pressed))
            addState(intArrayOf(), shape(normal))
        }
        return TextView(this).apply {
            text = sb; textSize = 26f; setTextColor(INK); gravity = Gravity.CENTER
            background = sel; isClickable = true
            setOnClickListener { press(k) }
            if (k == "0") setOnLongClickListener { press("+"); true }
            else if (k == "1") setOnLongClickListener { callVoicemail(); true }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }
    }

    private fun buildNav(): View {
        val nav = LinearLayout(this)
        nav.gravity = Gravity.CENTER_VERTICAL; nav.setPadding(dp(8), 0, dp(8), 0)
        val defs = listOf(tr("Papan angka") to R.drawable.ic_dial, tr("Pesan") to R.drawable.ic_bubble)
        defs.forEachIndexed { i, (label, res) ->
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL; col.gravity = Gravity.CENTER
            col.setOnClickListener { showTab(if (i == 0) 0 else 3) }
            val pill = FrameLayout(this)
            val ic = icon(res, MUTED, 20)
            ic.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
            pill.addView(ic)
            col.addView(pill, lp(dp(56), dp(28)))
            val tv = TextView(this).apply { text = label; textSize = 12f; setTextColor(MUTED); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
            col.addView(tv)
            nav.addView(col, lp(0, MATCH, 1f))
            tabPills.add(pill); tabIcons.add(ic); tabLbls.add(tv)
        }
        return nav
    }
    override fun onBackPressed() {
        if (curTab == 1 || curTab == 2) showTab(0) else super.onBackPressed()
    }
    fun showTab(i: Int) {
        curTab = i
        panes.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        // nav hanya 2 tab: Riwayat/Kontak dianggap bagian dari Papan angka
        val navOn = if (i == 3) 1 else 0
        for (k in 0..1) {
            val on = k == navOn
            tabPills[k].background = if (on) rr(BLUE, 14) else null
            tabIcons[k].setColorFilter(if (on) Color.WHITE else MUTED, PorterDuff.Mode.SRC_IN)
            tabLbls[k].setTextColor(if (on) LINK else MUTED)
        }
        if (i == 1) loadHistory()
        if (i == 2) loadContacts()
        if (i == 3 && ::msgPane.isInitialized) msgPane.refresh()
    }

    private fun newList() = ListView(this).apply { divider = null; setSelector(ColorDrawable(Color.TRANSPARENT)) }

    // header biru senada dengan Papan angka dan Pesan: judul putih, tombol kembali, cincin transparan
    /** Animasi umum header biru (kembali + judul + tombol kanan) lalu satu elemen "ekor" di bawahnya. */
    private fun blueAnim(h: HdrParts, rights: List<View>, tail: View, p: Float) {
        h.col.setPadding(dp(20), lerpI(dp(12), dp(6), p), dp(20), lerpI(dp(20), dp(10), p))
        h.top.setHeightPx(lerpI(dp(48), dp(44), p))
        h.title.setTextDp(lerpF(28f, 22f, p))
        val s = lerpI(dp(44), dp(38), p)
        h.back.setSquare(s)
        for (v in rights) v.setSquare(s)
        (tail.layoutParams as? LinearLayout.LayoutParams)?.let {
            val m = lerpI(dp(14), dp(8), p)
            if (it.topMargin != m) { it.topMargin = m; tail.layoutParams = it }
        }
    }

    private fun blueHeader(titleText: String, right: View? = null): HdrParts {
        val GL = Color.argb(46, 255, 255, 255)
        val hdr = FrameLayout(this)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = gd
        for ((size, al) in listOf(220 to 26, 340 to 15)) {
            val v = View(this)
            v.background = ov(Color.argb(al, 255, 255, 255))
            val rp = FrameLayout.LayoutParams(dp(size), dp(size), Gravity.TOP or Gravity.END)
            rp.setMargins(0, -dp(size / 3), -dp(size / 3), 0)
            hdr.addView(v, rp)
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(12), dp(20), dp(20))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = FrameLayout(this)
        back.background = ov(GL); back.contentDescription = tr("Kembali"); back.isClickable = true
        back.addView(icon(R.drawable.ic_back, Color.WHITE, 22).apply { layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER) })
        back.setOnClickListener { showTab(0) }
        top.addView(back, lp(dp(44), dp(44)))
        val ttl = TextView(this).apply {
            text = titleText; textSize = 28f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(dp(14), 0, 0, 0)
        }
        top.addView(ttl, lp(0, WRAP, 1f))
        if (right != null) top.addView(right)
        col.addView(top, lp(MATCH, dp(48)))
        hdr.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        return HdrParts(hdr, col, top, ttl, back)
    }

    private fun buildHistory(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        val more = FrameLayout(this)
        more.background = ov(Color.argb(46, 255, 255, 255))
        more.contentDescription = tr("Menu")
        more.isClickable = true
        more.addView(icon(R.drawable.ic_more, Color.WHITE, 24).apply { layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER) })
        more.layoutParams = lp(dp(44), dp(44))
        more.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add(0, 1, 1, tr("Nomor diblokir"))
            pm.menu.add(0, 2, 2, tr("Pesan cepat"))
            pm.setOnMenuItemClickListener { mi ->
                when (mi.itemId) {
                    2 -> startActivity(Intent(this, QuickRepliesActivity::class.java))
                    else -> startActivity(Intent(this, BlockedActivity::class.java))
                }
                true
            }
            pm.show()
        }
        val hRight = LinearLayout(this)
        hRight.gravity = Gravity.CENTER_VERTICAL
        val hSet = settingsButton().apply { (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(8) }
        hRight.addView(hSet)
        hRight.addView(more)
        val hp = blueHeader(tr("Riwayat"), hRight)
        val (hdr, col) = hp
        val chips = LinearLayout(this)
        chips.background = rr(Color.argb(46, 255, 255, 255), 24); chips.setPadding(dp(4), dp(4), dp(4), dp(4))
        chipAll = chip(tr("Semua")) { missedOnly = false; styleChips(); loadHistory() }
        chipMiss = chip(tr("Tak terjawab")) { missedOnly = true; styleChips(); loadHistory() }
        chips.addView(chipAll); chips.addView(chipMiss)
        col.addView(chips, lp(MATCH, WRAP).apply { topMargin = dp(14) })
        histList = newList()
        val hc = Collapse(hdr, dp(142), dp(110)) { pr ->
            blueAnim(hp, listOf(hSet, more), chips, pr)
            for (c in listOf(chipAll, chipMiss)) c.setHeightPx(lerpI(dp(40), dp(34), pr))
        }
        histList.setPadding(0, hc.exp + dp(8), 0, 0)
        val hBody = FrameLayout(this)
        hBody.addView(histList, FrameLayout.LayoutParams(MATCH, MATCH))
        hBody.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        p.addView(hBody, lp(MATCH, 0, 1f))
        hc.attach(histList)
        styleChips()
        return p
    }
    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); maxLines = 1
        setOnClickListener { onClick() }
        layoutParams = lp(0, dp(40), 1f)
    }
    private fun styleChips() {
        for ((c, on) in listOf(chipAll to !missedOnly, chipMiss to missedOnly)) {
            c.background = if (on) rr(Color.WHITE, 20) else null
            c.setTextColor(if (on) BLUE else Color.WHITE)
        }
    }
    private fun buildContacts(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        val cSet = settingsButton()
        val cp = blueHeader(tr("Kontak"), cSet)
        val (hdr, col) = cp
        searchEt = EditText(this).apply {
            hint = tr("Cari kontak"); textSize = 16f; background = rr(Color.WHITE, 24); setSingleLine()
            setTextColor(Color.parseColor("#14181F")); setHintTextColor(Color.parseColor("#5B6472"))
            setPadding(dp(16), 0, dp(16), 0); compoundDrawablePadding = dp(10)
            setCompoundDrawables(tinted(R.drawable.ic_search, Color.parseColor("#5B6472"), 20), null, null, null)
            layoutParams = lp(MATCH, dp(48)).apply { topMargin = dp(14) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { renderContacts(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        col.addView(searchEt)
        val cHc = Collapse(hdr, dp(142), dp(110)) { pr ->
            blueAnim(cp, listOf(cSet), searchEt, pr)
            searchEt.setHeightPx(lerpI(dp(48), dp(42), pr))
        }
        p.addView(hdr, lp(MATCH, cHc.exp))
        val frow = LinearLayout(this)
        frow.setBackgroundColor(BG)
        frow.gravity = Gravity.CENTER_VERTICAL
        frow.setPadding(dp(16), dp(6), dp(8), 0)
        filterTv = TextView(this).apply {
            text = srcFilterLabel; textSize = 13f; setTextColor(MUTED); setPadding(0, dp(10), dp(12), dp(10))
            isClickable = true; setOnClickListener { pickSource() }
        }
        frow.addView(filterTv, lp(0, WRAP, 1f))
        frow.addView(circleBtn(R.drawable.ic_more, SURF, INK, 40, tr("Impor dan ekspor")) { showContactMenu() })
        p.addView(frow, lp(MATCH, WRAP))
        favScroll = HorizontalScrollView(this)
        favScroll.isHorizontalScrollBarEnabled = false
        favScroll.visibility = View.GONE
        favScroll.setBackgroundColor(BG)
        favRow = LinearLayout(this)
        favRow.setPadding(dp(12), dp(8), dp(12), dp(4))
        favScroll.addView(favRow)
        p.addView(favScroll, lp(MATCH, WRAP))
        contList = newList()
        val wrap = FrameLayout(this)
        wrap.addView(contList, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(p, FrameLayout.LayoutParams(MATCH, WRAP))
        // Baris filter dan favorit tetap menempel di bawah header; daftar diberi padding setinggi semuanya.
        p.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val want = (b - t) - hdr.height + cHc.exp
            if (contList.paddingTop != want) contList.setPadding(0, want, 0, 0)
        }
        contList.setPadding(0, cHc.exp, 0, 0)
        cHc.attach(contList)
        val fab = FrameLayout(this)
        fab.background = rr(BLUE, 18); fab.contentDescription = tr("Tambah kontak"); fab.isClickable = true
        fab.addView(icon(R.drawable.ic_add, Color.WHITE, 26).apply { layoutParams = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER) })
        fab.setOnClickListener { startActivity(Intent(this, ContactEditActivity::class.java)) }
        wrap.addView(fab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(20)) })
        return wrap
    }

    // ---------- data ----------
    private fun fmtTime(d: Long): String = when {
        DateUtils.isToday(d) -> SimpleDateFormat(if (L.en) "HH:mm" else "HH.mm", L.loc).format(Date(d))
        DateUtils.isToday(d + 86400000L) -> tr("Kemarin")
        else -> SimpleDateFormat("d MMM", L.loc).format(Date(d))
    }
    private fun simIds(): Map<String, Int> {
        val m = HashMap<String, Int>()
        try {
            if (has(Manifest.permission.READ_PHONE_STATE)) {
                val l = (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).callCapablePhoneAccounts
                if (l.size > 1) l.forEachIndexed { i, h -> m[h.id] = i + 1 }
            }
        } catch (e: Exception) { }
        return m
    }
    private fun loadHistory() {
        val out = ArrayList<Row>()
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            out.add(Row(header = tr("Izin riwayat panggilan belum diberikan")))
        } else try {
            val simMap = simIds()
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.PHONE_ACCOUNT_ID),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 150) {
                    val n = c.getString(0) ?: ""
                    val name = c.getString(1) ?: ""
                    val type = c.getInt(2); val d = c.getLong(3)
                    val simTxt = simMap[c.getString(4) ?: ""]?.let { " · SIM " + it } ?: ""
                    if (n.isBlank()) continue
                    val missed = type == CallLog.Calls.MISSED_TYPE
                    if (missedOnly && !missed) continue
                    val named = name.isNotBlank()
                    val sub = (if (named) "$n · " else "") + (if (missed) tr("Tak terjawab · ") else "") + fmtTime(d) + simTxt
                    out.add(Row(title = if (named) name else n, sub = sub, number = n, missed = missed,
                        arrow = if (type == CallLog.Calls.OUTGOING_TYPE) 2 else 1, save = !named))
                }
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) out.add(Row(header = tr("Belum ada riwayat")))
        histList.adapter = RowAdapter(out)
    }
    private fun ensurePeople() {
        if (peopleLoaded || !has(Manifest.permission.READ_CONTACTS)) return
        people = ContactsRepo.list(this)
        peopleLoaded = true
    }
    private fun t9(name: String): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) {
            val d: Char? = when (ch) {
                'a', 'b', 'c' -> '2'
                'd', 'e', 'f' -> '3'
                'g', 'h', 'i' -> '4'
                'j', 'k', 'l' -> '5'
                'm', 'n', 'o' -> '6'
                'p', 'q', 'r', 's' -> '7'
                't', 'u', 'v' -> '8'
                'w', 'x', 'y', 'z' -> '9'
                else -> null
            }
            if (d != null) sb.append(d)
        }
        return sb.toString()
    }
    private fun updateSuggest(s: String) {
        if (!::sugBox.isInitialized) return
        sugBox.removeAllViews()
        if (s.length < 2 || !s.all { it.isDigit() }) return
        ensurePeople()
        val alt = if (s.startsWith("0")) "62" + s.drop(1) else s
        var count = 0
        for ((name, n) in people) {
            val nd = digits(n)
            val hit = nd.startsWith(s) || nd.startsWith(alt) || (s.length >= 4 && nd.contains(s)) || t9(name).contains(s)
            if (!hit) continue
            sugBox.addView(sugRow(name, n))
            count++
            if (count >= 2) break
        }
    }
    private fun sugRow(name: String, n: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = rr(SURF, 16)
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        r.isClickable = true
        r.setOnClickListener { setNumber(n) }
        val a = TextView(this)
        a.text = name; a.textSize = 15f; a.setTextColor(INK); a.setTypeface(null, Typeface.BOLD)
        a.maxLines = 1; a.ellipsize = TextUtils.TruncateAt.END
        r.addView(a, lp(0, WRAP, 1f))
        val b = TextView(this)
        b.text = n; b.textSize = 13f; b.setTextColor(MUTED); b.maxLines = 1
        val bp = lp(WRAP, WRAP)
        bp.marginStart = dp(8)
        r.addView(b, bp)
        val p = lp(MATCH, WRAP)
        p.topMargin = dp(6)
        r.layoutParams = p
        return r
    }
    private fun renderFavs() {
        if (!::favRow.isInitialized) return
        favRow.removeAllViews()
        val fav = Prefs.favs(this)
        favScroll.visibility = if (fav.isEmpty()) View.GONE else View.VISIBLE
        for ((name, number) in fav) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(8), dp(4), dp(8), dp(4))
            cell.isClickable = true
            val av = TextView(this)
            av.text = (name.firstOrNull() ?: '#').uppercaseChar().toString()
            av.gravity = Gravity.CENTER; av.textSize = 22f; av.setTextColor(Color.WHITE); av.setTypeface(null, Typeface.BOLD)
            av.background = ov(PAL[Math.abs(number.hashCode()) % PAL.size])
            cell.addView(av, lp(dp(56), dp(56)))
            val tv = TextView(this)
            tv.text = name; tv.textSize = 12f; tv.setTextColor(INK); tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER; tv.setPadding(0, dp(4), 0, 0)
            cell.addView(tv, lp(dp(64), WRAP))
            cell.setOnClickListener { callNum(number) }
            cell.setOnLongClickListener { showActions(Row(title = name, number = number)); true }
            favRow.addView(cell)
        }
    }
    private fun loadContacts() {
        renderFavs()
        if (!has(Manifest.permission.READ_CONTACTS)) {
            contList.adapter = RowAdapter(listOf(Row(header = tr("Izin kontak belum diberikan")))); return
        }
        ensurePeople()
        renderContacts(searchEt.text.toString())
    }
    private fun renderContacts(q: String) {
        val ql = q.trim().lowercase(); val qd = digits(ql)
        val out = ArrayList<Row>(); var last = ""
        var count = 0
        for ((name, n, cid, photo, src) in people) {
            if (srcFilter != null && src != srcFilter) continue
            if (ql.isNotEmpty() && !(name.lowercase().contains(ql) || (qd.isNotEmpty() && digits(n).contains(qd)))) continue
            val f = name.firstOrNull()
            val ch = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
            if (ch != last) { out.add(Row(header = ch)); last = ch }
            out.add(Row(title = name.ifBlank { n }, sub = n, number = n, cid = cid, photo = photo))
            count++
        }
        if (out.isEmpty()) out.add(Row(header = tr("Tidak ada kontak")))
        if (::filterTv.isInitialized) filterTv.text = "$srcFilterLabel · $count ▾"
        contList.adapter = RowAdapter(out)
    }

    inner class RowAdapter(private val items: List<Row>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = buildRow(items[position])
    }

    private fun buildRow(r: Row): View {
        if (r.header != null) return TextView(this).apply {
            text = r.header; textSize = 13f; setTextColor(LINK); setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(12), dp(16), dp(4))
        }
        val wa = normalizeWa(r.number)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(dp(16), dp(10), dp(16), dp(10))
        val f = r.title.firstOrNull()
        val pb = if (r.photo != null) Photos.get(this, r.photo) else null
        val av: View = if (pb != null) photoView(pb) else if (f != null && f.isLetter()) TextView(this).apply {
            text = f.uppercaseChar().toString(); gravity = Gravity.CENTER; textSize = 18f
            setTextColor(MUTED); background = ov(SURF)
        } else FrameLayout(this).apply {
            background = ov(SURF)
            addView(icon(R.drawable.ic_person, MUTED, 22).apply { layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER) })
        }
        row.addView(av, lp(dp(44), dp(44)))
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.addView(TextView(this).apply {
            text = r.title; textSize = 16f; setTextColor(if (r.missed) RED else INK)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        val sub = LinearLayout(this)
        sub.gravity = Gravity.CENTER_VERTICAL
        if (r.arrow != 0) sub.addView(icon(if (r.arrow == 1) R.drawable.ic_in else R.drawable.ic_out, if (r.missed) RED else MUTED, 14).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(4)
        })
        sub.addView(TextView(this).apply {
            text = r.sub; textSize = 13f; setTextColor(MUTED); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(sub)
        if (r.save) mid.addView(TextView(this).apply {
            text = tr("Simpan kontak"); textSize = 13f; setTextColor(LINK); setPadding(0, dp(4), dp(12), dp(4))
            setOnClickListener { saveContact(r.number) }
        })
        row.addView(mid, lp(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        row.addView(circleBtn(R.drawable.ic_phone, BLUE, Color.WHITE, 44, tr("Telepon %s", r.title)) { callNum(r.number) })
        row.addView(
            if (wa != null) circleBtn(R.drawable.ic_wa, GREEN, Color.WHITE, 44, tr("Chat WhatsApp %s", r.title), 8) { openWa(r.number) }
            else circleBtn(R.drawable.ic_wa, SURF, MUTED, 44, tr("WhatsApp tidak tersedia"), 8, false) {}
        )
        row.setOnClickListener {
            if (r.cid > 0) startActivity(Intent(this, ContactDetailActivity::class.java).putExtra("id", r.cid))
            else { setNumber(r.number); showTab(0) }
        }
        row.setOnLongClickListener { showActions(r); true }
        return row
    }
}
