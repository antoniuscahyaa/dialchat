package id.dialchat.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Row(
    val header: String? = null, val title: String = "", val sub: String = "",
    val number: String = "", val missed: Boolean = false, val arrow: Int = 0, val save: Boolean = false
)

class MainActivity : Activity() {
    private val INK = Color.parseColor("#14181F")
    private val MUTED = Color.parseColor("#5B6472")
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val SURF = Color.parseColor("#F3F4F7")
    private val LINE = Color.parseColor("#E3E6EB")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val num = StringBuilder()
    private lateinit var numTv: TextView
    private lateinit var waTv: TextView
    private lateinit var saveTv: TextView
    private lateinit var pasteChip: TextView
    private lateinit var panes: List<View>
    private val tabPills = ArrayList<FrameLayout>()
    private val tabIcons = ArrayList<ImageView>()
    private val tabLbls = ArrayList<TextView>()
    private lateinit var histList: ListView
    private lateinit var contList: ListView
    private lateinit var chipAll: TextView
    private lateinit var chipMiss: TextView
    private lateinit var searchEt: EditText
    private var missedOnly = false
    private var curTab = 0
    private var people = listOf<Pair<String, String>>()
    private var peopleLoaded = false

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun rr(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun ov(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun has(p: String) = Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun digits(s: String) = s.filter { it.isDigit() }

    private fun icon(res: Int, color: Int, size: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(color, PorterDuff.Mode.SRC_IN)
        layoutParams = lp(dp(size), dp(size))
    }
    private fun tinted(res: Int, color: Int, size: Int) = getDrawable(res)!!.mutate().apply {
        setColorFilter(color, PorterDuff.Mode.SRC_IN); setBounds(0, 0, dp(size), dp(size))
    }
    private fun circleBtn(res: Int, bg: Int, fg: Int, size: Int, desc: String, ms: Int = 0, enabled: Boolean = true, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.background = ov(bg); f.contentDescription = desc; f.isEnabled = enabled
        val i = icon(res, fg, 20)
        i.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        f.addView(i)
        if (enabled) { f.isClickable = true; f.setOnClickListener { onClick() } }
        f.layoutParams = lp(dp(size), dp(size)).apply { marginStart = dp(ms) }
        return f
    }
    private fun pillBtn(res: Int, label: String, bg: Int, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER; l.background = rr(bg, 28); l.isClickable = true
        l.setOnClickListener { onClick() }
        l.addView(icon(res, Color.WHITE, 20))
        l.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
        })
        l.layoutParams = lp(0, dp(56), 1f).apply { marginEnd = dp(10) }
        return l
    }

    // ---------- nomor ----------
    private fun normalizeWa(raw: String): String? {
        val t = raw.trim(); val d = digits(t)
        if (d.isEmpty()) return null
        val r = when {
            t.startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("62") -> d
            d.startsWith("08") -> "62" + d.drop(1)
            d.startsWith("8") -> "62$d"
            else -> return null
        }
        if (r.startsWith("62")) return if (r.startsWith("628") && r.length in 10..15) r else null
        return if (r.length in 8..15) r else null
    }
    private fun fmtWa(r: String): String =
        if (r.startsWith("62")) { val x = r.drop(2); "+62 " + x.take(3) + " " + x.drop(3).chunked(4).joinToString(" ") } else "+$r"
    private fun pretty(s: String) = if (s.length > 4 && s.all { it.isDigit() }) s.chunked(4).joinToString(" ") else s

    // ---------- aksi ----------
    private fun openWa(raw: String) {
        val w = normalizeWa(raw)
        if (w == null) { toast("Nomor tidak valid untuk WhatsApp"); return }
        val uri = Uri.parse("https://wa.me/$w")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return }
            catch (e: ActivityNotFoundException) { }
        }
        toast("WhatsApp tidak terpasang")
    }
    private fun callNum(raw: String) {
        if (raw.isBlank()) { toast("Ketik nomor dulu"); return }
        val u = Uri.parse("tel:" + Uri.encode(raw))
        val i = if (has(Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, u) else Intent(Intent.ACTION_DIAL, u)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }
    private fun saveContact(n: String) {
        val i = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
            type = "vnd.android.cursor.item/contact"
            putExtra(ContactsContract.Intents.Insert.PHONE, n)
        }
        try { startActivity(i) } catch (e: Exception) { toast("Aplikasi Kontak tidak ditemukan") }
    }
    private fun setNumber(s: String) {
        num.setLength(0)
        num.append(s.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }.take(20))
        updateDial()
    }
    private fun press(k: String) { if (num.length < 20) { num.append(k); updateDial() } }
    private fun updateDial() {
        val s = num.toString()
        numTv.text = pretty(s); numTv.textSize = if (s.length > 14) 26f else 34f
        val w = normalizeWa(s)
        waTv.text = when { s.isEmpty() -> ""; w != null -> "WhatsApp: " + fmtWa(w); else -> "Bukan nomor WhatsApp" }
        waTv.setTextColor(if (w != null) GREEN else MUTED)
        saveTv.visibility = if (s.isEmpty()) View.INVISIBLE else View.VISIBLE
        refreshClip()
    }
    private fun refreshClip() {
        if (!::pasteChip.isInitialized) return
        val t = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val c = cm.primaryClip
            if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else null
        } catch (e: Exception) { null }
        val ok = t != null && Regex("^\\+?[0-9][0-9 ().-]{6,19}$").matches(t)
        if (ok && digits(t!!) != digits(num.toString())) {
            pasteChip.text = "Tempel dari clipboard: $t"
            pasteChip.setOnClickListener { setNumber(t); pasteChip.visibility = View.GONE }
            pasteChip.visibility = View.VISIBLE
        } else pasteChip.visibility = View.GONE
    }
    private fun handleIntent(i: Intent?) {
        val d = i?.data
        if (d != null && d.scheme == "tel") setNumber(Uri.decode(d.schemeSpecificPart ?: ""))
    }

    // ---------- UI ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(Color.WHITE)
        val content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))
        panes = listOf(buildDial(), buildHistory(), buildContacts())
        panes.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(View(this).apply { setBackgroundColor(LINE) }, lp(MATCH, dp(1)))
        root.addView(buildNav(), lp(MATCH, dp(72)))
        setContentView(root)
        showTab(0)
        handleIntent(intent)
        if (Build.VERSION.SDK_INT >= 23 && !(has(Manifest.permission.READ_CONTACTS) && has(Manifest.permission.READ_CALL_LOG) && has(Manifest.permission.CALL_PHONE)))
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE), 1)
    }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent); showTab(0) }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) refreshClip() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        peopleLoaded = false; showTab(curTab)
    }

    private fun buildDial(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL; p.setPadding(dp(20), dp(20), dp(20), dp(12))
        pasteChip = TextView(this).apply {
            textSize = 14f; setTextColor(INK); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            background = rr(Color.WHITE, 20, LINE); setPadding(dp(16), 0, dp(16), 0); gravity = Gravity.CENTER
            compoundDrawablePadding = dp(8); visibility = View.GONE
            setCompoundDrawables(tinted(R.drawable.ic_paste, BLUE, 18), null, null, null)
            layoutParams = lp(WRAP, dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        }
        p.addView(pasteChip)
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL; mid.gravity = Gravity.CENTER
        numTv = TextView(this).apply { textSize = 34f; setTextColor(INK); gravity = Gravity.CENTER; hint = "Ketik nomor"; setHintTextColor(Color.parseColor("#8A929E")) }
        waTv = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        saveTv = TextView(this).apply {
            text = "Simpan kontak"; textSize = 14f; setTextColor(BLUE); setPadding(dp(12), dp(10), dp(12), dp(10))
            setCompoundDrawables(tinted(R.drawable.ic_userplus, BLUE, 18), null, null, null); compoundDrawablePadding = dp(6)
            setOnClickListener { saveContact(num.toString()) }
        }
        mid.addView(numTv); mid.addView(waTv); mid.addView(saveTv)
        p.addView(mid, lp(MATCH, 0, 1f))
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (c in 0 until 3) {
                val (k, l) = keys[r * 3 + c]
                row.addView(keyView(k, l), lp(0, dp(72), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            p.addView(row, lp(MATCH, WRAP))
        }
        val act = LinearLayout(this)
        act.gravity = Gravity.CENTER_VERTICAL; act.setPadding(0, dp(12), 0, 0)
        act.addView(pillBtn(R.drawable.ic_phone, "Telepon", BLUE) { callNum(num.toString()) })
        act.addView(pillBtn(R.drawable.ic_wa, "WhatsApp", GREEN) { openWa(num.toString()) })
        val back = circleBtn(R.drawable.ic_backspace, SURF, INK, 56, "Hapus angka") {
            if (num.isNotEmpty()) { num.setLength(num.length - 1); updateDial() }
        }
        back.setOnLongClickListener { num.setLength(0); updateDial(); true }
        act.addView(back)
        p.addView(act, lp(MATCH, WRAP))
        updateDial()
        return p
    }
    private fun keyView(k: String, l: String): TextView {
        val sb = SpannableStringBuilder(k)
        if (l.isNotEmpty()) {
            val s = sb.length
            sb.append("\n").append(l)
            sb.setSpan(RelativeSizeSpan(0.36f), s, sb.length, 0)
            sb.setSpan(ForegroundColorSpan(MUTED), s, sb.length, 0)
        }
        return TextView(this).apply {
            text = sb; textSize = 28f; setTextColor(INK); gravity = Gravity.CENTER
            background = rr(SURF, 20); isClickable = true
            setOnClickListener { press(k) }
            if (k == "0") setOnLongClickListener { press("+"); true }
        }
    }

    private fun buildNav(): View {
        val nav = LinearLayout(this)
        nav.gravity = Gravity.CENTER_VERTICAL; nav.setPadding(dp(8), 0, dp(8), 0)
        val defs = listOf("Papan angka" to R.drawable.ic_dial, "Riwayat" to R.drawable.ic_clock, "Kontak" to R.drawable.ic_people)
        defs.forEachIndexed { i, (label, res) ->
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL; col.gravity = Gravity.CENTER
            col.setOnClickListener { showTab(i) }
            val pill = FrameLayout(this)
            val ic = icon(res, MUTED, 20)
            ic.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
            pill.addView(ic)
            col.addView(pill, lp(dp(56), dp(28)))
            val tv = TextView(this).apply { text = label; textSize = 12f; setTextColor(MUTED); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
            col.addView(tv)
            nav.addView(col, lp(0, MATCH, 1f))
            tabPills.add(pill); tabIcons.add(ic); tabLbls.add(tv)
        }
        return nav
    }
    private fun showTab(i: Int) {
        curTab = i
        panes.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        for (k in 0..2) {
            val on = k == i
            tabPills[k].background = if (on) rr(BLUE, 14) else null
            tabIcons[k].setColorFilter(if (on) Color.WHITE else MUTED, PorterDuff.Mode.SRC_IN)
            tabLbls[k].setTextColor(if (on) BLUE else MUTED)
        }
        if (i == 1) loadHistory()
        if (i == 2) loadContacts()
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 28f; setTextColor(INK); setPadding(dp(16), dp(24), dp(16), dp(8))
    }
    private fun newList() = ListView(this).apply { divider = null; setSelector(ColorDrawable(Color.TRANSPARENT)) }

    private fun buildHistory(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.addView(title("Riwayat"))
        val chips = LinearLayout(this)
        chips.setPadding(dp(16), dp(8), dp(16), dp(12))
        chipAll = chip("Semua") { missedOnly = false; styleChips(); loadHistory() }
        chipMiss = chip("Tak terjawab") { missedOnly = true; styleChips(); loadHistory() }
        chips.addView(chipAll); chips.addView(chipMiss)
        p.addView(chips)
        histList = newList()
        p.addView(histList, lp(MATCH, 0, 1f))
        styleChips()
        return p
    }
    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { onClick() }
        layoutParams = lp(WRAP, dp(34)).apply { marginEnd = dp(8) }
    }
    private fun styleChips() {
        for ((c, on) in listOf(chipAll to !missedOnly, chipMiss to missedOnly)) {
            c.background = rr(if (on) BLUE else Color.WHITE, 17, if (on) BLUE else LINE)
            c.setTextColor(if (on) Color.WHITE else INK)
        }
    }
    private fun buildContacts(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.addView(title("Kontak"))
        searchEt = EditText(this).apply {
            hint = "Cari kontak"; textSize = 16f; background = rr(SURF, 24); setSingleLine()
            setPadding(dp(16), 0, dp(16), 0); compoundDrawablePadding = dp(10)
            setCompoundDrawables(tinted(R.drawable.ic_search, MUTED, 20), null, null, null)
            layoutParams = lp(MATCH, dp(48)).apply { setMargins(dp(16), dp(8), dp(16), dp(4)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { renderContacts(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        p.addView(searchEt)
        contList = newList()
        p.addView(contList, lp(MATCH, 0, 1f))
        return p
    }

    // ---------- data ----------
    private fun fmtTime(d: Long): String = when {
        DateUtils.isToday(d) -> SimpleDateFormat("HH.mm", Locale("id")).format(Date(d))
        DateUtils.isToday(d + 86400000L) -> "Kemarin"
        else -> SimpleDateFormat("d MMM", Locale("id")).format(Date(d))
    }
    private fun loadHistory() {
        val out = ArrayList<Row>()
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            out.add(Row(header = "Izin riwayat panggilan belum diberikan"))
        } else try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 150) {
                    val n = c.getString(0) ?: ""
                    val name = c.getString(1) ?: ""
                    val type = c.getInt(2); val d = c.getLong(3)
                    if (n.isBlank()) continue
                    val missed = type == CallLog.Calls.MISSED_TYPE
                    if (missedOnly && !missed) continue
                    val named = name.isNotBlank()
                    val sub = (if (named) "$n · " else "") + (if (missed) "Tak terjawab · " else "") + fmtTime(d)
                    out.add(Row(title = if (named) name else n, sub = sub, number = n, missed = missed,
                        arrow = if (type == CallLog.Calls.OUTGOING_TYPE) 2 else 1, save = !named))
                }
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) out.add(Row(header = "Belum ada riwayat"))
        histList.adapter = RowAdapter(out)
    }
    private fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) {
            contList.adapter = RowAdapter(listOf(Row(header = "Izin kontak belum diberikan"))); return
        }
        if (!peopleLoaded) {
            val list = ArrayList<Pair<String, String>>(); val seen = HashSet<String>()
            try {
                contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null,
                    Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(0) ?: ""; val n = c.getString(1) ?: ""
                        if (n.isBlank() || !seen.add(name + "|" + digits(n))) continue
                        list.add(name to n)
                    }
                }
            } catch (e: Exception) { }
            people = list; peopleLoaded = true
        }
        renderContacts(searchEt.text.toString())
    }
    private fun renderContacts(q: String) {
        val ql = q.trim().lowercase(); val qd = digits(ql)
        val out = ArrayList<Row>(); var last = ""
        for ((name, n) in people) {
            if (ql.isNotEmpty() && !(name.lowercase().contains(ql) || (qd.isNotEmpty() && digits(n).contains(qd)))) continue
            val f = name.firstOrNull()
            val ch = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
            if (ch != last) { out.add(Row(header = ch)); last = ch }
            out.add(Row(title = name.ifBlank { n }, sub = n, number = n))
        }
        if (out.isEmpty()) out.add(Row(header = "Tidak ada kontak"))
        contList.adapter = RowAdapter(out)
    }

    inner class RowAdapter(private val items: List<Row>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = buildRow(items[position])
    }

    private fun buildRow(r: Row): View {
        if (r.header != null) return TextView(this).apply {
            text = r.header; textSize = 13f; setTextColor(BLUE); setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(12), dp(16), dp(4))
        }
        val wa = normalizeWa(r.number)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(dp(16), dp(10), dp(16), dp(10))
        val f = r.title.firstOrNull()
        val av: View = if (f != null && f.isLetter()) TextView(this).apply {
            text = f.uppercaseChar().toString(); gravity = Gravity.CENTER; textSize = 18f
            setTextColor(MUTED); background = ov(SURF)
        } else FrameLayout(this).apply {
            background = ov(SURF)
            addView(icon(R.drawable.ic_person, MUTED, 22).apply { layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER) })
        }
        row.addView(av, lp(dp(44), dp(44)))
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.addView(TextView(this).apply {
            text = r.title; textSize = 16f; setTextColor(if (r.missed) RED else INK)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        val sub = LinearLayout(this)
        sub.gravity = Gravity.CENTER_VERTICAL
        if (r.arrow != 0) sub.addView(icon(if (r.arrow == 1) R.drawable.ic_in else R.drawable.ic_out, if (r.missed) RED else MUTED, 14).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(4)
        })
        sub.addView(TextView(this).apply {
            text = r.sub; textSize = 13f; setTextColor(MUTED); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(sub)
        if (r.save) mid.addView(TextView(this).apply {
            text = "Simpan kontak"; textSize = 13f; setTextColor(BLUE); setPadding(0, dp(4), dp(12), dp(4))
            setOnClickListener { saveContact(r.number) }
        })
        row.addView(mid, lp(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        row.addView(circleBtn(R.drawable.ic_phone, BLUE, Color.WHITE, 44, "Telepon ${r.title}") { callNum(r.number) })
        row.addView(
            if (wa != null) circleBtn(R.drawable.ic_wa, GREEN, Color.WHITE, 44, "Chat WhatsApp ${r.title}", 8) { openWa(r.number) }
            else circleBtn(R.drawable.ic_wa, Color.parseColor("#ECEEF1"), Color.parseColor("#8A929E"), 44, "WhatsApp tidak tersedia", 8, false) {}
        )
        row.setOnClickListener { setNumber(r.number); showTab(0) }
        return row
    }
}
