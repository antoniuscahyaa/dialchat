package id.dialchat.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.role.RoleManager
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.view.Window
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.Telephony
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Row(
    val header: String? = null, val title: String = "", val sub: String = "",
    val number: String = "", val missed: Boolean = false, val arrow: Int = 0, val save: Boolean = false
)

class MainActivity : Activity() {
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINK by lazy { col(R.color.link) }
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val SURF by lazy { col(R.color.surf) }
    private val LINE by lazy { col(R.color.line) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val num = StringBuilder()
    private lateinit var numTv: TextView
    private lateinit var waTv: TextView
    private lateinit var saveTv: TextView
    private lateinit var pasteChip: TextView
    private lateinit var roleBar: TextView
    private lateinit var msgPane: MessagesPane
    private lateinit var favRow: LinearLayout
    private lateinit var favScroll: HorizontalScrollView
    private val PAL by lazy { intArrayOf(BLUE, GREEN, Color.parseColor("#6D28D9"), Color.parseColor("#B45309"), RED) }
    private lateinit var sugBox: LinearLayout
    private lateinit var panes: List<View>
    private val tabPills = ArrayList<FrameLayout>()
    private val tabIcons = ArrayList<ImageView>()
    private val tabLbls = ArrayList<TextView>()
    private lateinit var histList: ListView
    private lateinit var contList: ListView
    private lateinit var chipAll: TextView
    private lateinit var chipMiss: TextView
    private lateinit var searchEt: EditText
    private var missedOnly = false
    private var curTab = 0
    private var people = listOf<Pair<String, String>>()
    private var peopleLoaded = false

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun rr(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun ov(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    fun has(p: String) = Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun digits(s: String) = s.filter { it.isDigit() }

    private fun icon(res: Int, color: Int, size: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(color, PorterDuff.Mode.SRC_IN)
        layoutParams = lp(dp(size), dp(size))
    }
    private fun tinted(res: Int, color: Int, size: Int) = getDrawable(res)!!.mutate().apply {
        setColorFilter(color, PorterDuff.Mode.SRC_IN); setBounds(0, 0, dp(size), dp(size))
    }
    private fun circleBtn(res: Int, bg: Int, fg: Int, size: Int, desc: String, ms: Int = 0, enabled: Boolean = true, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.background = ov(bg); f.contentDescription = desc; f.isEnabled = enabled
        val i = icon(res, fg, 20)
        i.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        f.addView(i)
        if (enabled) { f.isClickable = true; f.setOnClickListener { onClick() } }
        f.layoutParams = lp(dp(size), dp(size)).apply { marginStart = dp(ms) }
        return f
    }
    private fun pillBtn(res: Int, label: String, bg: Int, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER; l.background = rr(bg, 28); l.isClickable = true
        l.setOnClickListener { onClick() }
        l.addView(icon(res, Color.WHITE, 20))
        l.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
        })
        l.layoutParams = lp(0, dp(56), 1f).apply { marginEnd = dp(10) }
        return l
    }

    // ---------- nomor ----------
    private fun normalizeWa(raw: String): String? {
        val t = raw.trim(); val d = digits(t)
        if (d.isEmpty()) return null
        val r = when {
            t.startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("62") -> d
            d.startsWith("08") -> "62" + d.drop(1)
            d.startsWith("8") -> "62$d"
            else -> return null
        }
        if (r.startsWith("62")) return if (r.startsWith("628") && r.length in 10..15) r else null
        return if (r.length in 8..15) r else null
    }
    private fun fmtWa(r: String): String =
        if (r.startsWith("62")) { val x = r.drop(2); "+62 " + x.take(3) + " " + x.drop(3).chunked(4).joinToString(" ") } else "+$r"
    private fun pretty(s: String) = if (s.length > 4 && s.all { it.isDigit() }) s.chunked(4).joinToString(" ") else s

    // ---------- aksi ----------
    private fun openWa(raw: String) {
        val w = normalizeWa(raw)
        if (w == null) { toast("Nomor tidak valid untuk WhatsApp"); return }
        val uri = Uri.parse("https://wa.me/$w")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return }
            catch (e: ActivityNotFoundException) { }
        }
        toast("WhatsApp tidak terpasang")
    }
    private fun callNum(raw: String) {
        if (raw.isBlank()) { toast("Ketik nomor dulu"); return }
        val accs = simAccounts()
        if (accs.size > 1) showSimSheet(raw, accs) else placeCall(raw, null)
    }
    private fun simAccounts(): List<PhoneAccountHandle> = try {
        if (has(Manifest.permission.READ_PHONE_STATE))
            (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).callCapablePhoneAccounts
        else emptyList()
    } catch (e: Exception) { emptyList() }
    private fun placeCall(raw: String, acc: PhoneAccountHandle?) {
        val u = Uri.parse("tel:" + Uri.encode(raw))
        val i = if (has(Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, u) else Intent(Intent.ACTION_DIAL, u)
        if (acc != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, acc)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }
    private fun showSimSheet(raw: String, accs: List<PhoneAccountHandle>) {
        val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(24))
        val r = dp(28).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BG)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        box.background = bg
        val t1 = TextView(this)
        t1.text = "Telepon dengan SIM mana?"; t1.textSize = 22f; t1.setTextColor(INK); t1.setTypeface(null, Typeface.BOLD)
        box.addView(t1)
        val t2 = TextView(this)
        t2.text = raw; t2.textSize = 14f; t2.setTextColor(MUTED); t2.setPadding(0, dp(4), 0, dp(6))
        box.addView(t2)
        accs.forEachIndexed { i, acc ->
            val label = try { tm.getPhoneAccount(acc)?.label?.toString() ?: "" } catch (e: Exception) { "" }
            val col = if (i % 2 == 0) BLUE else GREEN
            val card = LinearLayout(this)
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(18), 0, dp(18), 0)
            card.background = rr(col, 20)
            card.isClickable = true
            card.setOnClickListener { d.dismiss(); placeCall(raw, acc) }
            val badge = TextView(this)
            badge.text = (i + 1).toString(); badge.textSize = 20f; badge.gravity = Gravity.CENTER
            badge.setTextColor(col); badge.setTypeface(null, Typeface.BOLD); badge.background = ov(Color.WHITE)
            card.addView(badge, lp(dp(44), dp(44)))
            val mid = LinearLayout(this)
            mid.orientation = LinearLayout.VERTICAL
            val a = TextView(this)
            a.text = "SIM " + (i + 1); a.textSize = 18f; a.setTextColor(Color.WHITE); a.setTypeface(null, Typeface.BOLD)
            mid.addView(a)
            val b2 = TextView(this)
            b2.text = label; b2.textSize = 13f; b2.setTextColor(Color.WHITE)
            mid.addView(b2)
            val mp = lp(0, WRAP, 1f)
            mp.marginStart = dp(14)
            card.addView(mid, mp)
            card.addView(icon(R.drawable.ic_phone, Color.WHITE, 26))
            val cp = lp(MATCH, dp(76))
            cp.topMargin = dp(12)
            box.addView(card, cp)
        }
        val cancel = TextView(this)
        cancel.text = "Batal"; cancel.textSize = 15f; cancel.setTextColor(MUTED); cancel.gravity = Gravity.CENTER
        cancel.setOnClickListener { d.dismiss() }
        val cl = lp(MATCH, dp(48))
        cl.topMargin = dp(8)
        box.addView(cancel, cl)
        d.setContentView(box)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setDimAmount(0.55f)
        }
        d.show()
    }
    private fun blockNumber(n: String) {
        try {
            if (Build.VERSION.SDK_INT < 24 || !BlockedNumberContract.canCurrentUserBlockNumbers(this)) {
                toast("Jadikan DialChat aplikasi telepon utama dulu untuk memblokir nomor"); return
            }
            val v = ContentValues()
            v.put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n)
            contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v)
            toast("Nomor diblokir")
        } catch (e: Exception) { toast("Gagal memblokir nomor") }
    }
    private fun showActions(r: Row, del: (() -> Unit)? = null) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(24))
        val rad = dp(28).toFloat()
        val bg = GradientDrawable()
        bg.setColor(BG)
        bg.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
        box.background = bg
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val f = r.title.firstOrNull()
        val av = TextView(this)
        av.text = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
        av.gravity = Gravity.CENTER; av.textSize = 20f; av.setTextColor(MUTED); av.background = ov(SURF)
        head.addView(av, lp(dp(48), dp(48)))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        val n1 = TextView(this)
        n1.text = r.title; n1.textSize = 18f; n1.setTextColor(INK); n1.setTypeface(null, Typeface.BOLD)
        val n2 = TextView(this)
        n2.text = r.number; n2.textSize = 14f; n2.setTextColor(MUTED)
        ht.addView(n1); ht.addView(n2)
        val hp = lp(0, WRAP, 1f)
        hp.marginStart = dp(14)
        head.addView(ht, hp)
        box.addView(head)
        val line = View(this)
        line.setBackgroundColor(LINE)
        val lpl = lp(MATCH, dp(1))
        lpl.setMargins(0, dp(12), 0, dp(8))
        box.addView(line, lpl)
        fun item(col: Int, res: Int, label: String, lc: Int, onClick: () -> Unit) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(10), dp(4), dp(10))
            row.isClickable = true
            row.setOnClickListener { d.dismiss(); onClick() }
            val c = FrameLayout(this)
            c.background = ov(col)
            val ic = icon(res, Color.WHITE, 22)
            ic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
            c.addView(ic)
            row.addView(c, lp(dp(44), dp(44)))
            val tv = TextView(this)
            tv.text = label; tv.textSize = 17f; tv.setTextColor(lc)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = dp(16)
            row.addView(tv, tp)
            box.addView(row, lp(MATCH, WRAP))
        }
        item(BLUE, R.drawable.ic_phone, "Telepon", INK) { callNum(r.number) }
        if (normalizeWa(r.number) != null) item(GREEN, R.drawable.ic_wa, "Chat WhatsApp", INK) { openWa(r.number) }
        if (r.save) item(BLUE, R.drawable.ic_userplus, "Simpan kontak", INK) { saveContact(r.number) }
        if (del != null) item(RED, R.drawable.ic_delete, "Hapus percakapan", RED) { del() }
        if (!r.save && r.title.isNotBlank() && r.number.any { it.isDigit() }) {
            val fav = Prefs.isFav(this, r.number)
            item(Color.parseColor("#B45309"), R.drawable.ic_star, if (fav) "Hapus dari favorit" else "Favoritkan", INK) {
                Prefs.toggleFav(this, r.title, r.number)
                renderFavs()
                toast(if (fav) "Dihapus dari favorit" else "Ditambahkan ke favorit")
            }
        }
        item(RED, R.drawable.ic_block, "Blokir nomor", RED) { blockNumber(r.number) }
        d.setContentView(box)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setDimAmount(0.55f)
        }
        d.show()
    }
    private fun buildMessages(): View {
        msgPane = MessagesPane(this)
        return msgPane
    }
    fun requestSmsRole() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 78)
                    return
                }
            }
            val i = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            i.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            startActivityForResult(i, 78)
        } catch (e: Exception) { toast("Tidak bisa membuka pengaturan aplikasi SMS") }
    }
    fun showThreadActions(t: Thr) {
        val nm = CallUtil.name(this, t.address)
        val r = Row(title = nm ?: t.address, number = t.address, save = nm == null && t.address.any { it.isDigit() })
        showActions(r) { confirmDeleteThread(t) }
    }
    private fun confirmDeleteThread(t: Thr) {
        AlertDialog.Builder(this)
            .setMessage("Hapus seluruh percakapan ini?")
            .setPositiveButton("Hapus") { _, _ ->
                try {
                    contentResolver.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(t.id.toString()))
                } catch (e: Exception) { toast("Gagal menghapus percakapan") }
                msgPane.refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
    private fun isDefaultDialer(): Boolean = try {
        (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == packageName
    } catch (e: Exception) { false }
    private fun refreshRole() {
        if (!::roleBar.isInitialized) return
        roleBar.visibility = if (isDefaultDialer()) View.GONE else View.VISIBLE
    }
    private fun requestDefaultDialer() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 77)
                    return
                }
            }
            val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            startActivityForResult(i, 77)
        } catch (e: Exception) { toast("Tidak bisa membuka pengaturan aplikasi telepon") }
    }
    override fun onResume() {
        super.onResume()
        refreshRole()
        if (curTab == 3 && ::msgPane.isInitialized) msgPane.refresh()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refreshRole()
        if (::msgPane.isInitialized) msgPane.refresh()
    }
    private fun saveContact(n: String) {
        val i = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
            type = "vnd.android.cursor.item/contact"
            putExtra(ContactsContract.Intents.Insert.PHONE, n)
        }
        try { startActivity(i) } catch (e: Exception) { toast("Aplikasi Kontak tidak ditemukan") }
    }
    private fun setNumber(s: String) {
        num.setLength(0)
        num.append(s.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }.take(20))
        updateDial()
    }
    private fun press(k: String) { if (num.length < 20) { num.append(k); updateDial() } }
    private fun updateDial() {
        val s = num.toString()
        numTv.text = pretty(s); numTv.textSize = if (s.length > 14) 26f else 34f
        val w = normalizeWa(s)
        waTv.text = when { s.isEmpty() -> ""; w != null -> "WhatsApp: " + fmtWa(w); else -> "Bukan nomor WhatsApp" }
        waTv.setTextColor(if (w != null) GREEN else MUTED)
        saveTv.visibility = if (s.isEmpty()) View.INVISIBLE else View.VISIBLE
        updateSuggest(s)
        refreshClip()
    }
    private fun refreshClip() {
        if (!::pasteChip.isInitialized) return
        val t = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val c = cm.primaryClip
            if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else null
        } catch (e: Exception) { null }
        val ok = t != null && Regex("^\\+?[0-9][0-9 ().-]{6,19}$").matches(t)
        if (ok && digits(t!!) != digits(num.toString())) {
            pasteChip.text = "Tempel dari clipboard: $t"
            pasteChip.setOnClickListener { setNumber(t); pasteChip.visibility = View.GONE }
            pasteChip.visibility = View.VISIBLE
        } else pasteChip.visibility = View.GONE
    }
    private fun handleIntent(i: Intent?) {
        val d = i?.data
        if (d != null && d.scheme == "tel") {
            setNumber(Uri.decode(d.schemeSpecificPart ?: ""))
            if (i.getBooleanExtra("autocall", false)) {
                i.removeExtra("autocall")
                window.decorView.post { callNum(num.toString()) }
            }
        }
    }

    // ---------- UI ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(BG)
        val content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))
        panes = listOf(buildDial(), buildHistory(), buildContacts(), buildMessages())
        panes.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(View(this).apply { setBackgroundColor(LINE) }, lp(MATCH, dp(1)))
        root.addView(buildNav(), lp(MATCH, dp(72)))
        setContentView(root)
        showTab(intent?.getIntExtra("tab", 0) ?: 0)
        handleIntent(intent)
        val need = ArrayList<String>()
        for (p in listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS))
            if (!has(p)) need.add(p)
        if (Build.VERSION.SDK_INT >= 33 && !has("android.permission.POST_NOTIFICATIONS")) need.add("android.permission.POST_NOTIFICATIONS")
        if (Build.VERSION.SDK_INT >= 23 && need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent); showTab(intent?.getIntExtra("tab", 0) ?: 0) }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) refreshClip() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        peopleLoaded = false; showTab(curTab)
    }

    private fun buildDial(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL; p.setPadding(dp(20), dp(20), dp(20), dp(12))
        pasteChip = TextView(this).apply {
            textSize = 14f; setTextColor(INK); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            background = rr(BG, 20, LINE); setPadding(dp(16), 0, dp(16), 0); gravity = Gravity.CENTER
            compoundDrawablePadding = dp(8); visibility = View.GONE
            setCompoundDrawables(tinted(R.drawable.ic_paste, LINK, 18), null, null, null)
            layoutParams = lp(WRAP, dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        }
        roleBar = TextView(this).apply {
            text = "Jadikan DialChat aplikasi telepon utama"; textSize = 14f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; background = rr(BLUE, 20)
            setPadding(dp(16), 0, dp(16), 0); visibility = View.GONE
            setOnClickListener { requestDefaultDialer() }
            layoutParams = lp(MATCH, dp(40)).apply { bottomMargin = dp(10) }
        }
        p.addView(roleBar)
        p.addView(pasteChip)
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL; mid.gravity = Gravity.CENTER
        numTv = TextView(this).apply { textSize = 34f; setTextColor(INK); gravity = Gravity.CENTER; hint = "Ketik nomor"; setHintTextColor(Color.parseColor("#8A929E")) }
        waTv = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        saveTv = TextView(this).apply {
            text = "Simpan kontak"; textSize = 14f; setTextColor(LINK); setPadding(dp(12), dp(10), dp(12), dp(10))
            setCompoundDrawables(tinted(R.drawable.ic_userplus, LINK, 18), null, null, null); compoundDrawablePadding = dp(6)
            setOnClickListener { saveContact(num.toString()) }
        }
        mid.addView(numTv); mid.addView(waTv); mid.addView(saveTv)
        sugBox = LinearLayout(this)
        sugBox.orientation = LinearLayout.VERTICAL
        mid.addView(sugBox, lp(MATCH, WRAP))
        p.addView(mid, lp(MATCH, 0, 1f))
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (c in 0 until 3) {
                val (k, l) = keys[r * 3 + c]
                row.addView(keyView(k, l), lp(0, dp(66), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            p.addView(row, lp(MATCH, WRAP))
        }
        val act = LinearLayout(this)
        act.gravity = Gravity.CENTER_VERTICAL; act.setPadding(0, dp(12), 0, 0)
        act.addView(pillBtn(R.drawable.ic_phone, "Telepon", BLUE) { callNum(num.toString()) })
        act.addView(pillBtn(R.drawable.ic_wa, "WhatsApp", GREEN) { openWa(num.toString()) })
        val back = circleBtn(R.drawable.ic_backspace, SURF, INK, 56, "Hapus angka") {
            if (num.isNotEmpty()) { num.setLength(num.length - 1); updateDial() }
        }
        back.setOnLongClickListener { num.setLength(0); updateDial(); true }
        act.addView(back)
        p.addView(act, lp(MATCH, WRAP))
        updateDial()
        return p
    }
    private fun keyView(k: String, l: String): TextView {
        val sb = SpannableStringBuilder(k)
        if (l.isNotEmpty()) {
            val s = sb.length
            sb.append("\n").append(l)
            sb.setSpan(RelativeSizeSpan(0.36f), s, sb.length, 0)
            sb.setSpan(ForegroundColorSpan(MUTED), s, sb.length, 0)
        }
        return TextView(this).apply {
            text = sb; textSize = 28f; setTextColor(INK); gravity = Gravity.CENTER
            background = rr(SURF, 20); isClickable = true
            setOnClickListener { press(k) }
            if (k == "0") setOnLongClickListener { press("+"); true }
        }
    }

    private fun buildNav(): View {
        val nav = LinearLayout(this)
        nav.gravity = Gravity.CENTER_VERTICAL; nav.setPadding(dp(8), 0, dp(8), 0)
        val defs = listOf("Papan angka" to R.drawable.ic_dial, "Riwayat" to R.drawable.ic_clock, "Kontak" to R.drawable.ic_people, "Pesan" to R.drawable.ic_bubble)
        defs.forEachIndexed { i, (label, res) ->
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL; col.gravity = Gravity.CENTER
            col.setOnClickListener { showTab(i) }
            val pill = FrameLayout(this)
            val ic = icon(res, MUTED, 20)
            ic.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
            pill.addView(ic)
            col.addView(pill, lp(dp(56), dp(28)))
            val tv = TextView(this).apply { text = label; textSize = 12f; setTextColor(MUTED); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
            col.addView(tv)
            nav.addView(col, lp(0, MATCH, 1f))
            tabPills.add(pill); tabIcons.add(ic); tabLbls.add(tv)
        }
        return nav
    }
    fun showTab(i: Int) {
        curTab = i
        panes.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        for (k in 0..3) {
            val on = k == i
            tabPills[k].background = if (on) rr(BLUE, 14) else null
            tabIcons[k].setColorFilter(if (on) Color.WHITE else MUTED, PorterDuff.Mode.SRC_IN)
            tabLbls[k].setTextColor(if (on) LINK else MUTED)
        }
        if (i == 1) loadHistory()
        if (i == 2) loadContacts()
        if (i == 3 && ::msgPane.isInitialized) msgPane.refresh()
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 28f; setTextColor(INK); setPadding(dp(16), dp(24), dp(16), dp(8))
    }
    private fun newList() = ListView(this).apply { divider = null; setSelector(ColorDrawable(Color.TRANSPARENT)) }

    private fun buildHistory(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(title("Riwayat"), lp(0, WRAP, 1f))
        val more = FrameLayout(this)
        more.contentDescription = "Menu"
        more.isClickable = true
        val mi = icon(R.drawable.ic_more, INK, 24)
        mi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        more.addView(mi)
        more.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add(0, 1, 0, "Nomor diblokir")
            pm.menu.add(0, 2, 1, "Pesan cepat")
            pm.setOnMenuItemClickListener { mi ->
                if (mi.itemId == 2) startActivity(Intent(this, QuickRepliesActivity::class.java))
                else startActivity(Intent(this, BlockedActivity::class.java))
                true
            }
            pm.show()
        }
        val mp = lp(dp(48), dp(48))
        mp.marginEnd = dp(8); mp.topMargin = dp(16)
        head.addView(more, mp)
        p.addView(head)
        val chips = LinearLayout(this)
        chips.setPadding(dp(16), dp(8), dp(16), dp(12))
        chipAll = chip("Semua") { missedOnly = false; styleChips(); loadHistory() }
        chipMiss = chip("Tak terjawab") { missedOnly = true; styleChips(); loadHistory() }
        chips.addView(chipAll); chips.addView(chipMiss)
        p.addView(chips)
        histList = newList()
        p.addView(histList, lp(MATCH, 0, 1f))
        styleChips()
        return p
    }
    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { onClick() }
        layoutParams = lp(WRAP, dp(34)).apply { marginEnd = dp(8) }
    }
    private fun styleChips() {
        for ((c, on) in listOf(chipAll to !missedOnly, chipMiss to missedOnly)) {
            c.background = rr(if (on) BLUE else BG, 17, if (on) BLUE else LINE)
            c.setTextColor(if (on) Color.WHITE else INK)
        }
    }
    private fun buildContacts(): View {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.addView(title("Kontak"))
        searchEt = EditText(this).apply {
            hint = "Cari kontak"; textSize = 16f; background = rr(SURF, 24); setSingleLine()
            setPadding(dp(16), 0, dp(16), 0); compoundDrawablePadding = dp(10)
            setCompoundDrawables(tinted(R.drawable.ic_search, MUTED, 20), null, null, null)
            layoutParams = lp(MATCH, dp(48)).apply { setMargins(dp(16), dp(8), dp(16), dp(4)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { renderContacts(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        p.addView(searchEt)
        favScroll = HorizontalScrollView(this)
        favScroll.isHorizontalScrollBarEnabled = false
        favScroll.visibility = View.GONE
        favRow = LinearLayout(this)
        favRow.setPadding(dp(12), dp(8), dp(12), dp(4))
        favScroll.addView(favRow)
        p.addView(favScroll, lp(MATCH, WRAP))
        contList = newList()
        p.addView(contList, lp(MATCH, 0, 1f))
        return p
    }

    // ---------- data ----------
    private fun fmtTime(d: Long): String = when {
        DateUtils.isToday(d) -> SimpleDateFormat("HH.mm", Locale("id")).format(Date(d))
        DateUtils.isToday(d + 86400000L) -> "Kemarin"
        else -> SimpleDateFormat("d MMM", Locale("id")).format(Date(d))
    }
    private fun loadHistory() {
        val out = ArrayList<Row>()
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            out.add(Row(header = "Izin riwayat panggilan belum diberikan"))
        } else try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 150) {
                    val n = c.getString(0) ?: ""
                    val name = c.getString(1) ?: ""
                    val type = c.getInt(2); val d = c.getLong(3)
                    if (n.isBlank()) continue
                    val missed = type == CallLog.Calls.MISSED_TYPE
                    if (missedOnly && !missed) continue
                    val named = name.isNotBlank()
                    val sub = (if (named) "$n · " else "") + (if (missed) "Tak terjawab · " else "") + fmtTime(d)
                    out.add(Row(title = if (named) name else n, sub = sub, number = n, missed = missed,
                        arrow = if (type == CallLog.Calls.OUTGOING_TYPE) 2 else 1, save = !named))
                }
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) out.add(Row(header = "Belum ada riwayat"))
        histList.adapter = RowAdapter(out)
    }
    private fun ensurePeople() {
        if (peopleLoaded || !has(Manifest.permission.READ_CONTACTS)) return
        val list = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        try {
            contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null,
                Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: ""
                    val n = c.getString(1) ?: ""
                    if (n.isBlank() || !seen.add(name + "|" + digits(n))) continue
                    list.add(name to n)
                }
            }
        } catch (e: Exception) { }
        people = list
        peopleLoaded = true
    }
    private fun t9(name: String): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) {
            val d: Char? = when (ch) {
                'a', 'b', 'c' -> '2'
                'd', 'e', 'f' -> '3'
                'g', 'h', 'i' -> '4'
                'j', 'k', 'l' -> '5'
                'm', 'n', 'o' -> '6'
                'p', 'q', 'r', 's' -> '7'
                't', 'u', 'v' -> '8'
                'w', 'x', 'y', 'z' -> '9'
                else -> null
            }
            if (d != null) sb.append(d)
        }
        return sb.toString()
    }
    private fun updateSuggest(s: String) {
        if (!::sugBox.isInitialized) return
        sugBox.removeAllViews()
        if (s.length < 2 || !s.all { it.isDigit() }) return
        ensurePeople()
        val alt = if (s.startsWith("0")) "62" + s.drop(1) else s
        var count = 0
        for ((name, n) in people) {
            val nd = digits(n)
            val hit = nd.startsWith(s) || nd.startsWith(alt) || (s.length >= 4 && nd.contains(s)) || t9(name).contains(s)
            if (!hit) continue
            sugBox.addView(sugRow(name, n))
            count++
            if (count >= 2) break
        }
    }
    private fun sugRow(name: String, n: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = rr(SURF, 16)
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        r.isClickable = true
        r.setOnClickListener { setNumber(n) }
        val a = TextView(this)
        a.text = name; a.textSize = 15f; a.setTextColor(INK); a.setTypeface(null, Typeface.BOLD)
        a.maxLines = 1; a.ellipsize = TextUtils.TruncateAt.END
        r.addView(a, lp(0, WRAP, 1f))
        val b = TextView(this)
        b.text = n; b.textSize = 13f; b.setTextColor(MUTED); b.maxLines = 1
        val bp = lp(WRAP, WRAP)
        bp.marginStart = dp(8)
        r.addView(b, bp)
        val p = lp(MATCH, WRAP)
        p.topMargin = dp(6)
        r.layoutParams = p
        return r
    }
    private fun renderFavs() {
        if (!::favRow.isInitialized) return
        favRow.removeAllViews()
        val fav = Prefs.favs(this)
        favScroll.visibility = if (fav.isEmpty()) View.GONE else View.VISIBLE
        for ((name, number) in fav) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(8), dp(4), dp(8), dp(4))
            cell.isClickable = true
            val av = TextView(this)
            av.text = (name.firstOrNull() ?: '#').uppercaseChar().toString()
            av.gravity = Gravity.CENTER; av.textSize = 22f; av.setTextColor(Color.WHITE); av.setTypeface(null, Typeface.BOLD)
            av.background = ov(PAL[Math.abs(number.hashCode()) % PAL.size])
            cell.addView(av, lp(dp(56), dp(56)))
            val tv = TextView(this)
            tv.text = name; tv.textSize = 12f; tv.setTextColor(INK); tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER; tv.setPadding(0, dp(4), 0, 0)
            cell.addView(tv, lp(dp(64), WRAP))
            cell.setOnClickListener { callNum(number) }
            cell.setOnLongClickListener { showActions(Row(title = name, number = number)); true }
            favRow.addView(cell)
        }
    }
    private fun loadContacts() {
        renderFavs()
        if (!has(Manifest.permission.READ_CONTACTS)) {
            contList.adapter = RowAdapter(listOf(Row(header = "Izin kontak belum diberikan"))); return
        }
        ensurePeople()
        renderContacts(searchEt.text.toString())
    }
    private fun renderContacts(q: String) {
        val ql = q.trim().lowercase(); val qd = digits(ql)
        val out = ArrayList<Row>(); var last = ""
        for ((name, n) in people) {
            if (ql.isNotEmpty() && !(name.lowercase().contains(ql) || (qd.isNotEmpty() && digits(n).contains(qd)))) continue
            val f = name.firstOrNull()
            val ch = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
            if (ch != last) { out.add(Row(header = ch)); last = ch }
            out.add(Row(title = name.ifBlank { n }, sub = n, number = n))
        }
        if (out.isEmpty()) out.add(Row(header = "Tidak ada kontak"))
        contList.adapter = RowAdapter(out)
    }

    inner class RowAdapter(private val items: List<Row>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = buildRow(items[position])
    }

    private fun buildRow(r: Row): View {
        if (r.header != null) return TextView(this).apply {
            text = r.header; textSize = 13f; setTextColor(LINK); setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(12), dp(16), dp(4))
        }
        val wa = normalizeWa(r.number)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(dp(16), dp(10), dp(16), dp(10))
        val f = r.title.firstOrNull()
        val av: View = if (f != null && f.isLetter()) TextView(this).apply {
            text = f.uppercaseChar().toString(); gravity = Gravity.CENTER; textSize = 18f
            setTextColor(MUTED); background = ov(SURF)
        } else FrameLayout(this).apply {
            background = ov(SURF)
            addView(icon(R.drawable.ic_person, MUTED, 22).apply { layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER) })
        }
        row.addView(av, lp(dp(44), dp(44)))
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.addView(TextView(this).apply {
            text = r.title; textSize = 16f; setTextColor(if (r.missed) RED else INK)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        val sub = LinearLayout(this)
        sub.gravity = Gravity.CENTER_VERTICAL
        if (r.arrow != 0) sub.addView(icon(if (r.arrow == 1) R.drawable.ic_in else R.drawable.ic_out, if (r.missed) RED else MUTED, 14).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(4)
        })
        sub.addView(TextView(this).apply {
            text = r.sub; textSize = 13f; setTextColor(MUTED); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(sub)
        if (r.save) mid.addView(TextView(this).apply {
            text = "Simpan kontak"; textSize = 13f; setTextColor(LINK); setPadding(0, dp(4), dp(12), dp(4))
            setOnClickListener { saveContact(r.number) }
        })
        row.addView(mid, lp(0, WRAP, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        row.addView(circleBtn(R.drawable.ic_phone, BLUE, Color.WHITE, 44, "Telepon ${r.title}") { callNum(r.number) })
        row.addView(
            if (wa != null) circleBtn(R.drawable.ic_wa, GREEN, Color.WHITE, 44, "Chat WhatsApp ${r.title}", 8) { openWa(r.number) }
            else circleBtn(R.drawable.ic_wa, SURF, MUTED, 44, "WhatsApp tidak tersedia", 8, false) {}
        )
        row.setOnClickListener { setNumber(r.number); showTab(0) }
        row.setOnLongClickListener { showActions(r); true }
        return row
    }
}
