package id.dialchat.app

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ContactEditActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private class FieldRow(val view: View, val entry: Entry, val et: EditText)

    private var existing: ContactFull? = null
    private var sources = listOf<Source>()
    private var src: Source? = null
    private val phoneRows = ArrayList<FieldRow>()
    private val emailRows = ArrayList<FieldRow>()
    private lateinit var phoneBox: LinearLayout
    private lateinit var emailBox: LinearLayout
    private lateinit var firstEt: EditText
    private lateinit var lastEt: EditText
    private lateinit var noteEt: EditText
    private lateinit var photoHolder: FrameLayout
    private var photoBytes: ByteArray? = null

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun hasWrite() = Build.VERSION.SDK_INT < 23 ||
        checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getLongExtra("id", 0L)
        if (id > 0) {
            existing = ContactsRepo.load(this, id)
            if (existing == null) { toast(tr(R.string.s_kontak_tidak_ditemukan)); finish(); return }
        }
        val ex = existing
        val preName = intent.getStringExtra("name") ?: intent.getStringExtra(ContactsContract.Intents.Insert.NAME) ?: ""
        val prePhone = intent.getStringExtra("number") ?: intent.getStringExtra(ContactsContract.Intents.Insert.PHONE) ?: ""
        val preEmail = intent.getStringExtra(ContactsContract.Intents.Insert.EMAIL) ?: ""
        val preNote = intent.getStringExtra(ContactsContract.Intents.Insert.NOTES) ?: ""

        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val hdr = LinearLayout(this)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = cornerBg(gd, BG)
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        hdr.gravity = Gravity.CENTER_VERTICAL
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr(R.string.s_batal); back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        hdr.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val ttl = TextView(this).apply {
            text = if (ex == null) tr(R.string.s_kontak_baru) else tr(R.string.s_ubah_kontak)
            textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setPadding(dp(12), 0, 0, 0)
        }
        hdr.addView(ttl, LinearLayout.LayoutParams(0, WRAP, 1f))
        hdr.addView(TextView(this).apply {
            text = tr(R.string.s_simpan); textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(18), 0, dp(18), 0)
            background = rr(Color.argb(46, 255, 255, 255), 22)
            isClickable = true; setOnClickListener { trySave() }
        }, LinearLayout.LayoutParams(WRAP, dp(44)))
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(20), dp(16), dp(32))
        sv.addView(body)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = simpleCollapse(hdr, back, ttl, 22f, 19f, 112, 68)
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))

        var f = ex?.first ?: ""
        var l = ex?.last ?: ""
        if (ex != null && f.isBlank() && l.isBlank()) { f = ex.display.substringBefore(' '); l = ex.display.substringAfter(' ', "") }
        if (ex == null && preName.isNotBlank()) { f = preName.substringBefore(' '); l = preName.substringAfter(' ', "") }
        photoHolder = FrameLayout(this)
        photoHolder.background = ov(col(R.color.surf))
        photoHolder.isClickable = true; photoHolder.contentDescription = tr(R.string.s_pilih_foto)
        photoHolder.setOnClickListener { pickPhoto() }
        showPhoto(Photos.get(this, ex?.photoUri))
        body.addView(photoHolder, LinearLayout.LayoutParams(dp(88), dp(88)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        body.addView(TextView(this).apply {
            text = tr(R.string.s_pilih_foto); textSize = 14f; setTextColor(LINK); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)); isClickable = true
            setOnClickListener { pickPhoto() }
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        val cap = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        firstEt = edit(f, tr(R.string.s_nama_depan), cap)
        lastEt = edit(l, tr(R.string.s_nama_belakang), cap)
        body.addView(box(tr(R.string.s_nama_depan), firstEt), gap())
        body.addView(box(tr(R.string.s_nama_belakang), lastEt), gap())

        phoneBox = LinearLayout(this); phoneBox.orientation = LinearLayout.VERTICAL
        body.addView(phoneBox, LinearLayout.LayoutParams(MATCH, WRAP))
        val phones = ex?.phones ?: if (prePhone.isNotBlank()) listOf(Entry(prePhone, ContactsRepo.PHONE_TYPES[0])) else emptyList()
        if (phones.isEmpty()) addRow(true, Entry("", ContactsRepo.PHONE_TYPES[0])) else phones.forEach { addRow(true, Entry(it.value, it.type, it.label)) }
        body.addView(addLink(tr(R.string.s_tambah_nomor)) { addRow(true, Entry("", ContactsRepo.PHONE_TYPES[0])) }, gap())

        emailBox = LinearLayout(this); emailBox.orientation = LinearLayout.VERTICAL
        body.addView(emailBox, LinearLayout.LayoutParams(MATCH, WRAP))
        val emails = ex?.emails ?: if (preEmail.isNotBlank()) listOf(Entry(preEmail, ContactsRepo.EMAIL_TYPES[0])) else emptyList()
        emails.forEach { addRow(false, Entry(it.value, it.type, it.label)) }
        body.addView(addLink(tr(R.string.s_tambah_email)) { addRow(false, Entry("", ContactsRepo.EMAIL_TYPES[0])) }, gap())

        noteEt = edit(ex?.note ?: preNote, tr(R.string.s_catatan), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        noteEt.minLines = 2
        body.addView(box(tr(R.string.s_catatan), noteEt), gap())

        if (ex == null) {
            sources = ContactsRepo.sources(this)
            src = sources.getOrNull(1) ?: sources[0]
            val tv = TextView(this)
            tv.text = src!!.label; tv.textSize = 16f; tv.setTextColor(INK); tv.setPadding(0, dp(2), 0, dp(2))
            val sb = box(tr(R.string.s_simpan_ke), tv)
            sb.isClickable = true
            sb.setOnClickListener {
                val names = sources.map { it.label }.toTypedArray()
                AlertDialog.Builder(this).setTitle(tr(R.string.s_simpan_ke)).setItems(names) { _, i ->
                    src = sources[i]; tv.text = sources[i].label
                }.show()
            }
            body.addView(sb, gap())
        } else {
            body.addView(box("Disimpan di", TextView(this).apply {
                text = ex.source.label; textSize = 16f; setTextColor(MUTED); setPadding(0, dp(2), 0, dp(2))
            }), gap())
        }
        setContentView(root)
    }

    private fun showPhoto(bmp: Bitmap?) {
        photoHolder.removeAllViews()
        if (bmp != null) photoHolder.addView(photoView(bmp), FrameLayout.LayoutParams(MATCH, MATCH))
        else photoHolder.addView(icon(R.drawable.ic_person, MUTED, 40).apply {
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER)
        })
    }

    private fun pickPhoto() {
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 41) }
        catch (e: Exception) { toast(tr(R.string.s_pemilih_gambar_tidak_ditemukan)) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode == 41 && resultCode == RESULT_OK && u != null) {
            val bytes = Photos.encode(this, u)
            if (bytes == null) { toast(tr(R.string.s_gambar_tidak_bisa_dibaca)); return }
            photoBytes = bytes
            showPhoto(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
        }
    }

    private fun gap() = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }

    private fun edit(text: String, hint: String, type: Int) = EditText(this).apply {
        setText(text); this.hint = hint; textSize = 16f; setTextColor(INK); setHintTextColor(MUTED)
        background = null; setPadding(0, dp(2), 0, dp(2)); inputType = type
    }

    private fun box(label: String, v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = rr(BG, 10, LINE)
        l.setPadding(dp(14), dp(8), dp(14), dp(8))
        l.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(MUTED) })
        l.addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        return l
    }

    private fun addLink(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = "+ $label"; textSize = 15f; setTextColor(LINK); setTypeface(null, Typeface.BOLD)
        setPadding(dp(4), dp(6), dp(4), dp(6)); isClickable = true
        setOnClickListener { onClick() }
    }

    private fun addRow(isPhone: Boolean, e: Entry) {
        val rows = if (isPhone) phoneRows else emailRows
        val boxV = if (isPhone) phoneBox else emailBox
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val et = edit(e.value, if (isPhone) tr(R.string.s_nomor_telepon) else tr(R.string.s_alamat_email),
            if (isPhone) InputType.TYPE_CLASS_PHONE else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        row.addView(box(if (isPhone) tr(R.string.s_telepon) else tr(R.string.s_email), et), LinearLayout.LayoutParams(0, WRAP, 1f))
        val typeTv = TextView(this).apply {
            text = if (isPhone) ContactsRepo.phoneTypeName(e.type, e.label) else ContactsRepo.emailTypeName(e.type, e.label)
            textSize = 14f; setTextColor(LINK); setTypeface(null, Typeface.BOLD)
            setPadding(dp(10), dp(12), dp(6), dp(12)); isClickable = true
        }
        typeTv.setOnClickListener {
            val types = if (isPhone) ContactsRepo.PHONE_TYPES else ContactsRepo.EMAIL_TYPES
            val names = types.map { if (isPhone) ContactsRepo.phoneTypeName(it, "") else ContactsRepo.emailTypeName(it, "") }.toTypedArray()
            AlertDialog.Builder(this).setItems(names) { _, i ->
                e.type = types[i]; e.label = ""; typeTv.text = names[i]
            }.show()
        }
        row.addView(typeTv, LinearLayout.LayoutParams(WRAP, WRAP))
        val fr = FieldRow(row, e, et)
        val del = FrameLayout(this)
        del.contentDescription = tr(R.string.s_hapus_baris); del.isClickable = true
        val di = icon(R.drawable.ic_delete, MUTED, 20)
        di.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        del.addView(di)
        del.setOnClickListener {
            if (isPhone && rows.size <= 1) { et.setText(""); return@setOnClickListener }
            rows.remove(fr); boxV.removeView(row)
        }
        row.addView(del, LinearLayout.LayoutParams(dp(36), dp(44)))
        rows.add(fr)
        boxV.addView(row, gap())
    }

    private fun collect(rows: List<FieldRow>): List<Entry> =
        rows.mapNotNull { r ->
            val v = r.et.text.toString().trim()
            if (v.isEmpty()) null else Entry(v, r.entry.type, r.entry.label)
        }

    private fun trySave() {
        val first = firstEt.text.toString().trim()
        val last = lastEt.text.toString().trim()
        val phones = collect(phoneRows)
        val emails = collect(emailRows)
        if (first.isEmpty() && last.isEmpty() && phones.isEmpty() && emails.isEmpty()) {
            toast(tr(R.string.s_isi_nama_atau_nomor_dulu)); return
        }
        if (!hasWrite()) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_CONTACTS), 22)
            return
        }
        val id = ContactsRepo.save(this, existing, first, last, phones, emails, noteEt.text.toString().trim(), src, photoBytes)
        if (id < 0) toast(tr(R.string.s_gagal_menyimpan_kontak)) else { toast(tr(R.string.s_kontak_disimpan)); finish() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) trySave()
            else toast(tr(R.string.s_izin_mengubah_kontak_diperlukan))
        }
    }
}
