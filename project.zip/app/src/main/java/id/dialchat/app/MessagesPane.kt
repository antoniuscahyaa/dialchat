package id.dialchat.app

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.provider.Telephony
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Thr(val id: Long, val address: String, val body: String, val date: Long, val unread: Int, val type: Int)

class MessagesPane(private val act: MainActivity) : FrameLayout(act) {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val INK = act.col(R.color.ink)
    private val MUTED = act.col(R.color.muted)
    private val SURF = act.col(R.color.surf)
    private val GL = Color.argb(46, 255, 255, 255)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val pal = intArrayOf(BLUE, GREEN, Color.parseColor("#6D28D9"), Color.parseColor("#B45309"), RED)
    private val otp = Regex("(?i)(otp|kode|verifikasi|verification|\\bcode\\b)")
    private val names = HashMap<String, String?>()
    private var all: List<Thr> = emptyList()
    private var filter = 0
    private val sub = TextView(act)
    private val chips = ArrayList<TextView>()
    private val search = EditText(act)
    private val list = ListView(act)
    private val listWrap = LinearLayout(act)
    private val activateView = FrameLayout(act)
    private val fab = LinearLayout(act)

    private fun dp(v: Int) = act.dp(v)

    init {
        buildList()
        buildActivate()
        addView(listWrap, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(activateView, FrameLayout.LayoutParams(MATCH, MATCH))
        val fp = FrameLayout.LayoutParams(WRAP, dp(56), Gravity.BOTTOM or Gravity.END)
        fp.setMargins(0, 0, dp(16), dp(16))
        addView(fab, fp)
        styleChips()
    }

    private fun ring(parent: FrameLayout, size: Int, al: Int, cy: Int) {
        val v = View(act)
        v.background = act.ov(Color.argb(al, 255, 255, 255))
        val p = FrameLayout.LayoutParams(dp(size), dp(size), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        p.topMargin = dp(cy - size / 2)
        parent.addView(v, p)
    }

    private fun buildList() {
        listWrap.orientation = LinearLayout.VERTICAL
        val hdr = FrameLayout(act)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = gd
        for ((size, al) in listOf(220 to 26, 340 to 15)) {
            val v = View(act)
            v.background = act.ov(Color.argb(al, 255, 255, 255))
            val p = FrameLayout.LayoutParams(dp(size), dp(size), Gravity.TOP or Gravity.END)
            p.setMargins(0, -dp(size / 3), -dp(size / 3), 0)
            hdr.addView(v, p)
        }
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(52), dp(20), dp(20))
        val top = LinearLayout(act)
        top.gravity = Gravity.CENTER_VERTICAL
        val tcol = LinearLayout(act)
        tcol.orientation = LinearLayout.VERTICAL
        val title = TextView(act)
        title.text = "Pesan"; title.textSize = 32f; title.setTextColor(Color.WHITE); title.setTypeface(null, Typeface.BOLD)
        sub.textSize = 14f; sub.setTextColor(Color.argb(224, 255, 255, 255))
        tcol.addView(title); tcol.addView(sub)
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sb = FrameLayout(act)
        sb.background = act.ov(GL)
        sb.contentDescription = "Cari pesan"
        sb.isClickable = true
        val sic = act.icon(R.drawable.ic_search, Color.WHITE, 22)
        sic.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        sb.addView(sic)
        sb.setOnClickListener {
            if (search.visibility == View.GONE) { search.visibility = View.VISIBLE; search.requestFocus() }
            else { search.setText(""); search.visibility = View.GONE }
        }
        top.addView(sb, LinearLayout.LayoutParams(dp(48), dp(48)))
        col.addView(top)
        val cr = LinearLayout(act)
        cr.background = act.rr(GL, 24); cr.setPadding(dp(4), dp(4), dp(4), dp(4))
        listOf("Semua", "Belum dibaca", "Kode OTP").forEachIndexed { i, t ->
            val c = TextView(act)
            c.text = t; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
            c.maxLines = 1
            c.setOnClickListener { filter = i; styleChips(); render() }
            cr.addView(c, LinearLayout.LayoutParams(0, dp(40), 1f))
            chips.add(c)
        }
        val crp = LinearLayout.LayoutParams(MATCH, WRAP)
        crp.topMargin = dp(18)
        col.addView(cr, crp)
        search.hint = "Cari pesan"; search.textSize = 16f
        search.setTextColor(Color.parseColor("#14181F")); search.setHintTextColor(Color.parseColor("#5B6472"))
        search.background = act.rr(Color.WHITE, 24); search.setPadding(dp(18), 0, dp(18), 0)
        search.setSingleLine(); search.visibility = View.GONE
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val sp = LinearLayout.LayoutParams(MATCH, dp(48))
        sp.topMargin = dp(12)
        col.addView(search, sp)
        hdr.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        listWrap.addView(hdr, LinearLayout.LayoutParams(MATCH, WRAP))
        list.divider = null
        list.setSelector(ColorDrawable(Color.TRANSPARENT))
        list.setPadding(dp(8), dp(12), dp(8), dp(88))
        list.clipToPadding = false
        listWrap.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        fab.gravity = Gravity.CENTER
        fab.background = act.rr(BLUE, 28)
        fab.setPadding(dp(22), 0, dp(22), 0)
        fab.isClickable = true
        fab.setOnClickListener { act.startActivity(Intent(act, NewMessageActivity::class.java)) }
        fab.addView(act.icon(R.drawable.ic_edit, Color.WHITE, 22))
        val ft = TextView(act)
        ft.text = "Pesan baru"; ft.textSize = 16f; ft.setTextColor(Color.WHITE); ft.setTypeface(null, Typeface.BOLD)
        ft.setPadding(dp(10), 0, 0, 0)
        fab.addView(ft)
    }

    private fun buildActivate() {
        activateView.setBackgroundColor(BLUE)
        ring(activateView, 300, 26, 250)
        ring(activateView, 430, 18, 250)
        ring(activateView, 560, 13, 250)
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(32), dp(190), dp(32), 0)
        val circle = FrameLayout(act)
        circle.background = act.ov(Color.WHITE)
        val ic = act.icon(R.drawable.ic_stat_msg, BLUE, 56)
        ic.layoutParams = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER)
        circle.addView(ic)
        col.addView(circle, LinearLayout.LayoutParams(dp(120), dp(120)))
        val t = TextView(act)
        t.text = "Jadikan DialChat aplikasi SMS utama"; t.textSize = 26f; t.setTextColor(Color.WHITE)
        t.setTypeface(null, Typeface.BOLD); t.gravity = Gravity.CENTER
        val tp = LinearLayout.LayoutParams(WRAP, WRAP)
        tp.topMargin = dp(28)
        col.addView(t, tp)
        val d = TextView(act)
        d.text = "Pesan lama tetap aman, dan Anda bisa kembali ke aplikasi lama kapan saja lewat Pengaturan."
        d.textSize = 16f; d.setTextColor(Color.argb(230, 255, 255, 255)); d.gravity = Gravity.CENTER
        val dpp = LinearLayout.LayoutParams(WRAP, WRAP)
        dpp.topMargin = dp(14)
        col.addView(d, dpp)
        val btn = TextView(act)
        btn.text = "Jadikan aplikasi SMS utama"; btn.textSize = 17f; btn.setTextColor(BLUE); btn.setTypeface(null, Typeface.BOLD)
        btn.gravity = Gravity.CENTER; btn.background = act.rr(Color.WHITE, 30); btn.isClickable = true
        btn.setOnClickListener { act.requestSmsRole() }
        val bp = LinearLayout.LayoutParams(MATCH, dp(60))
        bp.topMargin = dp(32)
        col.addView(btn, bp)
        val later = TextView(act)
        later.text = "Nanti saja"; later.textSize = 15f; later.setTextColor(Color.argb(230, 255, 255, 255)); later.gravity = Gravity.CENTER
        later.isClickable = true
        later.setOnClickListener { act.showTab(0) }
        col.addView(later, LinearLayout.LayoutParams(MATCH, dp(48)))
        activateView.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun styleChips() {
        for (i in 0 until chips.size) {
            val on = i == filter
            chips[i].background = if (on) act.rr(Color.WHITE, 20) else null
            chips[i].setTextColor(if (on) BLUE else Color.WHITE)
        }
    }

    fun refresh() {
        if (!SmsUtil.isDefault(act)) {
            listWrap.visibility = View.GONE; fab.visibility = View.GONE; activateView.visibility = View.VISIBLE
            return
        }
        activateView.visibility = View.GONE; listWrap.visibility = View.VISIBLE; fab.visibility = View.VISIBLE
        all = if (act.has(Manifest.permission.READ_SMS)) load() else emptyList()
        render()
    }

    private fun load(): List<Thr> {
        val latest = LinkedHashMap<Long, Thr>()
        val unread = HashMap<Long, Int>()
        try {
            act.contentResolver.query(
                Telephony.Sms.CONTENT_URI, arrayOf("thread_id", "address", "body", "date", "read", "type"),
                null, null, "date DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 3000) {
                    n++
                    val tid = c.getLong(0)
                    val read = c.getInt(4)
                    val type = c.getInt(5)
                    if (!latest.containsKey(tid)) latest[tid] = Thr(tid, c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), 0, type)
                    if (read == 0 && type == Telephony.Sms.MESSAGE_TYPE_INBOX) unread[tid] = (unread[tid] ?: 0) + 1
                }
            }
        } catch (e: Exception) { }
        return latest.values.map { Thr(it.id, it.address, it.body, it.date, unread[it.id] ?: 0, it.type) }
    }

    private fun nameOf(a: String): String? {
        if (!names.containsKey(a)) names[a] = CallUtil.name(act, a)
        return names[a]
    }

    private fun render() {
        val q = search.text.toString().trim().lowercase()
        val total = all.sumOf { it.unread }
        sub.text = if (!act.has(Manifest.permission.READ_SMS)) "Izin SMS belum diberikan" else if (total > 0) "$total belum dibaca" else "Tidak ada pesan baru"
        if (chips.size > 1) chips[1].text = "Belum dibaca" + (if (total > 0) " · $total" else "")
        val shown = all.filter { t ->
            val okFilter = when (filter) {
                1 -> t.unread > 0
                2 -> otp.containsMatchIn(t.body)
                else -> true
            }
            okFilter && (q.isEmpty() || t.body.lowercase().contains(q) || (nameOf(t.address) ?: "").lowercase().contains(q) || t.address.contains(q))
        }
        list.adapter = Adapter(shown)
    }

    private fun fmt(d: Long): String = when {
        DateUtils.isToday(d) -> SimpleDateFormat("HH.mm", Locale("id")).format(Date(d))
        DateUtils.isToday(d + 86400000L) -> "Kemarin"
        else -> SimpleDateFormat("d MMM", Locale("id")).format(Date(d))
    }

    private inner class Adapter(val items: List<Thr>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = row(items[position])
    }

    private fun row(t: Thr): View {
        val u = t.unread > 0
        val nm = nameOf(t.address)
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(12), dp(12), dp(12), dp(12))
        if (u) r.background = act.rr(SURF, 22)
        val f = nm?.firstOrNull()
        val av: View
        if (f != null && f.isLetter()) {
            val a = TextView(act)
            a.text = f.uppercaseChar().toString(); a.gravity = Gravity.CENTER; a.textSize = 19f
            a.setTextColor(Color.WHITE); a.setTypeface(null, Typeface.BOLD)
            av = a
        } else {
            val fl = FrameLayout(act)
            val ic = act.icon(R.drawable.ic_person, Color.WHITE, 24)
            ic.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
            fl.addView(ic)
            av = fl
        }
        av.background = act.ov(pal[Math.abs(t.address.hashCode()) % pal.size])
        r.addView(av, LinearLayout.LayoutParams(dp(48), dp(48)))
        val mid = LinearLayout(act)
        mid.orientation = LinearLayout.VERTICAL
        val n = TextView(act)
        n.text = nm ?: prettyNum(t.address); n.textSize = 16f; n.setTextColor(INK); n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        n.setTypeface(null, if (u) Typeface.BOLD else Typeface.NORMAL)
        mid.addView(n)
        val p = TextView(act)
        val mine = t.type != Telephony.Sms.MESSAGE_TYPE_INBOX
        p.text = (if (mine) "Anda: " else "") + t.body.replace('\n', ' ')
        p.textSize = 14f; p.setTextColor(if (u) INK else MUTED); p.maxLines = 1; p.ellipsize = TextUtils.TruncateAt.END
        mid.addView(p)
        val mp = LinearLayout.LayoutParams(0, WRAP, 1f)
        mp.marginStart = dp(14); mp.marginEnd = dp(8)
        r.addView(mid, mp)
        val right = LinearLayout(act)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        val tm = TextView(act)
        tm.text = fmt(t.date); tm.textSize = 12f
        tm.setTextColor(if (u) BLUE else MUTED)
        if (u) tm.setTypeface(null, Typeface.BOLD)
        right.addView(tm)
        if (u) {
            val b = TextView(act)
            b.text = t.unread.toString(); b.textSize = 12f; b.setTextColor(Color.WHITE); b.setTypeface(null, Typeface.BOLD)
            b.gravity = Gravity.CENTER; b.background = act.rr(BLUE, 11); b.setPadding(dp(6), 0, dp(6), 0)
            b.minWidth = dp(22)
            val bp = LinearLayout.LayoutParams(WRAP, dp(22))
            bp.topMargin = dp(6)
            right.addView(b, bp)
        }
        r.addView(right, LinearLayout.LayoutParams(WRAP, WRAP))
        r.isClickable = true
        r.setOnClickListener {
            act.startActivity(Intent(act, ThreadActivity::class.java).putExtra("address", t.address))
        }
        r.setOnLongClickListener { act.showThreadActions(t); true }
        return r
    }
}
