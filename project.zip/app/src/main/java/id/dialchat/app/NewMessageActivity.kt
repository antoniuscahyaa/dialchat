package id.dialchat.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class NewMessageActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val pal = intArrayOf(BLUE, Color.parseColor("#0F7A41"), Color.parseColor("#6D28D9"), Color.parseColor("#B45309"), Color.parseColor("#B42318"))
    private var people = listOf<Pair<String, String>>()
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdr = LinearLayout(this)
        hdr.orientation = LinearLayout.VERTICAL
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = gd
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr("Kembali")
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        top.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = tr("Pesan baru"); t.textSize = 26f; t.setTextColor(Color.WHITE); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(12), 0, 0, 0)
        top.addView(t)
        hdr.addView(top)
        val pill = LinearLayout(this)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = rr(Color.WHITE, 26)
        pill.setPadding(dp(18), 0, dp(18), 0)
        val lb = TextView(this)
        lb.text = tr("Kepada"); lb.textSize = 14f; lb.setTextColor(Color.parseColor("#5B6472")); lb.setTypeface(null, Typeface.BOLD)
        pill.addView(lb)
        val to = EditText(this)
        to.setSingleLine(); to.textSize = 17f; to.setTextColor(Color.parseColor("#14181F"))
        to.background = null; to.setPadding(dp(12), 0, 0, 0)
        to.hint = tr("Nama atau nomor"); to.setHintTextColor(Color.parseColor("#8A929E"))
        to.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        pill.addView(to, LinearLayout.LayoutParams(0, MATCH, 1f))
        val pp = LinearLayout.LayoutParams(MATCH, dp(52))
        pp.topMargin = dp(18)
        hdr.addView(pill, pp)
        val sv = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8), dp(12), dp(8), dp(12))
        sv.addView(list)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = Collapse(hdr, dp(182), dp(120)) { p ->
            hdr.setPadding(dp(20), lerpI(dp(44), dp(14), p), dp(20), lerpI(dp(24), dp(10), p))
            t.textSize = lerpF(26f, 20f, p)
            back.setSquare(lerpI(dp(44), dp(40), p))
            pp.height = lerpI(dp(52), dp(48), p)
            pp.topMargin = lerpI(dp(18), dp(8), p)
            pill.layoutParams = pp
        }
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        loadPeople()
        render("")
    }

    private fun loadPeople() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return
        val out = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        try {
            val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            contentResolver.query(p, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: ""
                    val n = c.getString(1) ?: ""
                    if (n.isBlank() || !seen.add(name + "|" + n.filter { it.isDigit() })) continue
                    out.add(name to n)
                }
            }
        } catch (e: Exception) { }
        people = out
    }

    private fun open(addr: String) {
        val i = Intent(this, ThreadActivity::class.java).putExtra("address", addr)
        val fw = intent.getStringExtra("forward")
        if (fw != null) i.putExtra("sms_body", fw)
        startActivity(i)
        finish()
    }

    private fun row(label: String, sub: String?, color: Int, letter: String?, addr: String): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(12), dp(10), dp(12), dp(10))
        r.isClickable = true
        r.setOnClickListener { open(addr) }
        val av = TextView(this)
        av.gravity = Gravity.CENTER; av.textSize = 18f; av.setTextColor(Color.WHITE); av.setTypeface(null, Typeface.BOLD)
        av.background = ov(color)
        if (letter != null) av.text = letter else av.text = "›"
        r.addView(av, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val a = TextView(this)
        a.text = label; a.textSize = 16f; a.setTextColor(INK)
        col.addView(a)
        if (sub != null) {
            val b = TextView(this)
            b.text = sub; b.textSize = 13f; b.setTextColor(MUTED)
            col.addView(b)
        }
        val cp = LinearLayout.LayoutParams(0, WRAP, 1f)
        cp.marginStart = dp(14)
        r.addView(col, cp)
        return r
    }

    private fun render(q: String) {
        list.removeAllViews()
        val ql = q.trim().lowercase()
        val qd = q.filter { it.isDigit() }
        var n = 0
        for ((name, num) in people) {
            if (ql.isNotEmpty() && !(name.lowercase().contains(ql) || (qd.isNotEmpty() && num.filter { it.isDigit() }.contains(qd)))) continue
            val f = name.firstOrNull()
            val letter = if (f != null && f.isLetter()) f.uppercaseChar().toString() else "#"
            list.addView(row(name.ifBlank { num }, num, pal[Math.abs(num.hashCode()) % pal.size], letter, num))
            n++
            if (n >= 12) break
        }
        if (qd.length >= 3 && q.all { it.isDigit() || it == '+' || it == ' ' || it == '-' }) {
            list.addView(row(tr("Kirim ke ") + q.trim(), null, BLUE, null, q.trim()))
        }
    }
}
