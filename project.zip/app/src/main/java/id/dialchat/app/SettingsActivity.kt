package id.dialchat.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val SURF by lazy { col(R.color.surf) }
    private val BG by lazy { col(R.color.bg) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var body: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdr = LinearLayout(this)
        hdr.gravity = Gravity.CENTER_VERTICAL
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = gd
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr("Kembali")
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        hdr.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = tr("Pengaturan"); t.textSize = 26f; t.setTextColor(Color.WHITE); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(12), 0, 0, 0)
        hdr.addView(t)
        val sv = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(20), dp(8), dp(20), dp(24))
        sv.addView(body)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = simpleCollapse(hdr, back, t, 26f, 20f, 112, 64)
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) build()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (::body.isInitialized) build()
    }

    private fun section(t: String) {
        val v = TextView(this)
        v.text = t; v.textSize = 13f; v.setTextColor(LINK); v.setTypeface(null, Typeface.BOLD)
        v.setPadding(dp(4), dp(20), 0, dp(8))
        body.addView(v)
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rr(SURF, 20)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.bottomMargin = dp(10)
        body.addView(c, p)
        return c
    }

    private fun label(parent: LinearLayout, title: String, sub: String?) {
        val a = TextView(this)
        a.text = title; a.textSize = 16f; a.setTextColor(INK); a.setTypeface(null, Typeface.BOLD)
        parent.addView(a)
        if (sub != null) {
            val b = TextView(this)
            b.text = sub; b.textSize = 13f; b.setTextColor(MUTED)
            b.setPadding(0, dp(2), 0, 0)
            parent.addView(b)
        }
    }

    private fun statusRow(title: String, ok: Boolean, sms: Boolean, code: Int) {
        val c = card()
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        label(col, title, if (ok) tr("Aktif") else tr("Belum menjadi aplikasi utama"))
        c.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (!ok) {
            val b = TextView(this)
            b.text = tr("Aktifkan"); b.textSize = 14f; b.setTextColor(Color.WHITE); b.setTypeface(null, Typeface.BOLD)
            b.gravity = Gravity.CENTER; b.background = rr(BLUE, 20); b.setPadding(dp(18), 0, dp(18), 0)
            b.isClickable = true
            b.setOnClickListener { Roles.request(this, sms, code) }
            c.addView(b, LinearLayout.LayoutParams(WRAP, dp(40)))
        } else {
            val k = TextView(this)
            k.text = "✓"; k.textSize = 20f; k.setTextColor(GREEN); k.setTypeface(null, Typeface.BOLD)
            c.addView(k)
        }
    }

    private fun chips(parent: LinearLayout, opts: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        opts.forEachIndexed { i, o ->
            val c = TextView(this)
            c.text = o; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
            c.setPadding(dp(16), 0, dp(16), 0)
            val on = i == selected
            c.background = rr(if (on) BLUE else BG, 18, if (on) BLUE else LINE)
            c.setTextColor(if (on) Color.WHITE else INK)
            c.isClickable = true
            c.setOnClickListener { onPick(i) }
            val p = LinearLayout.LayoutParams(WRAP, dp(36))
            p.marginEnd = dp(8)
            row.addView(c, p)
        }
        val rp = LinearLayout.LayoutParams(MATCH, WRAP)
        rp.topMargin = dp(10)
        parent.addView(row, rp)
    }

    private fun linkRow(title: String, sub: String, target: Class<*>) {
        val c = card()
        label(c, title, sub)
        c.isClickable = true
        c.setOnClickListener { startActivity(Intent(this, target)) }
    }

    private fun build() {
        body.removeAllViews()
        section(tr("APLIKASI UTAMA"))
        statusRow(tr("Aplikasi telepon"), Roles.isDialer(this), false, 1)
        statusRow(tr("Aplikasi SMS"), Roles.isSms(this), true, 2)

        section(tr("TAMPILAN"))
        val th = card()
        label(th, tr("Tema"), tr("Ikut sistem, terang, atau gelap"))
        chips(th, listOf(tr("Ikut sistem"), tr("Terang"), tr("Gelap")), Prefs.theme(this)) { v ->
            Prefs.setTheme(this, v)
            recreate()
        }

        val lg = card()
        label(lg, tr("Bahasa"), tr("Pilih bahasa tampilan aplikasi"))
        chips(lg, listOf(tr("Ikut sistem"), "Bahasa Indonesia", "English"), Prefs.lang(this)) { v ->
            if (v != Prefs.lang(this)) {
                Prefs.setLang(this, v)
                recreate()
            }
        }

        section(tr("ANTI SPAM"))
        val sp = card()
        label(sp, tr("Panggilan dari nomor tak dikenal"), tr("Nomor yang tidak ada di kontak, termasuk nomor tersembunyi. Pilih Senyapkan agar tidak berdering, atau Tolak untuk menolaknya otomatis."))
        chips(sp, listOf(tr("Normal"), tr("Senyapkan"), tr("Tolak")), Prefs.spamMode(this)) { v ->
            Prefs.setSpamMode(this, v)
            build()
        }
        val note = card()
        label(note, tr("Nomor diblokir"), tr("Panggilan dan notifikasi SMS dari nomor yang diblokir tidak akan berbunyi."))

        section(tr("LAINNYA"))
        linkRow(tr("Pesan cepat"), tr("Template untuk menolak panggilan dengan pesan"), QuickRepliesActivity::class.java)
        linkRow(tr("Nomor diblokir"), tr("Kelola, ekspor, dan impor daftar blokir"), BlockedActivity::class.java)

        section(tr("TENTANG"))
        val ab = card()
        label(ab, "DialChat 2.6", tr("Aplikasi telepon dan SMS"))
    }
}
