package id.dialchat.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.app.AlertDialog
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val SURF by lazy { col(R.color.surf) }
    private val BG by lazy { col(R.color.bg) }
    private val LINE by lazy { col(R.color.line) }
    private val LINK by lazy { col(R.color.link) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var body: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdr = LinearLayout(this)
        hdr.gravity = Gravity.CENTER_VERTICAL
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        hdr.background = cornerBg(gd, BG)
        hdr.setPadding(dp(20), dp(44), dp(20), dp(24))
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr(R.string.s_kembali)
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        hdr.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = TextView(this)
        t.text = tr(R.string.s_pengaturan); t.textSize = 26f; t.setTextColor(Color.WHITE); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(12), 0, 0, 0)
        hdr.addView(t)
        val sv = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(20), dp(8), dp(20), dp(24))
        sv.addView(body)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = simpleCollapse(hdr, back, t, 26f, 20f, 112, 64)
        area.addView(hdr, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) build()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (resultCode == RESULT_OK && u != null) {
            if (requestCode == 51) {
                try {
                    contentResolver.openOutputStream(u)?.use { it.write(Prefs.exportJson(this).toByteArray()) }
                    toast(tr(R.string.s_pengaturan_dicadangkan))
                } catch (e: Exception) { logW("SettingsActivity", e); toast(tr(R.string.s_gagal_mencadangkan_pengaturan)) }
            } else if (requestCode == 52) {
                try {
                    val txt = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
                    Prefs.importJson(this, txt)
                    toast(tr(R.string.s_pengaturan_dipulihkan))
                    recreate()
                    return
                } catch (e: Exception) { logW("SettingsActivity", e); toast(tr(R.string.s_gagal_memulihkan_pengaturan)) }
            }
        }
        if (::body.isInitialized) build()
    }

    private fun pickFile(create: Boolean) {
        val i = Intent(if (create) Intent.ACTION_CREATE_DOCUMENT else Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (create) "application/json" else "*/*"
        if (create) i.putExtra(Intent.EXTRA_TITLE, "dialchat-pengaturan.json")
        try { startActivityForResult(i, if (create) 51 else 52) } catch (e: Exception) { toast(tr(R.string.s_tidak_bisa_membuka_pemilih_file)) }
    }

    private fun speedDialCard() {
        val c = card()
        val sub = TextView(this)
        sub.text = tr(R.string.s_tahan_tombol_2_9_di_dialpad); sub.textSize = 13f; sub.setTextColor(MUTED)
        sub.setPadding(0, 0, 0, dp(6))
        c.addView(sub)
        val map = Prefs.speedDial(this)
        for (d in '2'..'9') {
            val k = d.toString()
            val e = map[k]
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(10), 0, dp(10))
            r.isClickable = true
            val dg = TextView(this)
            dg.text = k; dg.textSize = 18f; dg.setTypeface(null, Typeface.BOLD); dg.setTextColor(BLUE); dg.gravity = Gravity.CENTER
            r.addView(dg, LinearLayout.LayoutParams(dp(32), WRAP))
            val tv = TextView(this)
            tv.text = if (e != null) e.first + " · " + e.second else tr(R.string.s_belum_diatur)
            tv.textSize = 15f; tv.setTextColor(if (e != null) INK else MUTED)
            r.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            r.setOnClickListener { editSpeed(k, e != null) }
            c.addView(r)
        }
    }

    private fun editSpeed(k: String, assigned: Boolean) {
        val pick = { pickContact(tr(R.string.s_panggilan_cepat_n, k)) { n, p -> Prefs.setSpeedDial(this, k, n, p); build() } }
        if (!assigned) { pick(); return }
        AlertDialog.Builder(this).setTitle(tr(R.string.s_panggilan_cepat_n, k))
            .setItems(arrayOf(tr(R.string.s_ganti_kontak), tr(R.string.s_hapus))) { _, i ->
                if (i == 0) pick() else { Prefs.setSpeedDial(this, k, null, null); build() }
            }
            .show()
    }

    private fun backupCard() {
        val c = card()
        label(c, tr(R.string.s_cadangan_pengaturan), tr(R.string.s_simpan_atau_pulihkan_favorit_templat))
        val r = LinearLayout(this)
        r.setPadding(0, dp(12), 0, 0)
        fun pill(t: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
            text = t; textSize = 14f; setTextColor(fg); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; background = rr(bg, 20); setPadding(dp(18), 0, dp(18), 0)
            isClickable = true; setOnClickListener { onClick() }
        }
        val lp1 = LinearLayout.LayoutParams(WRAP, dp(40)); lp1.marginEnd = dp(8)
        r.addView(pill(tr(R.string.s_ekspor), BLUE, Color.WHITE) { pickFile(true) }, lp1)
        r.addView(pill(tr(R.string.s_pulihkan), BG, INK) { pickFile(false) }, LinearLayout.LayoutParams(WRAP, dp(40)))
        c.addView(r)
    }

    private fun toast(t: String) = android.widget.Toast.makeText(this, t, android.widget.Toast.LENGTH_SHORT).show()

    private fun section(t: String) {
        val v = TextView(this)
        v.text = t; v.textSize = 13f; v.setTextColor(LINK); v.setTypeface(null, Typeface.BOLD)
        v.setPadding(dp(4), dp(20), 0, dp(8))
        body.addView(v)
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rr(SURF, 20)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.bottomMargin = dp(10)
        body.addView(c, p)
        return c
    }

    private fun label(parent: LinearLayout, title: String, sub: String?) {
        val a = TextView(this)
        a.text = title; a.textSize = 16f; a.setTextColor(INK); a.setTypeface(null, Typeface.BOLD)
        parent.addView(a)
        if (sub != null) {
            val b = TextView(this)
            b.text = sub; b.textSize = 13f; b.setTextColor(MUTED)
            b.setPadding(0, dp(2), 0, 0)
            parent.addView(b)
        }
    }

    private fun statusRow(title: String, ok: Boolean, sms: Boolean, code: Int) {
        val c = card()
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        label(col, title, if (ok) tr(R.string.s_aktif) else tr(R.string.s_belum_menjadi_aplikasi_utama))
        c.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (!ok) {
            val b = TextView(this)
            b.text = tr(R.string.s_aktifkan); b.textSize = 14f; b.setTextColor(Color.WHITE); b.setTypeface(null, Typeface.BOLD)
            b.gravity = Gravity.CENTER; b.background = rr(BLUE, 20); b.setPadding(dp(18), 0, dp(18), 0)
            b.isClickable = true
            b.setOnClickListener { Roles.request(this, sms, code) }
            c.addView(b, LinearLayout.LayoutParams(WRAP, dp(40)))
        } else {
            val k = TextView(this)
            k.text = "✓"; k.textSize = 20f; k.setTextColor(GREEN); k.setTypeface(null, Typeface.BOLD)
            c.addView(k)
        }
    }

    private fun chips(parent: LinearLayout, opts: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        opts.forEachIndexed { i, o ->
            val c = TextView(this)
            c.text = o; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
            c.setPadding(dp(16), 0, dp(16), 0)
            val on = i == selected
            c.background = rr(if (on) BLUE else BG, 18, if (on) BLUE else LINE)
            c.setTextColor(if (on) Color.WHITE else INK)
            c.isClickable = true
            c.setOnClickListener { onPick(i) }
            val p = LinearLayout.LayoutParams(WRAP, dp(36))
            p.marginEnd = dp(8)
            row.addView(c, p)
        }
        val rp = LinearLayout.LayoutParams(MATCH, WRAP)
        rp.topMargin = dp(10)
        parent.addView(row, rp)
    }

    private fun linkRow(title: String, sub: String, target: Class<*>) {
        val c = card()
        label(c, title, sub)
        c.isClickable = true
        c.setOnClickListener { startActivity(Intent(this, target)) }
    }

    private fun build() {
        body.removeAllViews()
        section(tr(R.string.s_aplikasi_utama))
        statusRow(tr(R.string.s_aplikasi_telepon), Roles.isDialer(this), false, 1)
        statusRow(tr(R.string.s_aplikasi_sms), Roles.isSms(this), true, 2)

        section(tr(R.string.s_tampilan))
        val th = card()
        label(th, tr(R.string.s_tema), tr(R.string.s_ikut_sistem_terang_atau_gelap))
        chips(th, listOf(tr(R.string.s_ikut_sistem), tr(R.string.s_terang), tr(R.string.s_gelap)), Prefs.theme(this)) { v ->
            Prefs.setTheme(this, v)
            recreate()
        }

        val lg = card()
        label(lg, tr(R.string.s_bahasa), tr(R.string.s_pilih_bahasa_tampilan_aplikasi))
        chips(lg, listOf(tr(R.string.s_ikut_sistem), "Bahasa Indonesia", "English"), Prefs.lang(this)) { v ->
            if (v != Prefs.lang(this)) {
                Prefs.setLang(this, v)
                recreate()
            }
        }

        section(tr(R.string.s_anti_spam))
        val sp = card()
        label(sp, tr(R.string.s_panggilan_dari_nomor_tak_dikenal), tr(R.string.s_nomor_yang_tidak_ada_di_kontak_ter))
        chips(sp, listOf(tr(R.string.s_normal), tr(R.string.s_senyapkan), tr(R.string.s_tolak)), Prefs.spamMode(this)) { v ->
            Prefs.setSpamMode(this, v)
            build()
        }
        val note = card()
        label(note, tr(R.string.s_nomor_diblokir), tr(R.string.s_panggilan_dan_notifikasi_sms_dari))

        section(tr(R.string.s_riwayat_panggilan_judul))
        val grp = card()
        label(grp, tr(R.string.s_kelompokkan_panggilan), tr(R.string.s_gabungkan_panggilan_berurutan_dari))
        chips(grp, listOf(tr(R.string.s_aktif), tr(R.string.s_mati)), if (Prefs.groupCalls(this)) 0 else 1) { v ->
            Prefs.setGroupCalls(this, v == 0)
            build()
        }
        val pg = card()
        label(pg, tr(R.string.s_hapus_otomatis_riwayat), tr(R.string.s_hapus_riwayat_yang_lebih_lama_dari))
        val purgeOpts = listOf(0, 30, 90, 180)
        chips(pg, listOf(tr(R.string.s_mati), tr(R.string.s_n_hari, 30), tr(R.string.s_n_hari, 90), tr(R.string.s_n_hari, 180)),
            purgeOpts.indexOf(Prefs.purgeDays(this)).coerceAtLeast(0)) { v ->
            Prefs.setPurgeDays(this, purgeOpts[v])
            if (v != 0 && android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(android.Manifest.permission.WRITE_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(android.Manifest.permission.WRITE_CALL_LOG), 3)
            build()
        }

        section(tr(R.string.s_lainnya_2))
        linkRow(tr(R.string.s_pesan_cepat), tr(R.string.s_template_untuk_menolak_panggilan_d), QuickRepliesActivity::class.java)
        linkRow(tr(R.string.s_nomor_diblokir), tr(R.string.s_kelola_ekspor_dan_impor_daftar_blo), BlockedActivity::class.java)

        section(tr(R.string.s_panggilan_cepat))
        speedDialCard()

        section(tr(R.string.s_cadangan))
        backupCard()

        section(tr(R.string.s_tentang))
        val ab = card()
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { null }
        label(ab, "DialChat" + (if (ver != null) " $ver" else ""), tr(R.string.s_aplikasi_telepon_dan_sms))
    }
}
