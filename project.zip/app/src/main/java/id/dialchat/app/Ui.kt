package id.dialchat.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.PorterDuff
import android.view.View
import android.view.ViewOutlineProvider
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.widget.LinearLayout

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rr(color: Int, r: Int, stroke: Int = 0, sw: Int = 1): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    if (stroke != 0) g.setStroke(dp(sw), stroke)
    return g
}

fun Context.ov(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

fun Context.icon(res: Int, color: Int, size: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    return v
}

fun Context.photoView(bmp: Bitmap): ImageView {
    val v = ImageView(this)
    v.setImageBitmap(bmp)
    v.scaleType = ImageView.ScaleType.CENTER_CROP
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
    }
    v.clipToOutline = true
    return v
}

fun prettyNum(s: String): String = if (s.length > 4 && s.all { it.isDigit() }) s.chunked(4).joinToString(" ") else s

object Wa {
    fun normalize(raw: String): String? {
        val t = raw.trim()
        val d = t.filter { it.isDigit() }
        if (d.isEmpty()) return null
        val r = when {
            t.startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("62") -> d
            d.startsWith("08") -> "62" + d.drop(1)
            d.startsWith("8") -> "62$d"
            else -> return null
        }
        if (r.startsWith("62")) return if (r.startsWith("628") && r.length in 10..15) r else null
        return if (r.length in 8..15) r else null
    }

    fun open(ctx: Context, raw: String, text: String? = null) {
        val w = normalize(raw)
        if (w == null) {
            Toast.makeText(ctx, tr("Nomor tidak valid untuk WhatsApp"), Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.parse("https://wa.me/$w" + (if (text != null) "?text=" + Uri.encode(text) else ""))
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                return
            } catch (e: ActivityNotFoundException) { }
        }
        Toast.makeText(ctx, tr("WhatsApp tidak terpasang"), Toast.LENGTH_SHORT).show()
    }
}

fun Context.col(id: Int): Int = resources.getColor(id)

val Context.isDark: Boolean
    get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

open class BaseActivity : Activity() {
    private var themeApplied = 0
    private var langApplied = L.en

    override fun attachBaseContext(newBase: Context) {
        val mode = Prefs.theme(newBase)
        themeApplied = mode
        if (mode == 0) {
            super.attachBaseContext(newBase)
            return
        }
        val cfg = Configuration(newBase.resources.configuration)
        val night = if (mode == 2) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
        cfg.uiMode = (cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or night
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.theme(this) != themeApplied || L.en != langApplied) recreate()
    }
}
