package id.dialchat.app

import android.content.Context
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.widget.LinearLayout

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rr(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.ov(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

fun Context.icon(res: Int, color: Int, size: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    return v
}

fun prettyNum(s: String): String = if (s.length > 4 && s.all { it.isDigit() }) s.chunked(4).joinToString(" ") else s
