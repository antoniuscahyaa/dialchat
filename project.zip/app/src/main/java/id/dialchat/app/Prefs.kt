package id.dialchat.app

import android.app.Activity
import android.app.Dialog
import android.app.role.RoleManager
import android.provider.Telephony
import android.telecom.TelecomManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import android.widget.Toast

object Prefs {
    val defaults: List<String> get() = listOf(
        tr(R.string.s_nanti_saya_telepon_balik_ya),
        tr(R.string.s_saya_sedang_sibuk_kabari_lewat_pes),
        tr(R.string.s_saya_sedang_menyetir_nanti_saya_hu),
        tr(R.string.s_terima_kasih_ya)
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("dialchat", Context.MODE_PRIVATE)

    fun templates(ctx: Context): List<String> {
        val raw = sp(ctx).getString("tpl", null) ?: return defaults
        val l = raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        return if (l.isEmpty()) defaults else l
    }

    fun setTemplates(ctx: Context, l: List<String>) {
        val clean = l.map { it.replace("\n", " ").trim() }.filter { it.isNotEmpty() }
        sp(ctx).edit().putString("tpl", clean.joinToString("\n")).apply()
    }

    fun theme(ctx: Context): Int = sp(ctx).getInt("theme", 0)
    fun setTheme(ctx: Context, v: Int) { sp(ctx).edit().putInt("theme", v).apply() }
    /** 0 = ikut sistem (bawaan), 1 = Indonesia, 2 = English */
    fun lang(ctx: Context): Int = sp(ctx).getInt("lang", 0)
    fun setLang(ctx: Context, v: Int) { sp(ctx).edit().putInt("lang", v).apply(); L.apply(v) }
    fun spamMode(ctx: Context): Int = sp(ctx).getInt("spam", 0)
    fun setSpamMode(ctx: Context, v: Int) { sp(ctx).edit().putInt("spam", v).apply() }

    /** Kelompokkan panggilan berurutan dari nomor yang sama di Riwayat (bawaan: aktif). */
    fun groupCalls(ctx: Context): Boolean = sp(ctx).getBoolean("group_calls", true)
    fun setGroupCalls(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("group_calls", v).apply() }
    /** Hapus otomatis riwayat lebih lama dari N hari; 0 = mati. */
    fun purgeDays(ctx: Context): Int = sp(ctx).getInt("purge_days", 0)
    fun setPurgeDays(ctx: Context, v: Int) { sp(ctx).edit().putInt("purge_days", v).apply() }

    /** Cadangan seluruh pengaturan (favorit, template, tema, bahasa, dll.) sebagai JSON. */
    fun exportJson(ctx: Context): String {
        val prefs = JSONObject()
        loop@ for ((k, v) in sp(ctx).all) {
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "ss"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue@loop
            }
            prefs.put(k, o)
        }
        return JSONObject().put("app", "DialChat").put("version", 1).put("prefs", prefs).toString(2)
    }

    /** Pulihkan dari JSON hasil [exportJson]. Berkas dibaca penuh dulu; bila rusak, pengaturan lama tidak berubah. */
    fun importJson(ctx: Context, text: String): Int {
        val root = JSONObject(text)
        require(root.optString("app") == "DialChat") { "bukan berkas cadangan DialChat" }
        val p = root.getJSONObject("prefs")
        val ed = sp(ctx).edit().clear()
        var n = 0
        loop@ for (k in p.keys()) {
            val o = p.getJSONObject(k)
            when (o.getString("t")) {
                "b" -> ed.putBoolean(k, o.getBoolean("v"))
                "i" -> ed.putInt(k, o.getInt("v"))
                "l" -> ed.putLong(k, o.getLong("v"))
                "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                "s" -> ed.putString(k, o.getString("v"))
                "ss" -> { val a = o.getJSONArray("v"); ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
                else -> continue@loop
            }
            n++
        }
        ed.commit()
        L.apply(lang(ctx))
        return n
    }

    /** Panggilan cepat: tahan tombol 2–9 di dialpad -> menelepon kontak yang diatur. */
    private fun speedObj(ctx: Context): JSONObject =
        try { JSONObject(sp(ctx).getString("speed", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    fun speedDial(ctx: Context): Map<String, Pair<String, String>> {
        val out = LinkedHashMap<String, Pair<String, String>>()
        try {
            val o = speedObj(ctx)
            for (k in o.keys()) { val e = o.getJSONObject(k); out[k] = e.getString("n") to e.getString("p") }
        } catch (e: Exception) { logW("Prefs", e) }
        return out
    }
    fun setSpeedDial(ctx: Context, digit: String, name: String?, number: String?) {
        val o = speedObj(ctx)
        if (name == null || number == null) o.remove(digit) else o.put(digit, JSONObject().put("n", name).put("p", number))
        sp(ctx).edit().putString("speed", o.toString()).apply()
    }

    fun remindersJson(ctx: Context): String = sp(ctx).getString("reminders", "[]") ?: "[]"
    fun setRemindersJson(ctx: Context, s: String) { sp(ctx).edit().putString("reminders", s).apply() }

    private fun key(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    fun favs(ctx: Context): List<Pair<String, String>> {
        val raw = sp(ctx).getString("fav", "") ?: ""
        val out = ArrayList<Pair<String, String>>()
        for (line in raw.split("\n")) {
            val p = line.split("\t")
            if (p.size >= 2 && p[1].isNotBlank()) out.add(p[0] to p[1])
        }
        return out
    }

    fun isFav(ctx: Context, number: String): Boolean = favs(ctx).any { key(it.second) == key(number) }

    fun toggleFav(ctx: Context, name: String, number: String) {
        val l = favs(ctx).toMutableList()
        val i = l.indexOfFirst { key(it.second) == key(number) }
        if (i >= 0) l.removeAt(i) else l.add(name to number)
        val s = l.joinToString("\n") { it.first.replace("\n", " ").replace("\t", " ") + "\t" + it.second }
        sp(ctx).edit().putString("fav", s).apply()
    }
}

fun Activity.showQuickReplies(number: String, onSent: (() -> Unit)? = null) {
    val blue = Color.parseColor("#1D4ED8")
    val bg = col(R.color.bg)
    val ink = col(R.color.ink)
    val surf = col(R.color.surf)
    val link = col(R.color.link)
    val canWa = Wa.normalize(number) != null
    var channel = 0
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(20), dp(20), dp(16))
    val rad = dp(28).toFloat()
    val gd = GradientDrawable()
    gd.setColor(bg)
    gd.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
    box.background = gd
    val t = TextView(this)
    t.text = tr(R.string.s_kirim_pesan_cepat); t.textSize = 22f; t.setTextColor(ink); t.setTypeface(null, Typeface.BOLD)
    box.addView(t)
    val chips = ArrayList<TextView>()
    fun style() {
        for (i in chips.indices) {
            val on = i == channel
            chips[i].background = rr(if (on) blue else surf, 18)
            chips[i].setTextColor(if (on) Color.WHITE else ink)
        }
    }
    val cr = LinearLayout(this)
    val labels = if (canWa) listOf("SMS", "WhatsApp") else listOf("SMS")
    labels.forEachIndexed { i, l ->
        val c = TextView(this)
        c.text = l; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
        c.setPadding(dp(18), 0, dp(18), 0)
        c.setOnClickListener { channel = i; style() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36))
        p.marginEnd = dp(8)
        cr.addView(c, p)
        chips.add(c)
    }
    style()
    val crp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    crp.topMargin = dp(12)
    box.addView(cr, crp)
    for (tpl in Prefs.templates(this)) {
        val row = TextView(this)
        row.text = tpl; row.textSize = 15f; row.setTextColor(ink)
        row.background = rr(surf, 16)
        row.setPadding(dp(16), dp(12), dp(16), dp(12))
        row.isClickable = true
        row.setOnClickListener {
            d.dismiss()
            if (channel == 1 && canWa) {
                Wa.open(this, number, tpl)
            } else {
                SmsUtil.send(this, number, tpl, -1)
                Toast.makeText(this, tr(R.string.s_pesan_dikirim), Toast.LENGTH_SHORT).show()
            }
            onSent?.invoke()
        }
        val rp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.topMargin = dp(8)
        box.addView(row, rp)
    }
    val edit = TextView(this)
    edit.text = tr(R.string.s_ubah_template); edit.textSize = 15f; edit.setTextColor(link); edit.gravity = Gravity.CENTER
    edit.setTypeface(null, Typeface.BOLD)
    edit.setOnClickListener { d.dismiss(); startActivity(Intent(this, QuickRepliesActivity::class.java)) }
    box.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.55f)
    }
    d.show()
}

object Roles {
    fun isDialer(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == ctx.packageName
    } catch (e: Exception) { false }

    fun isSms(ctx: Context): Boolean = SmsUtil.isDefault(ctx)

    fun request(act: Activity, sms: Boolean, code: Int) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val rm = act.getSystemService(Context.ROLE_SERVICE) as RoleManager
                val role = if (sms) RoleManager.ROLE_SMS else RoleManager.ROLE_DIALER
                if (rm.isRoleAvailable(role)) {
                    act.startActivityForResult(rm.createRequestRoleIntent(role), code)
                    return
                }
            }
            val i = if (sms) {
                Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName)
            } else {
                Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.packageName)
            }
            act.startActivityForResult(i, code)
        } catch (e: Exception) {
            Toast.makeText(act, tr(R.string.s_tidak_bisa_membuka_pengaturan_apli_3), Toast.LENGTH_SHORT).show()
        }
    }
}

class SheetItem(val color: Int, val res: Int, val label: String, val labelColor: Int?, val onClick: () -> Unit)

fun Activity.showSheet(title: String, sub: String?, items: List<SheetItem>) {
    val bg = col(R.color.bg)
    val ink = col(R.color.ink)
    val muted = col(R.color.muted)
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(20), dp(20), dp(24))
    val rad = dp(28).toFloat()
    val gd = GradientDrawable()
    gd.setColor(bg)
    gd.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
    box.background = gd
    val t = TextView(this)
    t.text = title; t.textSize = 18f; t.setTextColor(ink); t.setTypeface(null, Typeface.BOLD)
    t.maxLines = 1; t.ellipsize = android.text.TextUtils.TruncateAt.END
    box.addView(t)
    if (sub != null) {
        val s = TextView(this)
        s.text = sub; s.textSize = 14f; s.setTextColor(muted); s.maxLines = 2
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        s.setPadding(0, dp(4), 0, dp(8))
        box.addView(s)
    }
    for (item in items) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        row.isClickable = true
        row.setOnClickListener { d.dismiss(); item.onClick() }
        val c = android.widget.FrameLayout(this)
        c.background = ov(item.color)
        val ic = icon(item.res, Color.WHITE, 22)
        ic.layoutParams = android.widget.FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        c.addView(ic)
        row.addView(c, LinearLayout.LayoutParams(dp(44), dp(44)))
        val tv = TextView(this)
        tv.text = item.label; tv.textSize = 17f; tv.setTextColor(item.labelColor ?: ink)
        val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tp.marginStart = dp(16)
        row.addView(tv, tp)
        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.55f)
    }
    d.show()
}
