package id.dialchat.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object Prefs {
    val defaults = listOf(
        "Nanti saya telepon balik ya.",
        "Saya sedang sibuk, kabari lewat pesan saja.",
        "Saya sedang menyetir, nanti saya hubungi.",
        "Terima kasih, ya."
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("dialchat", Context.MODE_PRIVATE)

    fun templates(ctx: Context): List<String> {
        val raw = sp(ctx).getString("tpl", null) ?: return defaults
        val l = raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        return if (l.isEmpty()) defaults else l
    }

    fun setTemplates(ctx: Context, l: List<String>) {
        val clean = l.map { it.replace("\n", " ").trim() }.filter { it.isNotEmpty() }
        sp(ctx).edit().putString("tpl", clean.joinToString("\n")).apply()
    }

    private fun key(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    fun favs(ctx: Context): List<Pair<String, String>> {
        val raw = sp(ctx).getString("fav", "") ?: ""
        val out = ArrayList<Pair<String, String>>()
        for (line in raw.split("\n")) {
            val p = line.split("\t")
            if (p.size >= 2 && p[1].isNotBlank()) out.add(p[0] to p[1])
        }
        return out
    }

    fun isFav(ctx: Context, number: String): Boolean = favs(ctx).any { key(it.second) == key(number) }

    fun toggleFav(ctx: Context, name: String, number: String) {
        val l = favs(ctx).toMutableList()
        val i = l.indexOfFirst { key(it.second) == key(number) }
        if (i >= 0) l.removeAt(i) else l.add(name to number)
        val s = l.joinToString("\n") { it.first.replace("\n", " ").replace("\t", " ") + "\t" + it.second }
        sp(ctx).edit().putString("fav", s).apply()
    }
}

fun Activity.showQuickReplies(number: String, onSent: (() -> Unit)? = null) {
    val blue = Color.parseColor("#1D4ED8")
    val bg = col(R.color.bg)
    val ink = col(R.color.ink)
    val surf = col(R.color.surf)
    val link = col(R.color.link)
    val canWa = Wa.normalize(number) != null
    var channel = 0
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(20), dp(20), dp(16))
    val rad = dp(28).toFloat()
    val gd = GradientDrawable()
    gd.setColor(bg)
    gd.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
    box.background = gd
    val t = TextView(this)
    t.text = "Kirim pesan cepat"; t.textSize = 22f; t.setTextColor(ink); t.setTypeface(null, Typeface.BOLD)
    box.addView(t)
    val chips = ArrayList<TextView>()
    fun style() {
        for (i in chips.indices) {
            val on = i == channel
            chips[i].background = rr(if (on) blue else surf, 18)
            chips[i].setTextColor(if (on) Color.WHITE else ink)
        }
    }
    val cr = LinearLayout(this)
    val labels = if (canWa) listOf("SMS", "WhatsApp") else listOf("SMS")
    labels.forEachIndexed { i, l ->
        val c = TextView(this)
        c.text = l; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
        c.setPadding(dp(18), 0, dp(18), 0)
        c.setOnClickListener { channel = i; style() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36))
        p.marginEnd = dp(8)
        cr.addView(c, p)
        chips.add(c)
    }
    style()
    val crp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    crp.topMargin = dp(12)
    box.addView(cr, crp)
    for (tpl in Prefs.templates(this)) {
        val row = TextView(this)
        row.text = tpl; row.textSize = 15f; row.setTextColor(ink)
        row.background = rr(surf, 16)
        row.setPadding(dp(16), dp(12), dp(16), dp(12))
        row.isClickable = true
        row.setOnClickListener {
            d.dismiss()
            if (channel == 1 && canWa) {
                Wa.open(this, number, tpl)
            } else {
                SmsUtil.send(this, number, tpl, -1)
                Toast.makeText(this, "Pesan dikirim", Toast.LENGTH_SHORT).show()
            }
            onSent?.invoke()
        }
        val rp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.topMargin = dp(8)
        box.addView(row, rp)
    }
    val edit = TextView(this)
    edit.text = "Ubah template"; edit.textSize = 15f; edit.setTextColor(link); edit.gravity = Gravity.CENTER
    edit.setTypeface(null, Typeface.BOLD)
    edit.setOnClickListener { d.dismiss(); startActivity(Intent(this, QuickRepliesActivity::class.java)) }
    box.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.55f)
    }
    d.show()
}
