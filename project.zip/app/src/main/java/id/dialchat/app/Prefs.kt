package id.dialchat.app

import android.app.Activity
import android.app.Dialog
import android.app.role.RoleManager
import android.provider.Telephony
import android.telecom.TelecomManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object Prefs {
    val defaults: List<String> get() = listOf(
        tr("Nanti saya telepon balik ya."),
        tr("Saya sedang sibuk, kabari lewat pesan saja."),
        tr("Saya sedang menyetir, nanti saya hubungi."),
        tr("Terima kasih, ya.")
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("dialchat", Context.MODE_PRIVATE)

    fun templates(ctx: Context): List<String> {
        val raw = sp(ctx).getString("tpl", null) ?: return defaults
        val l = raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        return if (l.isEmpty()) defaults else l
    }

    fun setTemplates(ctx: Context, l: List<String>) {
        val clean = l.map { it.replace("\n", " ").trim() }.filter { it.isNotEmpty() }
        sp(ctx).edit().putString("tpl", clean.joinToString("\n")).apply()
    }

    fun theme(ctx: Context): Int = sp(ctx).getInt("theme", 0)
    fun setTheme(ctx: Context, v: Int) { sp(ctx).edit().putInt("theme", v).apply() }
    /** 0 = ikut sistem (bawaan), 1 = Indonesia, 2 = English */
    fun lang(ctx: Context): Int = sp(ctx).getInt("lang", 0)
    fun setLang(ctx: Context, v: Int) { sp(ctx).edit().putInt("lang", v).apply(); L.apply(v) }
    fun spamMode(ctx: Context): Int = sp(ctx).getInt("spam", 0)
    fun setSpamMode(ctx: Context, v: Int) { sp(ctx).edit().putInt("spam", v).apply() }

    private fun key(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    fun favs(ctx: Context): List<Pair<String, String>> {
        val raw = sp(ctx).getString("fav", "") ?: ""
        val out = ArrayList<Pair<String, String>>()
        for (line in raw.split("\n")) {
            val p = line.split("\t")
            if (p.size >= 2 && p[1].isNotBlank()) out.add(p[0] to p[1])
        }
        return out
    }

    fun isFav(ctx: Context, number: String): Boolean = favs(ctx).any { key(it.second) == key(number) }

    fun toggleFav(ctx: Context, name: String, number: String) {
        val l = favs(ctx).toMutableList()
        val i = l.indexOfFirst { key(it.second) == key(number) }
        if (i >= 0) l.removeAt(i) else l.add(name to number)
        val s = l.joinToString("\n") { it.first.replace("\n", " ").replace("\t", " ") + "\t" + it.second }
        sp(ctx).edit().putString("fav", s).apply()
    }
}

fun Activity.showQuickReplies(number: String, onSent: (() -> Unit)? = null) {
    val blue = Color.parseColor("#1D4ED8")
    val bg = col(R.color.bg)
    val ink = col(R.color.ink)
    val surf = col(R.color.surf)
    val link = col(R.color.link)
    val canWa = Wa.normalize(number) != null
    var channel = 0
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(20), dp(20), dp(16))
    val rad = dp(28).toFloat()
    val gd = GradientDrawable()
    gd.setColor(bg)
    gd.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
    box.background = gd
    val t = TextView(this)
    t.text = tr("Kirim pesan cepat"); t.textSize = 22f; t.setTextColor(ink); t.setTypeface(null, Typeface.BOLD)
    box.addView(t)
    val chips = ArrayList<TextView>()
    fun style() {
        for (i in chips.indices) {
            val on = i == channel
            chips[i].background = rr(if (on) blue else surf, 18)
            chips[i].setTextColor(if (on) Color.WHITE else ink)
        }
    }
    val cr = LinearLayout(this)
    val labels = if (canWa) listOf("SMS", "WhatsApp") else listOf("SMS")
    labels.forEachIndexed { i, l ->
        val c = TextView(this)
        c.text = l; c.textSize = 14f; c.gravity = Gravity.CENTER; c.setTypeface(null, Typeface.BOLD)
        c.setPadding(dp(18), 0, dp(18), 0)
        c.setOnClickListener { channel = i; style() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36))
        p.marginEnd = dp(8)
        cr.addView(c, p)
        chips.add(c)
    }
    style()
    val crp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    crp.topMargin = dp(12)
    box.addView(cr, crp)
    for (tpl in Prefs.templates(this)) {
        val row = TextView(this)
        row.text = tpl; row.textSize = 15f; row.setTextColor(ink)
        row.background = rr(surf, 16)
        row.setPadding(dp(16), dp(12), dp(16), dp(12))
        row.isClickable = true
        row.setOnClickListener {
            d.dismiss()
            if (channel == 1 && canWa) {
                Wa.open(this, number, tpl)
            } else {
                SmsUtil.send(this, number, tpl, -1)
                Toast.makeText(this, tr("Pesan dikirim"), Toast.LENGTH_SHORT).show()
            }
            onSent?.invoke()
        }
        val rp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.topMargin = dp(8)
        box.addView(row, rp)
    }
    val edit = TextView(this)
    edit.text = tr("Ubah template"); edit.textSize = 15f; edit.setTextColor(link); edit.gravity = Gravity.CENTER
    edit.setTypeface(null, Typeface.BOLD)
    edit.setOnClickListener { d.dismiss(); startActivity(Intent(this, QuickRepliesActivity::class.java)) }
    box.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.55f)
    }
    d.show()
}

object Roles {
    fun isDialer(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == ctx.packageName
    } catch (e: Exception) { false }

    fun isSms(ctx: Context): Boolean = SmsUtil.isDefault(ctx)

    fun request(act: Activity, sms: Boolean, code: Int) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val rm = act.getSystemService(Context.ROLE_SERVICE) as RoleManager
                val role = if (sms) RoleManager.ROLE_SMS else RoleManager.ROLE_DIALER
                if (rm.isRoleAvailable(role)) {
                    act.startActivityForResult(rm.createRequestRoleIntent(role), code)
                    return
                }
            }
            val i = if (sms) {
                Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName)
            } else {
                Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.packageName)
            }
            act.startActivityForResult(i, code)
        } catch (e: Exception) {
            Toast.makeText(act, tr("Tidak bisa membuka pengaturan aplikasi default"), Toast.LENGTH_SHORT).show()
        }
    }
}

class SheetItem(val color: Int, val res: Int, val label: String, val labelColor: Int?, val onClick: () -> Unit)

fun Activity.showSheet(title: String, sub: String?, items: List<SheetItem>) {
    val bg = col(R.color.bg)
    val ink = col(R.color.ink)
    val muted = col(R.color.muted)
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(20), dp(20), dp(24))
    val rad = dp(28).toFloat()
    val gd = GradientDrawable()
    gd.setColor(bg)
    gd.cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
    box.background = gd
    val t = TextView(this)
    t.text = title; t.textSize = 18f; t.setTextColor(ink); t.setTypeface(null, Typeface.BOLD)
    t.maxLines = 1; t.ellipsize = android.text.TextUtils.TruncateAt.END
    box.addView(t)
    if (sub != null) {
        val s = TextView(this)
        s.text = sub; s.textSize = 14f; s.setTextColor(muted); s.maxLines = 2
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        s.setPadding(0, dp(4), 0, dp(8))
        box.addView(s)
    }
    for (item in items) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        row.isClickable = true
        row.setOnClickListener { d.dismiss(); item.onClick() }
        val c = android.widget.FrameLayout(this)
        c.background = ov(item.color)
        val ic = icon(item.res, Color.WHITE, 22)
        ic.layoutParams = android.widget.FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        c.addView(ic)
        row.addView(c, LinearLayout.LayoutParams(dp(44), dp(44)))
        val tv = TextView(this)
        tv.text = item.label; tv.textSize = 17f; tv.setTextColor(item.labelColor ?: ink)
        val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tp.marginStart = dp(16)
        row.addView(tv, tp)
        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.55f)
    }
    d.show()
}
