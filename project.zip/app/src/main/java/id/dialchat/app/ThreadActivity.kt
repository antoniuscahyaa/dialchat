package id.dialchat.app

import android.app.Activity
import android.app.NotificationManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.text.InputType
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Msg(val id: Long, val body: String, val date: Long, val type: Int, val read: Int)

class ThreadActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val INK by lazy { col(R.color.ink) }
    private val MUTED by lazy { col(R.color.muted) }
    private val SURF by lazy { col(R.color.surf) }
    private val BG by lazy { col(R.color.bg) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var address = ""
    private var threadId = -1L
    private var subId = -1
    private var subs: List<SubscriptionInfo> = emptyList()
    private lateinit var box: LinearLayout
    private lateinit var sv: ScrollView
    private lateinit var input: EditText
    private lateinit var simBtn: TextView
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { load() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        var a = intent.getStringExtra("address") ?: (intent.data?.schemeSpecificPart ?: "")
        a = Uri.decode(a).substringBefore('?').trim()
        if (a.isBlank()) { finish(); return }
        address = a
        threadId = SmsUtil.threadFor(this, address)
        window.statusBarColor = BLUE
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = if (isDark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val hdrView = header()
        sv = ScrollView(this)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        sv.addView(box)
        val area = FrameLayout(this)
        area.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        val hc = hdrCollapse!!
        area.addView(hdrView, FrameLayout.LayoutParams(MATCH, hc.exp))
        sv.setPadding(0, hc.exp, 0, 0)
        hc.attach(sv)
        root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(inputBar(), LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        loadSubs()
        val pre = intent.getStringExtra("sms_body")
        if (pre != null) input.setText(pre)
    }

    override fun onResume() {
        super.onResume()
        if (!::box.isInitialized) return
        contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, obs)
        load()
    }

    override fun onPause() {
        if (::box.isInitialized) contentResolver.unregisterContentObserver(obs)
        super.onPause()
    }

    private fun pill(bg: Int, fg: Int, res: Int, label: String, stroke: Int, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER
        l.background = rr(bg, 22, stroke, 2)
        l.isClickable = true
        l.setPadding(dp(18), 0, dp(18), 0)
        l.setOnClickListener { onClick() }
        l.addView(icon(res, fg, 20))
        val t = TextView(this)
        t.text = label; t.textSize = 15f; t.setTextColor(fg); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(8), 0, 0, 0)
        l.addView(t)
        val p = LinearLayout.LayoutParams(WRAP, dp(44))
        p.setMargins(dp(5), 0, dp(5), 0)
        l.layoutParams = p
        return l
    }

    private fun callThis() {
        val i = Intent(this, MainActivity::class.java)
        i.action = Intent.ACTION_DIAL
        i.data = Uri.parse("tel:" + Uri.encode(address))
        i.putExtra("autocall", true)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
    }

    private var hdrCollapse: Collapse? = null

    private fun header(): View {
        val name = CallUtil.name(this, address)
        val fr = RoundHeader(this, BLUE, BG, dp(36).toFloat())
        for ((size, al) in listOf(220 to 26, 340 to 15)) {
            val v = View(this)
            v.background = ov(Color.argb(al, 255, 255, 255))
            val p = FrameLayout.LayoutParams(dp(size), dp(size), Gravity.TOP or Gravity.END)
            p.setMargins(0, -dp(size / 3), -dp(size / 3), 0)
            fr.addView(v, p)
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(48), dp(20), dp(24))
        val f = name?.firstOrNull()
        val av: View
        if (f != null && f.isLetter()) {
            val t = TextView(this)
            t.text = f.uppercaseChar().toString(); t.gravity = Gravity.CENTER; t.textSize = 26f
            t.setTextColor(BLUE); t.setTypeface(null, Typeface.BOLD)
            av = t
        } else {
            val fl = FrameLayout(this)
            val ic = icon(R.drawable.ic_person, BLUE, 32)
            ic.layoutParams = FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER)
            fl.addView(ic)
            av = fl
        }
        av.background = ov(Color.WHITE)
        col.addView(av, LinearLayout.LayoutParams(dp(64), dp(64)))
        val tn = TextView(this)
        tn.text = name ?: prettyNum(address); tn.textSize = 24f; tn.setTextColor(Color.WHITE)
        tn.setTypeface(null, Typeface.BOLD); tn.gravity = Gravity.CENTER; tn.maxLines = 1
        tn.setPadding(0, dp(12), 0, 0)
        col.addView(tn)
        var tsV: TextView? = null
        if (name != null) {
            val ts = TextView(this)
            ts.text = address; ts.textSize = 14f; ts.setTextColor(Color.argb(224, 255, 255, 255))
            col.addView(ts)
            tsV = ts
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        row.addView(pill(Color.WHITE, BLUE, R.drawable.ic_phone, tr(R.string.s_telepon), 0) { callThis() })
        if (Wa.normalize(address) != null) {
            row.addView(pill(GREEN, Color.WHITE, R.drawable.ic_wa, tr(R.string.s_chat_whatsapp), Color.WHITE) { Wa.open(this, address) })
        }
        val rp = LinearLayout.LayoutParams(WRAP, WRAP)
        rp.topMargin = dp(16)
        col.addView(row, rp)
        fr.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        val back = FrameLayout(this)
        back.background = ov(Color.argb(46, 255, 255, 255))
        back.contentDescription = tr(R.string.s_kembali)
        back.isClickable = true
        back.setOnClickListener { finish() }
        val bi = icon(R.drawable.ic_back, Color.WHITE, 24)
        bi.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)
        back.addView(bi)
        val bp = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START)
        bp.setMargins(dp(12), dp(40), 0, 0)
        fr.addView(back, bp)

        // Header menyusut saat pesan di-scroll: avatar dan nomor memudar, nama + tombol aksi tetap.
        val wSpec = View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels, View.MeasureSpec.EXACTLY)
        val hSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        fr.measure(wSpec, hSpec)
        val tsH = tsV?.let { it.measure(wSpec, hSpec); it.measuredHeight } ?: 0
        hdrCollapse = Collapse(fr, fr.measuredHeight, dp(88)) { p ->
            col.setPadding(dp(20), lerpI(dp(48), dp(12), p), dp(20), lerpI(dp(24), dp(12), p))
            av.setSquare(lerpI(dp(64), 0, p))
            av.alpha = (1f - p * 2f).coerceIn(0f, 1f)
            tn.setTextDp(lerpF(24f, 18f, p))
            tn.setPadding(0, lerpI(dp(12), 0, p), 0, 0)
            tsV?.let { it.alpha = (1f - p * 2.5f).coerceIn(0f, 1f); it.setHeightPx(lerpI(tsH, 0, p)) }
            (row.layoutParams as LinearLayout.LayoutParams).let { l ->
                val m = lerpI(dp(16), dp(6), p)
                if (l.topMargin != m) { l.topMargin = m; row.layoutParams = l }
            }
            for (i in 0 until row.childCount) row.getChildAt(i).setHeightPx(lerpI(dp(44), dp(36), p))
            val bs = lerpI(dp(44), dp(36), p)
            bp.width = bs; bp.height = bs; bp.topMargin = lerpI(dp(40), dp(4), p)
            back.layoutParams = bp
        }
        return fr
    }

    private fun inputBar(): View {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), dp(10), dp(16), dp(14))
        bar.setBackgroundColor(BG)
        simBtn = TextView(this)
        simBtn.text = "SIM"; simBtn.textSize = 13f; simBtn.setTextColor(Color.WHITE); simBtn.setTypeface(null, Typeface.BOLD)
        simBtn.gravity = Gravity.CENTER; simBtn.background = rr(BLUE, 18)
        simBtn.setPadding(dp(14), 0, dp(14), 0); simBtn.visibility = View.GONE
        simBtn.setOnClickListener { pickSim() }
        val sp = LinearLayout.LayoutParams(WRAP, dp(36))
        sp.marginEnd = dp(10)
        bar.addView(simBtn, sp)
        input = EditText(this)
        input.hint = tr(R.string.s_ketik_pesan); input.textSize = 16f; input.background = rr(SURF, 24)
        input.setPadding(dp(18), dp(10), dp(18), dp(10)); input.minHeight = dp(48); input.maxLines = 4
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        bar.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        val send = FrameLayout(this)
        send.background = ov(BLUE)
        send.contentDescription = tr(R.string.s_kirim)
        send.isClickable = true
        send.setOnClickListener { doSend() }
        val si = icon(R.drawable.ic_send, Color.WHITE, 22)
        si.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        send.addView(si)
        val pp = LinearLayout.LayoutParams(dp(48), dp(48))
        pp.marginStart = dp(10)
        bar.addView(send, pp)
        return bar
    }

    private fun loadSubs() {
        subs = try {
            (getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager).activeSubscriptionInfoList ?: emptyList()
        } catch (e: Exception) { emptyList() }
        if (subs.size > 1) {
            val def = if (Build.VERSION.SDK_INT >= 22) SmsManager.getDefaultSmsSubscriptionId() else -1
            val cur = subs.firstOrNull { it.subscriptionId == def } ?: subs[0]
            subId = cur.subscriptionId
            simBtn.text = "SIM " + (cur.simSlotIndex + 1)
            simBtn.visibility = View.VISIBLE
        } else if (subs.size == 1) {
            subId = subs[0].subscriptionId
        }
    }

    private fun pickSim() {
        val pm = PopupMenu(this, simBtn)
        subs.forEachIndexed { i, s -> pm.menu.add(0, i, i, "SIM " + (s.simSlotIndex + 1) + " · " + s.displayName) }
        pm.setOnMenuItemClickListener { mi ->
            val s = subs[mi.itemId]
            subId = s.subscriptionId
            simBtn.text = "SIM " + (s.simSlotIndex + 1)
            true
        }
        pm.show()
    }

    private fun doSend() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (!SmsUtil.isDefault(this)) {
            Toast.makeText(this, tr(R.string.s_jadikan_dialchat_aplikasi_sms_utam_2), Toast.LENGTH_SHORT).show()
            return
        }
        input.setText("")
        SmsUtil.send(this, address, t, subId)
        load()
    }

    private fun resend(m: Msg) {
        try { contentResolver.delete(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, m.id.toString()), null, null) } catch (e: Exception) { logW("ThreadActivity", e) }
        SmsUtil.send(this, address, m.body, subId)
        load()
    }

    private fun dayLabel(d: Long): String = when {
        DateUtils.isToday(d) -> tr(R.string.s_hari_ini)
        DateUtils.isToday(d + 86400000L) -> tr(R.string.s_kemarin)
        else -> SimpleDateFormat("d MMM yyyy", L.loc).format(Date(d))
    }

    private var loadGen = 0

    /** Query pesan di thread latar; tampilan dibangun di main thread, hasil usang dibuang. */
    private fun load() {
        val tid = threadId
        val addr = address
        val gen = ++loadGen
        Bg.load({ queryMsgs(tid, addr) }) { res ->
            if (res == null || gen != loadGen || isFinishing || isDestroyed) return@load
            render(res)
        }
    }

    private fun queryMsgs(tid: Long, addr: String): List<Msg> {
        val msgs = ArrayList<Msg>()
        try {
            val byThread = tid >= 0
            contentResolver.query(
                Telephony.Sms.CONTENT_URI, arrayOf("_id", "body", "date", "type", "read"),
                if (byThread) "thread_id=?" else "address=?",
                arrayOf(if (byThread) tid.toString() else addr), "date ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    msgs.add(Msg(c.getLong(0), c.getString(1) ?: "", c.getLong(2), c.getInt(3), c.getInt(4)))
                    if (msgs.size > 400) msgs.removeAt(0)
                }
            }
        } catch (e: Exception) { logW("ThreadActivity", e) }
        return msgs
    }

    private fun render(msgs: List<Msg>) {
        box.removeAllViews()
        var last = ""
        var unread = false
        for (m in msgs) {
            val day = dayLabel(m.date)
            if (day != last) { box.addView(dateChip(day)); last = day }
            box.addView(bubble(m))
            if (m.type == Telephony.Sms.MESSAGE_TYPE_INBOX && m.read == 0) unread = true
        }
        if (unread) SmsUtil.markRead(this, threadId)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(SmsNotif.idFor(address))
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyText(label: String, text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, tr(R.string.s_disalin), Toast.LENGTH_SHORT).show()
    }

    private fun showMsgActions(m: Msg) {
        val items = ArrayList<SheetItem>()
        val code = SmsNotif.otpCode(m.body)
        if (code != null) items.add(SheetItem(GREEN, R.drawable.ic_copy, tr(R.string.s_salin_kode_2) + code, null) { copyText(tr(R.string.s_kode_otp), code) })
        items.add(SheetItem(BLUE, R.drawable.ic_copy, tr(R.string.s_salin_pesan), null) { copyText(tr(R.string.s_pesan), m.body) })
        items.add(SheetItem(BLUE, R.drawable.ic_forward, tr(R.string.s_teruskan), null) {
            startActivity(Intent(this, NewMessageActivity::class.java).putExtra("forward", m.body))
        })
        items.add(SheetItem(RED, R.drawable.ic_delete, tr(R.string.s_hapus_pesan), RED) {
            AlertDialog.Builder(this)
                .setMessage(tr(R.string.s_hapus_pesan_ini))
                .setPositiveButton(tr(R.string.s_hapus)) { _, _ ->
                    try { contentResolver.delete(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, m.id.toString()), null, null) }
                    catch (e: Exception) { logW("ThreadActivity", e); Toast.makeText(this, tr(R.string.s_gagal_menghapus_pesan), Toast.LENGTH_SHORT).show() }
                    load()
                }
                .setNegativeButton(tr(R.string.s_batal), null)
                .show()
        })
        val t = if (m.body.length > 60) m.body.substring(0, 60) + "…" else m.body
        showSheet(tr(R.string.s_pesan), t, items)
    }

    private fun dateChip(day: String): View {
        val t = TextView(this)
        t.text = day; t.textSize = 12f; t.setTextColor(MUTED); t.gravity = Gravity.CENTER
        t.background = rr(SURF, 12); t.setPadding(dp(12), dp(4), dp(12), dp(4))
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.gravity = Gravity.CENTER_HORIZONTAL
        p.topMargin = dp(8)
        t.layoutParams = p
        return t
    }

    private fun bubble(m: Msg): View {
        val out = m.type != Telephony.Sms.MESSAGE_TYPE_INBOX
        val failed = m.type == Telephony.Sms.MESSAGE_TYPE_FAILED
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.gravity = if (out) Gravity.END else Gravity.START
        val wp = LinearLayout.LayoutParams(MATCH, WRAP)
        wp.topMargin = dp(8)
        wrap.layoutParams = wp
        val tv = TextView(this)
        tv.text = m.body; tv.textSize = 15f; tv.setTextColor(if (out) Color.WHITE else INK)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val g = GradientDrawable()
        g.setColor(if (out) BLUE else SURF)
        val r = dp(18).toFloat()
        val s = dp(4).toFloat()
        g.cornerRadii = if (out) floatArrayOf(r, r, r, r, s, s, r, r) else floatArrayOf(r, r, r, r, r, r, s, s)
        tv.background = g
        tv.alpha = if (failed) 0.55f else 1f
        tv.setOnLongClickListener { showMsgActions(m); true }
        wrap.addView(tv)
        val time = SimpleDateFormat(if (L.en) "HH:mm" else "HH.mm", L.loc).format(Date(m.date))
        if (failed) {
            val rb = LinearLayout(this)
            rb.gravity = Gravity.CENTER
            rb.background = rr(RED, 16)
            rb.setPadding(dp(14), 0, dp(14), 0)
            rb.isClickable = true
            rb.setOnClickListener { resend(m) }
            rb.addView(icon(R.drawable.ic_replay, Color.WHITE, 16))
            val rt = TextView(this)
            rt.text = tr(R.string.s_gagal_terkirim_kirim_ulang); rt.textSize = 13f; rt.setTextColor(Color.WHITE)
            rt.setTypeface(null, Typeface.BOLD); rt.setPadding(dp(6), 0, 0, 0)
            rb.addView(rt)
            val rp = LinearLayout.LayoutParams(WRAP, dp(32))
            rp.topMargin = dp(6)
            wrap.addView(rb, rp)
        } else {
            val meta = TextView(this)
            val st = if (!out) "" else if (m.type == Telephony.Sms.MESSAGE_TYPE_SENT) " · Terkirim" else " · Mengirim…"
            meta.text = time + st; meta.textSize = 12f; meta.setTextColor(MUTED)
            meta.setPadding(dp(4), dp(4), dp(4), 0)
            wrap.addView(meta)
        }
        return wrap
    }
}
