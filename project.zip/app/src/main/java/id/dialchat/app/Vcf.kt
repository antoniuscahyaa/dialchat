package id.dialchat.app

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import java.io.ByteArrayOutputStream
import java.io.OutputStream

class Card {
    var first = ""
    var last = ""
    var fn = ""
    var note = ""
    val phones = ArrayList<Entry>()
    val emails = ArrayList<Entry>()
}

object Vcf {
    fun export(ctx: Context, out: OutputStream): Int {
        var n = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.LOOKUP_KEY), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val key = c.getString(0) ?: continue
                    try {
                        val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, key)
                        ctx.contentResolver.openInputStream(uri)?.use { ins ->
                            val b = ins.readBytes()
                            if (b.isNotEmpty()) {
                                out.write(b)
                                if (b[b.size - 1] != '\n'.code.toByte()) out.write('\n'.code)
                                n++
                            }
                        }
                    } catch (e: Exception) { logW("Vcf", e) }
                }
            }
            out.flush()
        } catch (e: Exception) { logW("Vcf", e) }
        return n
    }

    private fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                val nx = s[i + 1]
                sb.append(if (nx == 'n' || nx == 'N') '\n' else nx)
                i += 2
            } else { sb.append(ch); i++ }
        }
        return sb.toString()
    }

    private fun decodeQp(s: String): String {
        val bo = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '=' && i + 2 < s.length) {
                val h = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (h != null) { bo.write(h); i += 3; continue }
            }
            bo.write(ch.toString().toByteArray(Charsets.UTF_8))
            i++
        }
        return String(bo.toByteArray(), Charsets.UTF_8)
    }

    private fun phoneType(params: List<String>): Int {
        val p = params.joinToString(",")
        return when {
            p.contains("CELL") || p.contains("MOBILE") -> Phone.TYPE_MOBILE
            p.contains("HOME") -> Phone.TYPE_HOME
            p.contains("WORK") -> Phone.TYPE_WORK
            else -> Phone.TYPE_OTHER
        }
    }

    private fun emailType(params: List<String>): Int {
        val p = params.joinToString(",")
        return when {
            p.contains("HOME") -> Email.TYPE_HOME
            p.contains("WORK") -> Email.TYPE_WORK
            else -> Email.TYPE_OTHER
        }
    }

    fun parse(text: String): List<Card> {
        val raw = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val unfolded = ArrayList<String>()
        for (l in raw) {
            if ((l.startsWith(" ") || l.startsWith("\t")) && unfolded.isNotEmpty())
                unfolded[unfolded.size - 1] = unfolded[unfolded.size - 1] + l.substring(1)
            else unfolded.add(l)
        }
        val lines = ArrayList<String>()
        var k = 0
        while (k < unfolded.size) {
            var cur = unfolded[k]
            val head = cur.substringBefore(':').uppercase()
            if (head.contains("QUOTED-PRINTABLE")) {
                while (cur.endsWith("=") && k + 1 < unfolded.size) {
                    k++
                    cur = cur.dropLast(1) + unfolded[k]
                }
            }
            lines.add(cur)
            k++
        }

        val cards = ArrayList<Card>()
        var card: Card? = null
        for (line in lines) {
            val idx = line.indexOf(':')
            if (idx < 0) continue
            val headParts = line.substring(0, idx).split(';')
            val name = headParts[0].uppercase().substringAfterLast('.')
            val params = headParts.drop(1).map { it.uppercase() }
            var value = line.substring(idx + 1)
            if (name == "BEGIN" && value.trim().equals("VCARD", true)) { card = Card(); continue }
            if (name == "END") {
                val c = card
                if (c != null) {
                    if (c.first.isBlank() && c.last.isBlank() && c.fn.isNotBlank()) {
                        c.first = c.fn.substringBefore(' ')
                        c.last = c.fn.substringAfter(' ', "")
                    }
                    if (c.first.isNotBlank() || c.last.isNotBlank() || c.phones.isNotEmpty() || c.emails.isNotEmpty()) cards.add(c)
                }
                card = null
                continue
            }
            val c = card ?: continue
            if (params.any { it.contains("QUOTED-PRINTABLE") }) value = decodeQp(value)
            when (name) {
                "N" -> {
                    val p = value.split(';')
                    c.last = unescape(p.getOrElse(0) { "" }).trim()
                    c.first = unescape(p.getOrElse(1) { "" }).trim()
                }
                "FN" -> c.fn = unescape(value).trim()
                "TEL" -> { val v = unescape(value).trim(); if (v.isNotEmpty()) c.phones.add(Entry(v, phoneType(params))) }
                "EMAIL" -> { val v = unescape(value).trim(); if (v.isNotEmpty()) c.emails.add(Entry(v, emailType(params))) }
                "NOTE" -> c.note = unescape(value).trim()
            }
        }
        return cards
    }
}
