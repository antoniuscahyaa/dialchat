package id.dialchat.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class CallActivity : BaseActivity() {
    private val BLUE = Color.parseColor("#1D4ED8")
    private val GREEN = Color.parseColor("#0F7A41")
    private val RED = Color.parseColor("#B42318")
    private val INK by lazy { col(R.color.ink) }
    private val SURF by lazy { col(R.color.surf) }
    private val MUTED by lazy { col(R.color.muted) }
    private val BG by lazy { col(R.color.bg) }
    private val LINK by lazy { col(R.color.link) }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())
    private var statusTv: TextView? = null
    private var dotView: View? = null
    private var dtmf: Dialog? = null
    private var prox: PowerManager.WakeLock? = null
    private val listener: () -> Unit = { render() }
    private val tick = object : Runnable {
        override fun run() { updateStatus(); ui.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        setContentView(root)
        CallManager.addListener(listener)
        handleExtra(intent)
        render()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleExtra(intent)
        render()
    }

    override fun onDestroy() {
        CallManager.removeListener(listener)
        ui.removeCallbacksAndMessages(null)
        releaseProx()
        dtmf?.dismiss()
        super.onDestroy()
    }

    private fun handleExtra(i: Intent?) {
        val act = i?.getStringExtra("act")
        if (act == "answer") CallManager.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        if (act == "reject") CallManager.primary()?.reject(false, null)
        i?.removeExtra("act")
    }

    // ---------- helpers ----------
    private fun fl(w: Int, h: Int, g: Int, top: Int = 0, bottom: Int = 0, side: Int = 0): FrameLayout.LayoutParams {
        val p = FrameLayout.LayoutParams(w, h, g)
        p.setMargins(dp(side), dp(top), dp(side), dp(bottom))
        return p
    }
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private val TOPC = Gravity.TOP or Gravity.CENTER_HORIZONTAL

    private fun bars(c: Int, whiteNav: Boolean) {
        window.statusBarColor = c
        window.navigationBarColor = if (whiteNav) BG else c
        window.decorView.systemUiVisibility = if (whiteNav && !isDark) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
    }
    private fun ring(cy: Int, size: Int, alpha: Int) {
        val v = View(this)
        v.background = ov(Color.argb(alpha, 255, 255, 255))
        root.addView(v, fl(dp(size), dp(size), TOPC, cy - size / 2))
    }
    private fun chip(t: String): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = 14f; v.setTextColor(Color.WHITE); v.gravity = Gravity.CENTER
        v.background = rr(Color.argb(46, 255, 255, 255), 16)
        v.setPadding(dp(16), 0, dp(16), 0)
        return v
    }
    private fun avatar(name: String?, size: Int, top: Int): View {
        val f = name?.firstOrNull()
        val v: View
        if (f != null && f.isLetter()) {
            val t = TextView(this)
            t.text = f.uppercaseChar().toString(); t.gravity = Gravity.CENTER
            t.setTextColor(BLUE); t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, size * 0.44f)
            t.setTypeface(null, Typeface.BOLD)
            v = t
        } else {
            val fr = FrameLayout(this)
            val ic = icon(R.drawable.ic_person, BLUE, size / 2)
            ic.layoutParams = FrameLayout.LayoutParams(dp(size / 2), dp(size / 2), Gravity.CENTER)
            fr.addView(ic)
            v = fr
        }
        v.background = ov(Color.WHITE)
        v.layoutParams = fl(dp(size), dp(size), TOPC, top)
        return v
    }
    private fun nameBlock(name: String?, num: String, top: Int, sp: Int, showNum: Boolean): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER_HORIZONTAL
        val t = TextView(this)
        t.text = name ?: prettyNum(num).ifBlank { tr("Nomor tidak dikenal") }
        t.textSize = sp.toFloat(); t.setTypeface(null, Typeface.BOLD); t.setTextColor(Color.WHITE)
        t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END; t.gravity = Gravity.CENTER
        l.addView(t)
        if (showNum && name != null && num.isNotBlank()) {
            val n = TextView(this)
            n.text = prettyNum(num); n.textSize = 16f; n.setTextColor(Color.argb(224, 255, 255, 255))
            n.gravity = Gravity.CENTER; n.setPadding(0, dp(6), 0, 0)
            l.addView(n)
        }
        l.layoutParams = fl(MATCH, WRAP, Gravity.TOP, top, side = 24)
        return l
    }
    private fun pillBtn(res: Int, label: String, color: Int, fg: Int = Color.WHITE, r: Int = 32, stroke: Int = 0, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.gravity = Gravity.CENTER; l.background = rr(color, r, stroke, 2); l.isClickable = true
        l.setPadding(dp(20), 0, dp(20), 0)
        l.setOnClickListener { onClick() }
        l.addView(icon(res, fg, 24))
        val t = TextView(this)
        t.text = label; t.textSize = 17f; t.setTextColor(fg); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(10), 0, 0, 0)
        l.addView(t)
        return l
    }

    // ---------- render ----------
    private fun render() {
        ui.removeCallbacks(tick)
        val c = CallManager.primary()
        updateProximity(c)
        if (c == null) {
            val e = CallManager.ended
            if (e != null) {
                root.removeAllViews()
                statusTv = null; dotView = null
                endedScreen(e)
            } else {
                ui.postDelayed({ if (CallManager.calls.isEmpty() && CallManager.ended == null) finish() }, 600)
            }
            return
        }
        root.removeAllViews()
        statusTv = null; dotView = null
        if (c.state == Call.STATE_RINGING) incoming(c) else active(c)
    }

    private fun updateProximity(c: Call?) {
        val route = CallManager.audio?.route ?: CallAudioState.ROUTE_EARPIECE
        val want = c != null && c.state != Call.STATE_RINGING && c.state != Call.STATE_DISCONNECTED &&
            route == CallAudioState.ROUTE_EARPIECE
        if (!want) { releaseProx(); return }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) return
            if (prox == null) prox = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "dialchat:proximity")
            val w = prox
            if (w != null && !w.isHeld) w.acquire(4 * 60 * 60 * 1000L)
        } catch (e: Exception) { }
    }

    private fun releaseProx() {
        try {
            val w = prox
            if (w != null && w.isHeld) w.release()
        } catch (e: Exception) { }
    }

    private fun incoming(c: Call) {
        root.setBackgroundColor(BLUE)
        bars(BLUE, false)
        ring(240, 280, 26); ring(240, 400, 18); ring(240, 520, 13)
        val num = CallUtil.number(c)
        val name = CallUtil.name(this, num)
        val sim = CallUtil.sim(this, c)
        val ch = chip((if (CallManager.calls.size > 1) tr("Panggilan menunggu") else tr("Panggilan masuk")) + (if (sim != null) " · $sim" else ""))
        root.addView(ch, fl(WRAP, dp(32), TOPC, 72))
        root.addView(avatar(name, 120, 180))
        root.addView(nameBlock(name, num, 322, 30, true))
        if (Wa.normalize(num) != null) {
            val wb = pillBtn(R.drawable.ic_wa, tr("Chat WhatsApp"), GREEN, Color.WHITE, 24, Color.WHITE) { Wa.open(this, num) }
            root.addView(wb, fl(WRAP, dp(48), TOPC, 412))
        }

        val other = if (CallManager.calls.size > 1) CallManager.other(c) else null
        if (other != null) {
            val ab = TextView(this)
            ab.text = tr("Akhiri panggilan aktif & jawab"); ab.textSize = 14f; ab.setTextColor(Color.WHITE)
            ab.gravity = Gravity.CENTER; ab.background = rr(Color.argb(46, 255, 255, 255), 22)
            ab.setPadding(dp(18), 0, dp(18), 0); ab.isClickable = true
            ab.setOnClickListener { other.disconnect(); c.answer(VideoProfile.STATE_AUDIO_ONLY) }
            root.addView(ab, fl(WRAP, dp(44), TOPC, 484))
        }
        val pill = FrameLayout(this)
        pill.background = rr(Color.WHITE, 38)
        val knob = FrameLayout(this)
        knob.background = ov(GREEN)
        knob.contentDescription = tr("Geser untuk menjawab")
        val kic = icon(R.drawable.ic_phone, Color.WHITE, 28)
        kic.layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
        knob.addView(kic)
        val kp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.START or Gravity.CENTER_VERTICAL)
        kp.marginStart = dp(8)
        pill.addView(knob, kp)
        val label = TextView(this)
        label.text = tr("Geser untuk menjawab"); label.textSize = 16f; label.setTextColor(INK)
        label.gravity = Gravity.CENTER; label.setTypeface(null, Typeface.BOLD)
        pill.addView(label, FrameLayout.LayoutParams(MATCH, MATCH))
        val chev = LinearLayout(this)
        chev.gravity = Gravity.CENTER_VERTICAL
        val alphas = floatArrayOf(1f, 0.6f, 0.3f)
        for (a in alphas) {
            val ci = icon(R.drawable.ic_chevron, BLUE, 22)
            ci.alpha = a
            chev.addView(ci)
        }
        val cp = FrameLayout.LayoutParams(WRAP, MATCH, Gravity.END or Gravity.CENTER_VERTICAL)
        cp.marginEnd = dp(16)
        pill.addView(chev, cp)
        var sx = 0f
        knob.setOnTouchListener { v, e ->
            val max = (pill.width - dp(76)).toFloat()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    v.translationX = (e.rawX - sx).coerceIn(0f, max)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (v.translationX > max * 0.7f) c.answer(VideoProfile.STATE_AUDIO_ONLY)
                    else v.animate().translationX(0f).setDuration(150).start()
                    true
                }
                else -> false
            }
        }
        val pp = FrameLayout.LayoutParams(MATCH, dp(76), Gravity.BOTTOM)
        pp.setMargins(dp(36), 0, dp(36), dp(164))
        root.addView(pill, pp)

        val rej = pillBtn(R.drawable.ic_hangup, tr("Tolak"), RED) { c.reject(false, null) }
        val msg = pillBtn(R.drawable.ic_bubble, tr2("Pesan", "Message"), Color.argb(46, 255, 255, 255)) {
            showQuickReplies(num) { c.reject(false, null) }
        }
        val rowb = LinearLayout(this)
        val rl = lp(0, MATCH, 1f)
        rl.marginEnd = dp(6)
        rowb.addView(rej, rl)
        val ml = lp(0, MATCH, 1f)
        ml.marginStart = dp(6)
        rowb.addView(msg, ml)
        val rp = FrameLayout.LayoutParams(MATCH, dp(60), Gravity.BOTTOM)
        rp.setMargins(dp(36), 0, dp(36), dp(72))
        root.addView(rowb, rp)
    }

    private fun tile(res: Int, label: String, on: Boolean, green: Boolean = false, onClick: () -> Unit): View {
        val filled = on || green
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(dp(12), dp(12), dp(12), dp(12))
        t.background = rr(if (green) GREEN else if (on) BLUE else SURF, 20)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        val circle = FrameLayout(this)
        circle.background = ov(if (filled) Color.WHITE else BLUE)
        val ic = icon(res, if (green) GREEN else if (on) BLUE else Color.WHITE, 20)
        ic.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
        circle.addView(ic)
        t.addView(circle, lp(dp(36), dp(36)))
        t.addView(View(this), lp(MATCH, 0, 1f))
        val tv = TextView(this)
        tv.text = label; tv.textSize = 13f; tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
        tv.setTextColor(if (filled) Color.WHITE else INK)
        t.addView(tv)
        val m = lp(0, dp(88), 1f)
        m.setMargins(dp(5), dp(5), dp(5), dp(5))
        t.layoutParams = m
        return t
    }

    private fun routeIcon(r: Int): Int = when (r) {
        CallAudioState.ROUTE_SPEAKER -> R.drawable.ic_speaker
        CallAudioState.ROUTE_BLUETOOTH -> R.drawable.ic_bluetooth
        CallAudioState.ROUTE_WIRED_HEADSET -> R.drawable.ic_headset
        else -> R.drawable.ic_phone
    }

    private fun routeName(r: Int): String = when (r) {
        CallAudioState.ROUTE_SPEAKER -> "Speaker"
        CallAudioState.ROUTE_BLUETOOTH -> "Bluetooth"
        CallAudioState.ROUTE_WIRED_HEADSET -> "Headset"
        else -> tr("Telinga")
    }

    private fun active(c: Call) {
        root.setBackgroundColor(BG)
        bars(BLUE, true)
        val top = View(this)
        val gd = GradientDrawable()
        gd.setColor(BLUE)
        val rad = dp(36).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        top.background = gd
        root.addView(top, fl(MATCH, dp(390), Gravity.TOP))
        ring(190, 240, 26); ring(190, 360, 15)
        val num = CallUtil.number(c)
        val name = CallUtil.name(this, num)
        root.addView(chip(CallUtil.sim(this, c) ?: tr("Panggilan suara")), fl(WRAP, dp(32), TOPC, 64))
        root.addView(avatar(name, 96, 120))
        root.addView(nameBlock(name, num, 232, 28, false))

        val sp = LinearLayout(this)
        sp.gravity = Gravity.CENTER
        sp.background = rr(Color.argb(46, 255, 255, 255), 18)
        sp.setPadding(dp(16), dp(6), dp(16), dp(6))
        val dot = View(this)
        dot.background = ov(Color.parseColor("#7EE2A8"))
        val dp8 = lp(dp(8), dp(8))
        dp8.marginEnd = dp(8)
        sp.addView(dot, dp8)
        val st = TextView(this)
        st.textSize = 18f; st.setTextColor(Color.WHITE)
        sp.addView(st)
        root.addView(sp, fl(WRAP, WRAP, TOPC, 286))
        statusTv = st; dotView = dot

        val other = CallManager.other(c)
        if (other != null) {
            val on = CallUtil.number(other)
            val onm = CallUtil.name(this, on) ?: prettyNum(on).ifBlank { tr("Nomor tidak dikenal") }
            val bar = LinearLayout(this)
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.background = rr(Color.argb(46, 255, 255, 255), 20)
            bar.setPadding(dp(16), 0, dp(6), 0)
            val tv = TextView(this)
            tv.text = (if (other.state == Call.STATE_HOLDING) tr("Ditahan: ") else tr("Panggilan lain: ")) + onm
            tv.textSize = 14f; tv.setTextColor(Color.WHITE); tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
            bar.addView(tv, lp(0, WRAP, 1f))
            fun chipBtn(t: String, onClick: () -> Unit) {
                val b = TextView(this)
                b.text = t; b.textSize = 14f; b.setTextColor(BLUE); b.setTypeface(null, Typeface.BOLD)
                b.gravity = Gravity.CENTER; b.background = rr(Color.WHITE, 16)
                b.setPadding(dp(14), 0, dp(14), 0); b.isClickable = true
                b.setOnClickListener { onClick() }
                val bp = lp(WRAP, dp(32))
                bp.marginStart = dp(6)
                bar.addView(b, bp)
            }
            chipBtn(tr("Tukar")) { if (other.state == Call.STATE_HOLDING) other.unhold() else c.hold() }
            val caps = c.details?.callCapabilities ?: 0
            if ((caps and Call.Details.CAPABILITY_MERGE_CONFERENCE) != 0) chipBtn(tr("Gabung")) { c.conference(other) }
            root.addView(bar, fl(MATCH, dp(40), Gravity.TOP, 336, side = 24))
        }

        val audio = CallManager.audio
        val muted = audio?.isMuted == true
        val route = audio?.route ?: CallAudioState.ROUTE_EARPIECE
        val hold = c.state == Call.STATE_HOLDING
        val onRoute = route != CallAudioState.ROUTE_EARPIECE && route != CallAudioState.ROUTE_WIRED_OR_EARPIECE
        val gr = LinearLayout(this)
        gr.orientation = LinearLayout.VERTICAL
        val r1 = LinearLayout(this)
        r1.addView(tile(R.drawable.ic_mic, tr("Bisukan"), muted) { CallManager.service?.setMuted(!muted) })
        r1.addView(tile(R.drawable.ic_dial, tr("Papan angka"), false) { showDtmf(c) })
        r1.addView(tile(routeIcon(route), routeName(route), onRoute) { showRoutes() })
        val r2 = LinearLayout(this)
        r2.addView(tile(R.drawable.ic_pause, tr("Tahan"), hold) { if (hold) c.unhold() else c.hold() })
        r2.addView(tile(R.drawable.ic_add, tr("Tambah"), false) { addCall() })
        if (Wa.normalize(num) != null) {
            r2.addView(tile(R.drawable.ic_wa, "WhatsApp", false, true) { Wa.open(this, num) })
        } else {
            val spc = lp(0, dp(88), 1f)
            spc.setMargins(dp(5), dp(5), dp(5), dp(5))
            r2.addView(View(this), spc)
        }
        gr.addView(r1, lp(MATCH, WRAP))
        gr.addView(r2, lp(MATCH, WRAP))
        root.addView(gr, fl(MATCH, WRAP, Gravity.TOP, 408, side = 19))

        val end = pillBtn(R.drawable.ic_hangup, tr("Akhiri panggilan"), RED) { c.disconnect() }
        val ep = FrameLayout.LayoutParams(MATCH, dp(64), Gravity.BOTTOM)
        ep.setMargins(dp(24), 0, dp(24), dp(40))
        root.addView(end, ep)
        updateStatus()
        ui.postDelayed(tick, 1000)
    }

    private fun addCall() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.putExtra("tab", 0)
        startActivity(i)
    }

    private fun showRoutes() {
        val a = CallManager.audio ?: return
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(8))
        box.background = rr(BG, 24)
        val t = TextView(this)
        t.text = tr("Keluaran suara"); t.textSize = 20f; t.setTextColor(INK); t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(4), 0, 0, dp(8))
        box.addView(t)
        val routes = intArrayOf(CallAudioState.ROUTE_EARPIECE, CallAudioState.ROUTE_WIRED_HEADSET, CallAudioState.ROUTE_BLUETOOTH, CallAudioState.ROUTE_SPEAKER)
        for (rt in routes) {
            if ((a.supportedRouteMask and rt) == 0) continue
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(12), dp(4), dp(12))
            row.isClickable = true
            row.setOnClickListener { CallManager.service?.setAudioRoute(rt); d.dismiss() }
            row.addView(icon(routeIcon(rt), INK, 24))
            val tv = TextView(this)
            tv.text = routeName(rt); tv.textSize = 17f; tv.setTextColor(INK)
            val tp = lp(0, WRAP, 1f)
            tp.marginStart = dp(16)
            row.addView(tv, tp)
            if (a.route == rt) {
                val ck = TextView(this)
                ck.text = tr("Aktif"); ck.textSize = 14f; ck.setTextColor(LINK); ck.setTypeface(null, Typeface.BOLD)
                row.addView(ck)
            }
            box.addView(row, lp(MATCH, WRAP))
        }
        val close = TextView(this)
        close.text = tr("Tutup"); close.textSize = 16f; close.setTextColor(LINK); close.gravity = Gravity.CENTER
        close.setTypeface(null, Typeface.BOLD)
        close.setOnClickListener { d.dismiss() }
        box.addView(close, lp(MATCH, dp(48)))
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(dp(320), WRAP)
        d.show()
        dtmf = d
    }

    override fun onBackPressed() {
        CallManager.ended = null
        super.onBackPressed()
    }

    private fun endedScreen(e: Ended) {
        root.setBackgroundColor(BG)
        bars(BLUE, true)
        val top = View(this)
        val g = GradientDrawable()
        g.setColor(BLUE)
        val rad = dp(36).toFloat()
        g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, rad, rad, rad, rad)
        top.background = g
        root.addView(top, fl(MATCH, dp(340), Gravity.TOP))
        ring(170, 220, 26); ring(170, 340, 15)
        root.addView(chip(tr("Panggilan berakhir")), fl(WRAP, dp(32), TOPC, 64))
        root.addView(avatar(e.name, 96, 110))
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER_HORIZONTAL
        val t = TextView(this)
        t.text = e.name ?: prettyNum(e.number).ifBlank { tr("Nomor tidak dikenal") }
        t.textSize = 28f; t.setTypeface(null, Typeface.BOLD); t.setTextColor(Color.WHITE)
        t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END; t.gravity = Gravity.CENTER
        l.addView(t)
        val parts = ArrayList<String>()
        if (e.name != null && e.number.isNotBlank()) parts.add(prettyNum(e.number))
        if (e.seconds > 0L) parts.add(fmt(e.seconds))
        if (e.sim != null) parts.add(e.sim)
        if (parts.isNotEmpty()) {
            val s = TextView(this)
            s.text = parts.joinToString(" · "); s.textSize = 16f; s.setTextColor(Color.argb(224, 255, 255, 255))
            s.gravity = Gravity.CENTER; s.setPadding(0, dp(6), 0, 0)
            l.addView(s)
        }
        root.addView(l, fl(MATCH, WRAP, Gravity.TOP, 222, side = 24))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        fun add(v: View) {
            val p = lp(MATCH, dp(60))
            p.bottomMargin = dp(12)
            col.addView(v, p)
        }
        add(pillBtn(R.drawable.ic_phone, tr("Telepon lagi"), BLUE, Color.WHITE, 30) {
            val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(e.number)))
            if (e.acc != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, e.acc)
            CallManager.ended = null
            try { startActivity(i) } catch (x: Exception) { }
        })
        if (Wa.normalize(e.number) != null) add(pillBtn(R.drawable.ic_wa, tr("Chat WhatsApp"), GREEN, Color.WHITE, 30) { Wa.open(this, e.number) })
        if (e.name == null) add(pillBtn(R.drawable.ic_userplus, tr("Simpan kontak"), SURF, INK, 30) {
            try { startActivity(Intent(this, ContactEditActivity::class.java).putExtra("number", e.number)) } catch (x: Exception) { }
        })
        if (e.number.isNotBlank()) add(pillBtn(R.drawable.ic_bubble, tr("Pesan cepat"), SURF, INK, 30) { showQuickReplies(e.number) })
        root.addView(col, fl(MATCH, WRAP, Gravity.TOP, 380, side = 24))

        val close = TextView(this)
        close.text = tr("Tutup"); close.textSize = 16f; close.setTextColor(MUTED)
        close.gravity = Gravity.CENTER; close.setTypeface(null, Typeface.BOLD)
        close.setOnClickListener { CallManager.ended = null; finish() }
        root.addView(close, fl(MATCH, dp(52), Gravity.BOTTOM, bottom = 40, side = 24))
    }

    private fun fmt(sec: Long): String {
        val m = sec / 60
        val s = sec % 60
        return if (m >= 60) "%d:%02d:%02d".format(m / 60, m % 60, s) else "%02d:%02d".format(m, s)
    }

    private fun updateStatus() {
        val c = CallManager.primary() ?: return
        val s = when (c.state) {
            Call.STATE_ACTIVE -> {
                val t = c.details?.connectTimeMillis ?: 0L
                if (t > 0L) fmt((System.currentTimeMillis() - t) / 1000) else "00:00"
            }
            Call.STATE_HOLDING -> tr("Ditahan")
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> tr("Panggilan berakhir")
            else -> tr("Memanggil…")
        }
        statusTv?.text = s
        dotView?.visibility = if (c.state == Call.STATE_ACTIVE) View.VISIBLE else View.GONE
    }

    private fun showDtmf(c: Call) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(8))
        box.background = rr(BG, 24)
        val shown = TextView(this)
        shown.textSize = 28f; shown.setTextColor(INK); shown.gravity = Gravity.CENTER
        shown.minHeight = dp(48); shown.maxLines = 1
        box.addView(shown, lp(MATCH, WRAP))
        val keys = "123456789*0#"
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (k in 0 until 3) {
                val ch = keys[r * 3 + k]
                val key = TextView(this)
                key.text = ch.toString(); key.textSize = 26f; key.setTextColor(INK)
                key.gravity = Gravity.CENTER; key.background = rr(SURF, 18); key.isClickable = true
                key.setOnClickListener {
                    shown.append(ch.toString())
                    c.playDtmfTone(ch)
                    ui.postDelayed({ c.stopDtmfTone() }, 150)
                }
                val kp = lp(0, dp(64), 1f)
                kp.setMargins(dp(4), dp(4), dp(4), dp(4))
                row.addView(key, kp)
            }
            box.addView(row, lp(MATCH, WRAP))
        }
        val close = TextView(this)
        close.text = tr("Tutup"); close.textSize = 16f; close.setTextColor(LINK); close.gravity = Gravity.CENTER
        close.setTypeface(null, Typeface.BOLD)
        close.setOnClickListener { d.dismiss() }
        box.addView(close, lp(MATCH, dp(48)))
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(dp(320), WRAP)
        d.show()
        dtmf = d
    }
}
