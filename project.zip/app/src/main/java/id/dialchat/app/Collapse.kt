package id.dialchat.app

import android.content.Context
import android.view.View
import android.widget.AbsListView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t
fun lerpI(a: Int, b: Int, t: Float): Int = (a + (b - a) * t).toInt()

/**
 * Header biru yang menyusut saat daftar di-scroll.
 * Header berada di atas daftar (overlay) dan daftar diberi padding atas setinggi header penuh,
 * sehingga isi daftar naik tepat sebesar penyusutan header tanpa lompatan.
 */
class Collapse(private val hdr: View, var exp: Int, var col: Int, private val onP: (Float) -> Unit) {
    var p = 0f
        private set
    private var lastOff = 0

    fun set(off: Int) {
        lastOff = off
        val range = (exp - col).coerceAtLeast(1)
        p = (off.toFloat() / range).coerceIn(0f, 1f)
        val h = lerpI(exp, col, p)
        val lp = hdr.layoutParams
        if (lp != null && lp.height != h) {
            lp.height = h
            hdr.layoutParams = lp
        }
        onP(p)
    }

    fun refresh() = set(lastOff)

    fun attach(list: ListView) {
        list.clipToPadding = false
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, state: Int) {}
            override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                val c = v.getChildAt(0)
                set(
                    when {
                        total == 0 || c == null -> 0
                        first == 0 -> (v.paddingTop - c.top).coerceAtLeast(0)
                        else -> Int.MAX_VALUE / 2
                    }
                )
            }
        })
        set(0)
    }

    fun attach(sv: ScrollView) {
        sv.clipToPadding = false
        sv.viewTreeObserver.addOnScrollChangedListener { set(sv.scrollY) }
        set(0)
    }
}

/** Bagian-bagian header biru standar (tombol kembali + judul) agar bisa dianimasikan. */
class HdrParts(val hdr: FrameLayout, val col: LinearLayout, val top: LinearLayout, val title: TextView, val back: View) {
    operator fun component1() = hdr
    operator fun component2() = col
}

fun View.setSquare(px: Int) {
    val lp = layoutParams ?: return
    if (lp.width != px || lp.height != px) {
        lp.width = px; lp.height = px
        layoutParams = lp
    }
}

/** Header sederhana: tombol kembali + judul di LinearLayout dengan padding (20, 44, 20, 24). */
fun Context.simpleCollapse(hdr: LinearLayout, back: View, title: TextView, big: Float, small: Float, expDp: Int, colDp: Int): Collapse =
    Collapse(hdr, dp(expDp), dp(colDp)) { p ->
        hdr.setPadding(dp(20), lerpI(dp(44), dp(14), p), dp(20), lerpI(dp(24), dp(10), p))
        title.textSize = lerpF(big, small, p)
        back.setSquare(lerpI(dp(44), dp(40), p))
    }
