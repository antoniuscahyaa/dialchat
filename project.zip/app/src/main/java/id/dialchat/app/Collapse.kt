package id.dialchat.app

import android.animation.ValueAnimator
import android.content.Context
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.widget.AbsListView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t
fun lerpI(a: Int, b: Int, t: Float): Int = (a + (b - a) * t).toInt()

/** Ukuran teks header memakai dp (tidak ikut skala font sistem) agar tinggi header tetap pas. */
fun TextView.setTextDp(v: Float) = setTextSize(TypedValue.COMPLEX_UNIT_DIP, v)

fun View.setSquare(px: Int) {
    val lp = layoutParams ?: return
    if (lp.width != px || lp.height != px) {
        lp.width = px; lp.height = px
        layoutParams = lp
    }
}

fun View.setHeightPx(px: Int) {
    val lp = layoutParams ?: return
    if (lp.height != px) { lp.height = px; layoutParams = lp }
}

/**
 * Header yang menyusut saat daftar di-scroll ke atas dan terbuka lagi begitu daftar ditarik ke bawah
 * (tanpa harus sampai ke paling atas). Saat jari dilepas di tengah animasi, header menuntaskan diri
 * ke kondisi penuh atau kecil.
 *
 * Header berada di atas daftar (overlay) dan daftar diberi padding atas setinggi header penuh,
 * sehingga isi daftar naik tepat sebesar penyusutan header tanpa celah.
 * p = 0 header penuh, p = 1 header kecil.
 */
class Collapse(private val hdr: View, var exp: Int, var col: Int, private val onP: (Float) -> Unit) {
    var p = 0f
        private set
    private var off = 0
    private var anim: ValueAnimator? = null
    private var scrollBy: ((Int) -> Unit)? = null
    private val range: Int get() = (exp - col).coerceAtLeast(1)

    private fun apply() {
        val h = lerpI(exp, col, p)
        val lp = hdr.layoutParams
        if (lp != null && lp.height != h) {
            lp.height = h
            hdr.layoutParams = lp
        }
        onP(p)
    }

    fun refresh() = apply()

    private fun setP(v: Float) {
        p = v.coerceIn(0f, 1f)
        apply()
    }

    /** newOff = jarak scroll dari atas (px). exact = nilai pasti, bukan perkiraan. */
    private fun moved(newOff: Int, exact: Boolean) {
        val d = newOff - off
        off = newOff
        anim?.let { it.cancel(); anim = null }
        var np = (p + d.toFloat() / range).coerceIn(0f, 1f)
        // Header tidak boleh lebih kecil dari yang ditentukan posisi scroll (kalau tidak, muncul celah di bawahnya).
        if (exact) np = minOf(np, (off.toFloat() / range).coerceAtLeast(0f))
        if (np != p) setP(np)
    }

    private fun snap() {
        if (p <= 0.001f || p >= 0.999f) return
        if (off < range) {
            // Header masih mengikuti scroll: tuntaskan dengan menggeser daftar.
            val target = if (off < range / 2) 0 else range
            scrollBy?.invoke(target - off)
        } else {
            val to = if (p < 0.5f) 0f else 1f
            anim = ValueAnimator.ofFloat(p, to).apply {
                duration = 160
                addUpdateListener { setP(it.animatedValue as Float) }
                start()
            }
        }
    }

    fun attach(list: ListView, extra: ((Int, Int, Int) -> Unit)? = null) {
        list.clipToPadding = false
        scrollBy = { dy -> if (dy != 0) list.smoothScrollBy(dy, 160) }
        var lastFirst = 0
        var lastTop = Int.MIN_VALUE
        var lastH = 0
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, state: Int) {
                if (state == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) snap()
            }

            override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                extra?.invoke(first, visible, total)
                val c = v.getChildAt(0)
                if (total == 0 || c == null) {
                    lastTop = Int.MIN_VALUE
                    moved(0, true)
                    return
                }
                if (first == 0) {
                    moved((v.paddingTop - c.top).coerceAtLeast(0), true)
                } else {
                    var n = off
                    if (lastTop != Int.MIN_VALUE) {
                        n += when {
                            first == lastFirst -> lastTop - c.top
                            first > lastFirst -> (lastTop + lastH) - c.top + (first - lastFirst - 1) * c.height
                            else -> lastTop - (c.top + c.height) - (lastFirst - first - 1) * c.height
                        }
                    }
                    moved(n.coerceAtLeast(0), false)
                }
                lastFirst = first; lastTop = c.top; lastH = c.height
            }
        })
        apply()
    }

    fun attach(sv: ScrollView) {
        sv.clipToPadding = false
        scrollBy = { dy -> if (dy != 0) sv.smoothScrollBy(0, dy) }
        var down = false
        val idle = Runnable { if (!down) snap() }
        sv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> down = true
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; sv.removeCallbacks(idle); sv.postDelayed(idle, 130) }
            }
            false
        }
        sv.viewTreeObserver.addOnScrollChangedListener {
            moved(sv.scrollY, true)
            sv.removeCallbacks(idle)
            sv.postDelayed(idle, 130)
        }
        apply()
    }
}

/** Bagian-bagian header biru standar (tombol kembali + judul) agar bisa dianimasikan. */
class HdrParts(val hdr: FrameLayout, val col: LinearLayout, val top: LinearLayout, val title: TextView, val back: View) {
    operator fun component1() = hdr
    operator fun component2() = col
}

/** Header sederhana: tombol kembali + judul di LinearLayout dengan padding (20, 44, 20, 24). */
fun Context.simpleCollapse(hdr: LinearLayout, back: View, title: TextView, big: Float, small: Float, expDp: Int, colDp: Int): Collapse =
    Collapse(hdr, dp(expDp), dp(colDp)) { p ->
        hdr.setPadding(dp(20), lerpI(dp(44), dp(14), p), dp(20), lerpI(dp(24), dp(10), p))
        title.setTextDp(lerpF(big, small, p))
        back.setSquare(lerpI(dp(44), dp(40), p))
    }

/** Latar bagian bawah yang melengkung: sudut yang "bolong" diisi warna latar halaman agar isi daftar tidak tembus. */
fun cornerBg(shape: android.graphics.drawable.Drawable, bg: Int): android.graphics.drawable.Drawable =
    android.graphics.drawable.LayerDrawable(arrayOf(android.graphics.drawable.ColorDrawable(bg), shape))

/**
 * Header biru dengan sudut bawah melengkung. Sudut yang bolong diisi warna latar halaman dan isi header
 * (termasuk lingkaran dekorasi) dipotong mengikuti lengkungan, jadi baris daftar yang lewat di belakangnya tidak terlihat.
 */
class RoundHeader(ctx: Context, private val blue: Int, private val bg: Int, private val rad: Float) : FrameLayout(ctx) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val shape = android.graphics.Path()
    private val corners = android.graphics.Path()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shape.reset()
        shape.addRoundRect(android.graphics.RectF(0f, -rad, w.toFloat(), h.toFloat()), rad, rad, android.graphics.Path.Direction.CW)
        corners.reset()
        corners.addRect(0f, 0f, w.toFloat(), h.toFloat(), android.graphics.Path.Direction.CW)
        corners.op(shape, android.graphics.Path.Op.DIFFERENCE)
    }

    override fun dispatchDraw(canvas: android.graphics.Canvas) {
        paint.color = bg
        canvas.drawPath(corners, paint)
        paint.color = blue
        canvas.drawPath(shape, paint)
        val s = canvas.save()
        canvas.clipPath(shape)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(s)
    }
}
